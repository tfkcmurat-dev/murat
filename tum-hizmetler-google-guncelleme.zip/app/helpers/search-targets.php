<?php
/** Search metadata only. Does not replace visible service content. */
function bsSearchTargetFor($pageSlug) {
    static $targets = null;
    if ($targets === null) $targets = json_decode(<<<'SEARCH_TARGETS_JSON'
{
  "hizmet/bilgisayar-mac-servis": {
    "title": "Bilgisayar ve Mac Servisi İstanbul",
    "description": "İstanbul bilgisayar ve mac servisi: bilgisayar, laptop, MacBook ve iMac için bakım ve onarım seçenekleri. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/elektrik-elektronik": {
    "title": "Elektrik ve Elektronik Teknik Servis İstanbul",
    "description": "İstanbul elektrik ve elektronik teknik servis: tesisat, aydınlatma ve elektronik cihaz ihtiyaçları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/tv-uydu-kamera": {
    "title": "TV, Uydu ve Kamera Servisi İstanbul",
    "description": "İstanbul tv, uydu ve kamera servisi: televizyon, uydu ve kamera sistemi çözümleri. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/kucuk-ev-aletleri-tamiri": {
    "title": "Küçük Ev Aletleri Tamiri İstanbul",
    "description": "İstanbul küçük ev aletleri tamiri: kişisel bakım, mutfak, temizlik ve ütü cihazları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/bilgisayar-tamiri": {
    "title": "Bilgisayar Tamiri İstanbul",
    "description": "İstanbul bilgisayar tamiri: masaüstü ve laptoplarda açılmama, ısınma ve yavaşlama sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/macbook-imac-servis": {
    "title": "MacBook ve iMac Tamiri İstanbul",
    "description": "İstanbul macbook ve imac tamiri: MacBook ve iMac cihazlarda arıza, bakım ve performans değerlendirmesi. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/donanim-yukseltme": {
    "title": "SSD ve RAM Yükseltme İstanbul",
    "description": "İstanbul ssd ve ram yükseltme: uyumlu SSD ve RAM seçimi, kurulum ve veri aktarımı planlaması. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/elektrik-tesisati": {
    "title": "Elektrik Tesisatı İstanbul",
    "description": "İstanbul elektrik tesisatı: ev ve iş yerlerinde hat, bağlantı ve tesisat değerlendirmesi. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/priz-sigorta-aydinlatma": {
    "title": "Priz, Sigorta ve Aydınlatma İstanbul",
    "description": "İstanbul priz, sigorta ve aydınlatma: priz, sigorta, anahtar ve aydınlatma ihtiyaçları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/avize-montaji": {
    "title": "Avize Montajı İstanbul",
    "description": "İstanbul avize montajı: montaj yeri, ürün uygunluğu ve aydınlatma bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/tv-tamiri": {
    "title": "TV Tamiri İstanbul",
    "description": "İstanbul tv tamiri: televizyonlarda görüntü, ses ve açılmama sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/uydu-sistemleri": {
    "title": "Uydu Ayarı ve Kanal Ayarlama İstanbul",
    "description": "İstanbul uydu ayarı ve kanal ayarlama: anten, sinyal, alıcı bağlantısı ve kanal taraması. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/kamera-sistemleri": {
    "title": "Güvenlik Kamerası Kurulumu İstanbul",
    "description": "İstanbul güvenlik kamerası kurulumu: kamera konumu, kayıt cihazı ve görüntü bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/yazici-toner-servisi": {
    "title": "Yazıcı ve Toner Servisi İstanbul",
    "description": "İstanbul yazıcı ve toner servisi: baskı kalitesi, bağlantı, sürücü ve toner uygunluğu. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/elektronik-onarim": {
    "title": "Elektronik Onarım İstanbul",
    "description": "İstanbul elektronik onarım: elektronik cihaz, güç ve devre incelemesi. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/evler-icin-teknik-servis": {
    "title": "Evler İçin Teknik Servis İstanbul",
    "description": "İstanbul evler i̇çin teknik servis: evde kullanılan cihazlar ve teknik sistemler. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/ofisler-icin-teknik-servis": {
    "title": "Ofis Teknik Servisi İstanbul",
    "description": "İstanbul ofis teknik servisi: ofis bilgisayarları, yazıcılar ve teknik altyapı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/isletmeler-icin-teknik-servis": {
    "title": "İşletmeler İçin Teknik Servis İstanbul",
    "description": "İstanbul i̇şletmeler i̇çin teknik servis: işletme cihazları, kamera ve teknik sistem ihtiyaçları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/sanayi-icin-teknik-servis": {
    "title": "Sanayi Elektrik ve Elektronik Servisi İstanbul",
    "description": "İstanbul sanayi elektrik ve elektronik servisi: elektrik, elektronik ve otomasyon bağlantısı değerlendirmesi. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/tamir-bakim": {
    "title": "Cihaz Tamir ve Bakım Hizmeti İstanbul",
    "description": "İstanbul cihaz tamir ve bakım hizmeti: cihaz arızası, bakım ve uygun parça seçenekleri. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/cihaz-satis-aksesuar": {
    "title": "Bilgisayar, Yazıcı ve Aksesuar Satışı İstanbul",
    "description": "İstanbul bilgisayar, yazıcı ve aksesuar satışı: kullanım ihtiyacı, cihaz ve aksesuar uyumluluğu. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/satis-sonrasi-destek": {
    "title": "Satış Sonrası Teknik Destek İstanbul",
    "description": "İstanbul satış sonrası teknik destek: kurulum, bağlantı ve kullanım sorularınız. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/kahve-makinesi-tamiri": {
    "title": "Kahve Makinesi Tamiri İstanbul",
    "description": "İstanbul kahve makinesi tamiri: su akışı, ısıtma ve çalışma sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/su-isiticisi-tamiri": {
    "title": "Su Isıtıcısı Tamiri İstanbul",
    "description": "İstanbul su isıtıcısı tamiri: ısıtmama, termostat ve güç bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/tost-makinesi-tamiri": {
    "title": "Tost Makinesi Tamiri İstanbul",
    "description": "İstanbul tost makinesi tamiri: ısıtıcı, termostat ve çalışma kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/blender-tamiri": {
    "title": "Blender Tamiri İstanbul",
    "description": "İstanbul blender tamiri: motor, güç ve hazne bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/mikser-tamiri": {
    "title": "Mikser Tamiri İstanbul",
    "description": "İstanbul mikser tamiri: motor, hız kademesi ve bağlantı sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/supurge-tamiri": {
    "title": "Süpürge Tamiri İstanbul",
    "description": "İstanbul süpürge tamiri: çekiş, motor, filtre ve hava akışı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/fon-makinesi-tamiri": {
    "title": "Fön Makinesi Tamiri İstanbul",
    "description": "İstanbul fön makinesi tamiri: saç kurutma makinesinde ısıtma, hava akışı ve motor sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/sac-masasi-tamiri": {
    "title": "Saç Maşası Tamiri İstanbul",
    "description": "İstanbul saç maşası tamiri: ısıtıcı, sıcaklık ayarı ve kablo bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/sac-duzlestirici-tamiri": {
    "title": "Saç Düzleştirici Tamiri İstanbul",
    "description": "İstanbul saç düzleştirici tamiri: ısıtıcı plaka, sıcaklık ve güç sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/tras-makinesi-tamiri": {
    "title": "Tıraş Makinesi Tamiri İstanbul",
    "description": "İstanbul tıraş makinesi tamiri: şarj, batarya, motor ve kesici bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/epilator-tamiri": {
    "title": "Epilatör Tamiri İstanbul",
    "description": "İstanbul epilatör tamiri: şarj, motor ve başlık çalışma sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/cay-makinesi-tamiri": {
    "title": "Çay Makinesi Tamiri İstanbul",
    "description": "İstanbul çay makinesi tamiri: ısıtma, sıcak tutma ve termostat kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/airfryer-tamiri": {
    "title": "Airfryer Tamiri İstanbul",
    "description": "İstanbul airfryer tamiri: ısıtıcı, fan ve kontrol paneli sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/fritoz-tamiri": {
    "title": "Fritöz Tamiri İstanbul",
    "description": "İstanbul fritöz tamiri: ısıtma, sıcaklık ve güç kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/mutfak-robotu-tamiri": {
    "title": "Mutfak Robotu Tamiri İstanbul",
    "description": "İstanbul mutfak robotu tamiri: motor, hız, hazne ve mekanik bağlantı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/rondo-tamiri": {
    "title": "Rondo Tamiri İstanbul",
    "description": "İstanbul rondo tamiri: doğrayıcı motoru, anahtar ve kapak bağlantısı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/ekmek-kizartma-makinesi-tamiri": {
    "title": "Ekmek Kızartma Makinesi Tamiri İstanbul",
    "description": "İstanbul ekmek kızartma makinesi tamiri: ısıtıcı ve kaldırma mekanizması sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/meyve-sikacagi-tamiri": {
    "title": "Meyve Sıkacağı Tamiri İstanbul",
    "description": "İstanbul meyve sıkacağı tamiri: meyve ve narenciye sıkacağı motor ve hazne kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/ekmek-yapma-makinesi-tamiri": {
    "title": "Ekmek Yapma Makinesi Tamiri İstanbul",
    "description": "İstanbul ekmek yapma makinesi tamiri: yoğurma, ısıtma ve program sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/robot-supurge-tamiri": {
    "title": "Robot Süpürge Tamiri İstanbul",
    "description": "İstanbul robot süpürge tamiri: şarj, batarya, tekerlek, fırça ve sensör kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/dikey-supurge-tamiri": {
    "title": "Dikey Süpürge Tamiri İstanbul",
    "description": "İstanbul dikey süpürge tamiri: şarjlı süpürgede batarya, motor ve çekiş sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/buharli-temizleyici-tamiri": {
    "title": "Buharlı Temizleyici Tamiri İstanbul",
    "description": "İstanbul buharlı temizleyici tamiri: ısıtma, su akışı ve buhar çıkışı. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/utu-tamiri": {
    "title": "Ütü Tamiri İstanbul",
    "description": "İstanbul ütü tamiri: ısıtıcı, termostat, buhar ve kablo kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/kazanli-utu-tamiri": {
    "title": "Kazanlı Ütü Tamiri İstanbul",
    "description": "İstanbul kazanlı ütü tamiri: kazan, pompa, su akışı ve ısıtma sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/vantilator-tamiri": {
    "title": "Vantilatör Tamiri İstanbul",
    "description": "İstanbul vantilatör tamiri: motor, hız, salınım ve kablo kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/elektrikli-isitici-tamiri": {
    "title": "Elektrikli Isıtıcı Tamiri İstanbul",
    "description": "İstanbul elektrikli isıtıcı tamiri: ısıtma, fan, termostat ve güç sorunları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/hava-nemlendirici-tamiri": {
    "title": "Hava Nemlendirici Tamiri İstanbul",
    "description": "İstanbul hava nemlendirici tamiri: su haznesi, buhar üretimi ve güç kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/uydu-kurulumu": {
    "title": "Uydu Kurulumu İstanbul",
    "description": "İstanbul uydu kurulumu: çanak anten, montaj noktası, bağlantı ve kanal taraması. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/priz-degisimi": {
    "title": "Priz Değişimi İstanbul",
    "description": "İstanbul priz değişimi: priz tipi, montaj, bağlantı ve çalışma kontrolü. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  },
  "hizmet/elektrikci": {
    "title": "Elektrikçi İstanbul",
    "description": "İstanbul elektrikçi: elektrik arızası, priz, anahtar ve aydınlatma ihtiyaçları. Bilişim Servis ile kapsam ve ücret bilgisi alın."
  }
}
SEARCH_TARGETS_JSON
, true);
    return $targets[$pageSlug] ?? null;
}
