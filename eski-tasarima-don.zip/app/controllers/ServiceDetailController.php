<?php
/**
 * Service Detail Controller
 * Hizmet detay sayfası
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/SiteService.php';

class ServiceDetailController {
    
    public function show($slug) {
        try {
            $siteServiceModel = new SiteService();
            $service = $siteServiceModel->findBySlug($slug);
            
            if (!$service) {
                // 404 - anasayfaya yönlendir
                redirect(url());
                return;
            }
            
            // İlgili hizmetleri getir (aynı kategorideki diğer hizmetler)
            $allServices = $siteServiceModel->getAll(true);
            $relatedServices = array_filter($allServices, function($s) use ($service) {
                return $s['id'] != $service['id'];
            });
            $relatedServices = array_slice($relatedServices, 0, 3);
            
        } catch (Exception $e) {
            error_log("Service detail error: " . $e->getMessage());
            redirect(url());
            return;
        }
        
        $pageTitle = $service['name'];
        require_once APP_PATH . '/views/layouts/header.php';
        view('services/detail', [
            'service' => $service,
            'relatedServices' => $relatedServices ?? []
        ]);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
}
