<!-- Slider (Hero) - Corporate Professional Design -->
<section id="slider" class="hero-section-pro slider">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    
    <!-- Animated Grid -->
    <div class="hero-grid-pro"></div>
    
    <!-- 3D Floating Cubes -->
    <div class="cube-container">
        <div class="cube cube-1">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-2">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-3">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
    </div>
    
    <!-- Glowing Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    
    <!-- Light Beams -->
    <div class="light-beam light-beam-1"></div>
    <div class="light-beam light-beam-2"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7 hero-content-pro">
                <!-- Status Badge -->
                <div class="status-badge">
                    <span class="status-dot"></span>
                    <span class="status-text">Profesyonel Teknik Servis</span>
                </div>
                
                <!-- Main Title -->
                <h1 class="hero-title-pro" x-data="heroSlider()" x-init="init()">
                    <span class="title-main">Kurumsal Teknoloji</span>
                    <span class="title-highlight" 
                          x-show="true"
                          x-transition:enter="transition ease-out duration-700"
                          x-transition:enter-start="opacity-0 transform translate-y-10"
                          x-transition:enter-end="opacity-100 transform translate-y-0"
                          x-transition:leave="transition ease-in duration-400"
                          x-transition:leave-start="opacity-100"
                          x-transition:leave-end="opacity-0"
                          x-text="changingTexts[currentIndex]"
                          :key="currentIndex">
                    </span>
                    <span class="title-main">Çözüm Ortağınız</span>
                </h1>
                
                <!-- Description -->
                <p class="hero-desc-pro">
                    <?= getThemeSetting('hero_subtitle', 'Kurumsal ve bireysel müşterilerimize 10+ yıllık deneyimimizle profesyonel teknik servis hizmeti sunuyoruz.') ?>
                </p>
                
                <!-- CTA Buttons -->
                <div class="hero-cta-pro">
                    <a href="<?= url('hizmetler') ?>" class="cta-primary-pro">
                        <span class="cta-text">Hizmetlerimiz</span>
                        <span class="cta-arrow-pro"></span>
                    </a>
                    <a href="<?= url('iletisim') ?>" class="cta-secondary-pro">
                        <span class="cta-text">İletişime Geç</span>
                    </a>
                </div>
                
                <!-- Stats Row -->
                <div class="hero-stats-pro">
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">10+</span>
                        <span class="stat-label-pro">Yıl Deneyim</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">500+</span>
                        <span class="stat-label-pro">Mutlu Müşteri</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">24/7</span>
                        <span class="stat-label-pro">Destek</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-5 hero-visual-pro">
                <!-- 3D Tech Visual -->
                <div class="tech-visual-container">
                    <div class="tech-ring tech-ring-1"></div>
                    <div class="tech-ring tech-ring-2"></div>
                    <div class="tech-ring tech-ring-3"></div>
                    <div class="tech-core">
                        <div class="core-inner"></div>
                        <div class="core-pulse"></div>
                    </div>
                    <!-- Orbiting Elements -->
                    <div class="orbit orbit-1">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-2">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-3">
                        <div class="orbit-dot"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bottom Gradient -->
    <div class="hero-bottom-fade"></div>
</section>

<!-- Services Preview Section - Pro Design -->
<section id="services" class="services-section-pro">
    <div class="container">
        <div class="section-header-pro fade-in-up">
            <span class="section-badge-pro">
                <span class="badge-dot"></span>
                Hizmetlerimiz
            </span>
            <h2 class="section-title-pro">Sunduğumuz Profesyonel Hizmetler</h2>
            <p class="section-subtitle-pro">
                <?= getThemeSetting('services_subtitle', 'Tüm teknik servis ihtiyaçlarınız için profesyonel çözümler sunuyoruz') ?>
            </p>
        </div>
        
        <div class="services-grid-home" id="services-grid">
            <?php if (empty($services) || !is_array($services) || count($services) === 0): ?>
                <div class="empty-state-home fade-in-up">
                    <div class="empty-icon-home">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
                        </svg>
                    </div>
                    <h3>Henüz Hizmet Eklenmemiş</h3>
                    <p>Admin panelinden hizmetlerinizi ekleyebilirsiniz.</p>
                    <a href="<?= adminUrl('site-services.php') ?>" class="empty-btn-home">
                        <span>Admin Panel</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            <?php else: ?>
                <?php 
                $serviceIcons = [
                    'laptop' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg>',
                    'smartphone' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>',
                    'tablet' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M21 4H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-2 14H5V6h14v12z"/></svg>',
                    'printer' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>',
                    'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>',
                    'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>'
                ];
                ?>
                <?php foreach (array_slice($services, 0, 6) as $index => $service): ?>
                    <?php 
                    $iconName = $service['icon'] ?? 'settings';
                    $icon = $serviceIcons[$iconName] ?? $serviceIcons['settings'];
                    $slug = $service['slug'] ?? createSlug($service['name']);
                    $features = !empty($service['features']) ? json_decode($service['features'], true) : [];
                    $serviceUrl = url('hizmet/' . $slug);
                    $delay = ($index % 3) * 0.1;
                    ?>
                    <a href="<?= $serviceUrl ?>" class="service-card-home fade-in-up" style="animation-delay: <?= $delay ?>s;">
                        <div class="service-card-home-inner">
                            <!-- Glow Effect -->
                            <div class="card-glow-home"></div>
                            
                            <!-- Card Header -->
                            <div class="service-card-home-header">
                                <div class="service-icon-home">
                                    <div class="icon-bg-home"></div>
                                    <div class="icon-inner-home">
                                        <?= $icon ?>
                                    </div>
                                </div>
                                <div class="service-badge-home">Popüler</div>
                            </div>
                            
                            <!-- Card Content -->
                            <div class="service-card-home-content">
                                <h3 class="service-title-home"><?= clean($service['name']) ?></h3>
                                <?php if (!empty($service['subtitle'])): ?>
                                    <p class="service-subtitle-home"><?= clean($service['subtitle']) ?></p>
                                <?php endif; ?>
                                <?php if (!empty($service['description'])): ?>
                                    <p class="service-desc-home"><?= clean(mb_substr($service['description'], 0, 80)) ?><?= mb_strlen($service['description']) > 80 ? '...' : '' ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Card Footer -->
                            <div class="service-card-home-footer">
                                <span class="view-details-home">
                                    Detayları İncele
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </span>
                            </div>
                            
                            <!-- Hover Border Effect -->
                            <div class="card-border-effect-home"></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="services-cta-home fade-in-up">
            <a href="<?= url('hizmetler') ?>" class="btn-services-all">
                <span>Tüm Hizmetleri Gör</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    </div>
</section>

<style>
/* Services Section Pro - Homepage */
.services-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #0d0d1f 50%, #12122a 100%);
    position: relative;
    overflow: hidden;
}

.services-section-pro::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0, 212, 255, 0.3), transparent);
}

/* Section Header Pro */
.section-header-pro {
    text-align: center;
    margin-bottom: 60px;
}

.section-badge-pro {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(0, 102, 255, 0.1);
    border: 1px solid rgba(0, 102, 255, 0.3);
    padding: 8px 20px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #00D4FF;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.badge-dot {
    width: 8px;
    height: 8px;
    background: #00D4FF;
    border-radius: 50%;
    animation: pulse-dot 2s ease-in-out infinite;
}

@keyframes pulse-dot {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(1.2); }
}

.section-title-pro {
    font-size: clamp(2rem, 4vw, 2.8rem);
    font-weight: 700;
    color: white;
    margin-bottom: 16px;
    font-family: 'Poppins', sans-serif;
}

.section-subtitle-pro {
    font-size: 1.1rem;
    color: rgba(255, 255, 255, 0.6);
    max-width: 600px;
    margin: 0 auto;
    line-height: 1.7;
}

/* Services Grid Home */
.services-grid-home {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
    margin-bottom: 50px;
}

/* Service Card Home */
.service-card-home {
    text-decoration: none;
    display: block;
}

.service-card-home-inner {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 32px;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.service-card-home:hover .service-card-home-inner {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
    box-shadow: 0 25px 50px rgba(0, 102, 255, 0.15);
}

/* Card Glow Effect */
.card-glow-home {
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(0, 102, 255, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.4s ease;
    pointer-events: none;
}

.service-card-home:hover .card-glow-home {
    opacity: 1;
}

/* Card Border Effect */
.card-border-effect-home {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.service-card-home:hover .card-border-effect-home {
    transform: scaleX(1);
}

/* Service Card Header */
.service-card-home-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 24px;
}

.service-icon-home {
    position: relative;
    width: 70px;
    height: 70px;
}

.service-icon-home .icon-bg-home {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    transform: rotate(45deg);
    transition: transform 0.4s ease;
}

.service-card-home:hover .icon-bg-home {
    transform: rotate(0deg);
}

.service-icon-home .icon-inner-home {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.service-icon-home .icon-inner-home svg {
    width: 32px;
    height: 32px;
    color: #00D4FF;
}

.service-badge-home {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.1) 100%);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #10B981;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
}

.service-card-home:hover .service-badge-home {
    opacity: 1;
    transform: translateY(0);
}

/* Service Card Content */
.service-card-home-content {
    flex: 1;
}

.service-title-home {
    font-size: 1.3rem;
    font-weight: 700;
    color: white;
    margin-bottom: 8px;
    font-family: 'Poppins', sans-serif;
    transition: color 0.3s ease;
}

.service-card-home:hover .service-title-home {
    color: #00D4FF;
}

.service-subtitle-home {
    color: #00D4FF;
    font-size: 0.85rem;
    font-weight: 500;
    margin-bottom: 12px;
}

.service-desc-home {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    line-height: 1.6;
    margin: 0;
}

/* Service Card Footer */
.service-card-home-footer {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

.view-details-home {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #00D4FF;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.view-details-home svg {
    transition: transform 0.3s ease;
}

.service-card-home:hover .view-details-home svg {
    transform: translateX(5px);
}

/* Empty State */
.empty-state-home {
    grid-column: 1 / -1;
    text-align: center;
    padding: 80px 40px;
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
}

.empty-icon-home {
    color: rgba(255,255,255,0.2);
    margin-bottom: 24px;
}

.empty-state-home h3 {
    color: white;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 12px;
}

.empty-state-home p {
    color: rgba(255,255,255,0.6);
    margin-bottom: 24px;
}

.empty-btn-home {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 12px 24px;
    border-radius: 10px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.empty-btn-home:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0, 102, 255, 0.4);
    color: white;
}

/* Services CTA */
.services-cta-home {
    text-align: center;
}

.btn-services-all {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 16px 40px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 1rem;
    text-decoration: none;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-services-all::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s ease;
}

.btn-services-all:hover::before {
    left: 100%;
}

.btn-services-all:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(0, 102, 255, 0.4);
    color: white;
}

.btn-services-all svg {
    transition: transform 0.3s ease;
}

.btn-services-all:hover svg {
    transform: translateX(5px);
}

/* Responsive */
@media (max-width: 1200px) {
    .services-grid-home {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .services-section-pro {
        padding: 60px 0;
    }
    
    .services-grid-home {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .section-title-pro {
        font-size: 1.8rem;
    }
    
    .service-card-home-inner {
        padding: 24px;
    }
    
    .btn-services-all {
        width: 100%;
        justify-content: center;
    }
}

/* ========================================
   WHY CHOOSE US SECTION PRO
   ======================================== */
.why-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #12122a 0%, #0a0a1a 100%);
    position: relative;
}

.features-grid-pro {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
}

.feature-card-pro {
    position: relative;
}

.feature-card-inner {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 32px 28px;
    text-align: center;
    height: 100%;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}

.feature-card-pro:hover .feature-card-inner {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
    box-shadow: 0 25px 50px rgba(0, 102, 255, 0.15);
}

.feature-icon-pro {
    position: relative;
    width: 80px;
    height: 80px;
    margin: 0 auto 24px;
}

.feature-icon-pro .icon-ring {
    position: absolute;
    inset: 0;
    border: 2px solid rgba(0, 212, 255, 0.3);
    border-radius: 50%;
    animation: pulse-ring 2s ease-out infinite;
}

@keyframes pulse-ring {
    0% { transform: scale(1); opacity: 1; }
    100% { transform: scale(1.3); opacity: 0; }
}

.feature-icon-pro svg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 36px;
    height: 36px;
    color: #00D4FF;
}

.feature-title-pro {
    font-size: 1.2rem;
    font-weight: 700;
    color: white;
    margin-bottom: 12px;
    font-family: 'Poppins', sans-serif;
}

.feature-desc-pro {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    line-height: 1.6;
    margin-bottom: 20px;
}

.feature-highlight {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding-top: 16px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

.highlight-number {
    font-size: 1.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.highlight-text {
    color: rgba(255,255,255,0.5);
    font-size: 0.85rem;
}

/* ========================================
   STATISTICS SECTION PRO
   ======================================== */
.stats-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #0d0d1f 50%, #12122a 100%);
    position: relative;
    overflow: hidden;
}

.stats-section-pro::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0, 212, 255, 0.3), transparent);
}

.stats-bg-elements {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.stats-orb {
    position: absolute;
    border-radius: 50%;
    background: rgba(0, 102, 255, 0.1);
    filter: blur(80px);
}

.stats-orb-1 {
    width: 400px;
    height: 400px;
    top: -100px;
    right: -100px;
}

.stats-orb-2 {
    width: 300px;
    height: 300px;
    bottom: -50px;
    left: -50px;
}

.stats-grid-pro {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
}

.stat-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 32px 24px;
    text-align: center;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}

.stat-card-pro::before {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.stat-card-pro:hover {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
    box-shadow: 0 25px 50px rgba(0, 102, 255, 0.15);
}

.stat-card-pro:hover::before {
    transform: scaleX(1);
}

.stat-icon-pro {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    position: relative;
}

.stat-icon-pro::after {
    content: '';
    position: absolute;
    inset: -2px;
    border-radius: 22px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.3));
    z-index: -1;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.stat-card-pro:hover .stat-icon-pro::after {
    opacity: 1;
}

.stat-icon-pro svg {
    width: 32px;
    height: 32px;
    color: #00D4FF;
}

.stat-number-pro {
    font-size: 2.8rem;
    font-weight: 800;
    background: linear-gradient(135deg, #ffffff 0%, #00D4FF 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 8px;
    font-family: 'Poppins', sans-serif;
}

.stat-number-pro .suffix {
    font-size: 1.8rem;
}

.stat-label-pro {
    color: rgba(255,255,255,0.7);
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 16px;
}

.stat-bar-pro {
    height: 4px;
    background: rgba(255,255,255,0.1);
    border-radius: 2px;
    overflow: hidden;
}

.stat-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    border-radius: 2px;
    transition: width 1s ease;
}

/* ========================================
   PROCESS SECTION PRO
   ======================================== */
.process-section-pro {
    padding: 100px 0;
    background: #0a0a1a;
    position: relative;
}

.process-timeline-pro {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
    position: relative;
    margin-top: 60px;
}

.timeline-line-pro {
    position: absolute;
    top: 60px;
    left: 10%;
    right: 10%;
    height: 2px;
    background: linear-gradient(90deg, #0066FF, #00D4FF, #0066FF, #00D4FF);
    background-size: 200% 100%;
    animation: gradient-move 3s linear infinite;
}

@keyframes gradient-move {
    0% { background-position: 0% 0%; }
    100% { background-position: 200% 0%; }
}

.process-step-pro {
    text-align: center;
    position: relative;
}

.step-number-pro {
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.3));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 20px;
}

.step-content-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 30px 24px;
    transition: all 0.4s ease;
}

.process-step-pro:hover .step-content-pro {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
}

.step-icon-pro {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}

.step-icon-pro svg {
    width: 28px;
    height: 28px;
    color: #00D4FF;
}

.step-content-pro h4 {
    color: white;
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 10px;
    font-family: 'Poppins', sans-serif;
}

.step-content-pro p {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    line-height: 1.6;
    margin: 0;
}

/* ========================================
   CTA SECTION PRO
   ======================================== */
.cta-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
}

.cta-wrapper-pro {
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.1) 100%);
    border: 1px solid rgba(0, 212, 255, 0.3);
    border-radius: 30px;
    padding: 80px;
    position: relative;
    overflow: hidden;
    text-align: center;
}

.cta-bg-elements {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.cta-circle {
    position: absolute;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.1));
}

.cta-circle-1 {
    width: 300px;
    height: 300px;
    top: -150px;
    right: -100px;
}

.cta-circle-2 {
    width: 200px;
    height: 200px;
    bottom: -100px;
    left: -50px;
}

.cta-circle-3 {
    width: 100px;
    height: 100px;
    top: 50%;
    left: 20%;
    opacity: 0.5;
}

.cta-grid {
    position: absolute;
    inset: 0;
    background-image: 
        linear-gradient(rgba(0, 212, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0, 212, 255, 0.03) 1px, transparent 1px);
    background-size: 50px 50px;
}

.cta-content-pro {
    position: relative;
    z-index: 1;
}

.cta-badge {
    display: inline-block;
    background: rgba(0, 212, 255, 0.2);
    border: 1px solid rgba(0, 212, 255, 0.4);
    color: #00D4FF;
    padding: 8px 20px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 24px;
}

.cta-title-pro {
    font-size: 2.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 16px;
    font-family: 'Poppins', sans-serif;
}

.cta-desc-pro {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 40px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.cta-buttons-pro {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.cta-btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(0, 102, 255, 0.4);
    color: white;
}

.cta-btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-secondary:hover {
    background: rgba(255,255,255,0.2);
    transform: translateY(-3px);
    color: white;
}

/* ========================================
   PARTNERS SECTION PRO
   ======================================== */
.partners-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #12122a 0%, #0d0d1f 100%);
    overflow: hidden;
    position: relative;
}

.partners-section-pro::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0, 212, 255, 0.3), transparent);
}

.partners-section-pro .section-header-pro {
    margin-bottom: 50px;
}

/* Decorative elements */
.partners-section-pro::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 200px;
    height: 200px;
    background: radial-gradient(circle, rgba(0, 102, 255, 0.1) 0%, transparent 70%);
    pointer-events: none;
}

.partners-slider-pro {
    position: relative;
    overflow: hidden;
    padding: 30px 0;
    mask-image: linear-gradient(to right, transparent, black 5%, black 95%, transparent);
    -webkit-mask-image: linear-gradient(to right, transparent, black 5%, black 95%, transparent);
}

.partners-track {
    display: flex;
    gap: 40px;
    animation: scroll-partners 25s linear infinite;
    width: fit-content;
}

.partners-track:hover {
    animation-play-state: paused;
}

@keyframes scroll-partners {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

.partner-item-pro {
    flex-shrink: 0;
}

.partner-link-pro {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 200px;
    height: 100px;
    background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 24px;
    transition: all 0.4s ease;
    text-decoration: none;
    position: relative;
    overflow: hidden;
}

.partner-link-pro::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.1) 0%, rgba(0, 212, 255, 0.05) 100%);
    opacity: 0;
    transition: opacity 0.4s ease;
}

.partner-link-pro::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transform: scaleX(0);
    transform-origin: center;
    transition: transform 0.4s ease;
}

.partner-link-pro:hover {
    border-color: rgba(0, 212, 255, 0.4);
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 102, 255, 0.2);
}

.partner-link-pro:hover::before {
    opacity: 1;
}

.partner-link-pro:hover::after {
    transform: scaleX(1);
}

.partner-logo-pro {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    filter: grayscale(100%) brightness(1.5);
    opacity: 0.5;
    transition: all 0.4s ease;
    position: relative;
    z-index: 1;
}

.partner-link-pro:hover .partner-logo-pro {
    filter: grayscale(0%) brightness(1);
    opacity: 1;
    transform: scale(1.05);
}

.partner-text {
    color: rgba(255,255,255,0.5);
    font-size: 0.95rem;
    font-weight: 600;
    position: relative;
    z-index: 1;
    transition: all 0.3s ease;
}

.partner-link-pro:hover .partner-text,
.partner-link-pro:hover .partner-text span {
    color: #00D4FF;
}

/* Partners Wrapper & Glow Effects */
.partners-wrapper-pro {
    position: relative;
}

.partners-glow {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 150px;
    height: 100%;
    z-index: 2;
    pointer-events: none;
}

.partners-glow-left {
    left: 0;
    background: linear-gradient(to right, #0d0d1f 0%, transparent 100%);
}

.partners-glow-right {
    right: 0;
    background: linear-gradient(to left, #0d0d1f 0%, transparent 100%);
}

/* ========================================
   RESPONSIVE ADJUSTMENTS
   ======================================== */
@media (max-width: 1200px) {
    .features-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .stats-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .process-timeline-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .timeline-line-pro {
        display: none;
    }
}

@media (max-width: 768px) {
    .why-section-pro,
    .stats-section-pro,
    .process-section-pro,
    .cta-section-pro,
    .partners-section-pro {
        padding: 60px 0;
    }
    
    .features-grid-pro,
    .stats-grid-pro,
    .process-timeline-pro {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .cta-wrapper-pro {
        padding: 40px 24px;
    }
    
    .cta-title-pro {
        font-size: 1.8rem;
    }
    
    .cta-buttons-pro {
        flex-direction: column;
    }
    
    .cta-btn-primary,
    .cta-btn-secondary {
        width: 100%;
        justify-content: center;
    }
    
    .partner-link-pro {
        width: 140px;
        height: 60px;
    }
}
</style>

<!-- Why Choose Us Section - Pro Design -->
<section class="why-section-pro">
    <div class="container">
        <div class="section-header-pro fade-in-up">
            <span class="section-badge-pro">
                <span class="badge-dot"></span>
                Neden Bizi Seçmelisiniz
            </span>
            <h2 class="section-title-pro">Fark Yaratan Hizmet Anlayışımız</h2>
            <p class="section-subtitle-pro">
                Profesyonel hizmet anlayışımız ve müşteri memnuniyeti odaklı yaklaşımımızla sektörde öne çıkıyoruz.
            </p>
        </div>
        
        <div class="features-grid-pro">
            <div class="feature-card-pro fade-in-up" style="animation-delay: 0s;">
                <div class="feature-card-inner">
                    <div class="feature-icon-pro">
                        <div class="icon-ring"></div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M13 2.05v2.02c3.95.49 7 3.85 7 7.93 0 3.21-1.92 6-4.72 7.28L13 17v5h5l-1.22-1.22C19.91 19.07 22 15.76 22 12c0-5.18-3.95-9.45-9-9.95zM11 2.05C5.94 2.55 2 6.81 2 12c0 3.76 2.09 7.07 5.22 8.78L6 22h5v-5l-2.28 2.28C6.09 18 4.18 15.21 4.18 12c0-4.08 3.04-7.44 7-7.93V2.05h-.18z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title-pro">Hızlı Tamir Süreci</h3>
                    <p class="feature-desc-pro">
                        Sorunlarınıza hızlıca müdahale ediyor, en kısa sürede çözüm sunuyoruz.
                    </p>
                    <div class="feature-highlight">
                        <span class="highlight-number">2-4</span>
                        <span class="highlight-text">Saat İçinde</span>
                    </div>
                </div>
            </div>
            
            <div class="feature-card-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="feature-card-inner">
                    <div class="feature-icon-pro">
                        <div class="icon-ring"></div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title-pro">Ücretsiz Teşhis</h3>
                    <p class="feature-desc-pro">
                        Tüm cihazlarınız için ücretsiz teşhis hizmeti sunuyoruz.
                    </p>
                    <div class="feature-highlight">
                        <span class="highlight-number">%100</span>
                        <span class="highlight-text">Ücretsiz</span>
                    </div>
                </div>
            </div>
            
            <div class="feature-card-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="feature-card-inner">
                    <div class="feature-icon-pro">
                        <div class="icon-ring"></div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title-pro">Hızlı Teslimat</h3>
                    <p class="feature-desc-pro">
                        Tamir işlemlerinizi hızlıca tamamlayıp size teslim ediyoruz.
                    </p>
                    <div class="feature-highlight">
                        <span class="highlight-number">24</span>
                        <span class="highlight-text">Saat Teslimat</span>
                    </div>
                </div>
            </div>
            
            <div class="feature-card-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="feature-card-inner">
                    <div class="feature-icon-pro">
                        <div class="icon-ring"></div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title-pro">Garanti</h3>
                    <p class="feature-desc-pro">
                        Tüm tamir işlemlerimizde garanti sunuyoruz.
                    </p>
                    <div class="feature-highlight">
                        <span class="highlight-number">6</span>
                        <span class="highlight-text">Ay Garanti</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistics Section - Pro Design -->
<section class="stats-section-pro">
    <div class="stats-bg-elements">
        <div class="stats-orb stats-orb-1"></div>
        <div class="stats-orb stats-orb-2"></div>
    </div>
    <div class="container">
        <div class="section-header-pro fade-in-up">
            <span class="section-badge-pro">
                <span class="badge-dot"></span>
                Rakamlarla Biz
            </span>
            <h2 class="section-title-pro">Tecrübemizle Fark Yaratıyoruz</h2>
        </div>
        
        <div class="stats-grid-pro">
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm4.2 14.2L11 13V7h1.5v5.2l4.5 2.7-.8 1.3z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="10" data-suffix="+">
                    <span class="counter">0</span><span class="suffix">+</span>
                </div>
                <div class="stat-label-pro">Yıllık Tecrübe</div>
                <div class="stat-bar-pro"><div class="stat-bar-fill" style="width: 100%;"></div></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="500" data-suffix="+">
                    <span class="counter">0</span><span class="suffix">+</span>
                </div>
                <div class="stat-label-pro">Mutlu Müşteri</div>
                <div class="stat-bar-pro"><div class="stat-bar-fill" style="width: 85%;"></div></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="1000" data-suffix="+">
                    <span class="counter">0</span><span class="suffix">+</span>
                </div>
                <div class="stat-label-pro">Tamamlanan Proje</div>
                <div class="stat-bar-pro"><div class="stat-bar-fill" style="width: 95%;"></div></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="24" data-suffix="/7">
                    <span class="counter">0</span><span class="suffix">/7</span>
                </div>
                <div class="stat-label-pro">Kesintisiz Destek</div>
                <div class="stat-bar-pro"><div class="stat-bar-fill" style="width: 100%;"></div></div>
            </div>
        </div>
    </div>
</section>

<!-- Process Section - Pro Design -->
<section class="process-section-pro">
    <div class="container">
        <div class="section-header-pro fade-in-up">
            <span class="section-badge-pro">
                <span class="badge-dot"></span>
                Süreç
            </span>
            <h2 class="section-title-pro">Nasıl Çalışıyoruz?</h2>
            <p class="section-subtitle-pro">
                Basit ve hızlı süreçlerimizle size en iyi hizmeti sunuyoruz.
            </p>
        </div>
        
        <div class="process-timeline-pro">
            <div class="timeline-line-pro"></div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0s;">
                <div class="step-number-pro">01</div>
                <div class="step-content-pro">
                    <div class="step-icon-pro">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                    </div>
                    <h4>İletişime Geçin</h4>
                    <p>Bize ulaşın ve sorununuzu anlatın. Ücretsiz teşhis için randevu alın.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="step-number-pro">02</div>
                <div class="step-content-pro">
                    <div class="step-icon-pro">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>
                        </svg>
                    </div>
                    <h4>Teşhis</h4>
                    <p>Uzman ekibimiz cihazınızı inceler ve sorunu tespit eder.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="step-number-pro">03</div>
                <div class="step-content-pro">
                    <div class="step-icon-pro">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>
                        </svg>
                    </div>
                    <h4>Onay & Tamir</h4>
                    <p>Onayınızın ardından profesyonel tamir işlemi başlar.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="step-number-pro">04</div>
                <div class="step-content-pro">
                    <div class="step-icon-pro">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                    </div>
                    <h4>Teslimat</h4>
                    <p>Tamir tamamlandıktan sonra cihazınız size teslim edilir.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section - Pro Design -->
<section class="cta-section-pro">
    <div class="container">
        <div class="cta-wrapper-pro fade-in-up">
            <div class="cta-bg-elements">
                <div class="cta-circle cta-circle-1"></div>
                <div class="cta-circle cta-circle-2"></div>
                <div class="cta-circle cta-circle-3"></div>
                <div class="cta-grid"></div>
            </div>
            <div class="cta-content-pro">
                <span class="cta-badge">Hemen Başlayın</span>
                <h2 class="cta-title-pro">İşinize Geri Dönmenize Yardımcı Olacağız</h2>
                <p class="cta-desc-pro">
                    Teknoloji sorunlarınız için profesyonel çözümler sunuyoruz. Hızlı, güvenilir ve uygun fiyatlı hizmetlerimizle yanınızdayız.
                </p>
                <div class="cta-buttons-pro">
                    <a href="<?= url('iletisim') ?>" class="cta-btn-primary">
                        <span>Ücretsiz Teşhis İste</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="tel:<?= getThemeSetting('contact_phone', '05548634870') ?>" class="cta-btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                        <span>Hemen Ara</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Partners Section - Pro Design -->
<?php if (!empty($references)): ?>
<section class="partners-section-pro">
    <div class="container">
        <div class="section-header-pro fade-in-up">
            <span class="section-badge-pro">
                <span class="badge-dot"></span>
                Referanslarımız
            </span>
            <h2 class="section-title-pro">Bize Güvenen Firmalar</h2>
            <p class="section-subtitle-pro">
                Kurumsal ve bireysel müşterilerimizle güvene dayalı iş ortaklıkları kuruyoruz.
            </p>
        </div>
        
        <div class="partners-wrapper-pro">
            <div class="partners-glow partners-glow-left"></div>
            <div class="partners-glow partners-glow-right"></div>
            <div class="partners-slider-pro">
            <div class="partners-track">
                <?php foreach ($references as $reference): ?>
                    <div class="partner-item-pro">
                        <?php if (!empty($reference['logo_url'])): ?>
                            <?php if (!empty($reference['link'])): ?>
                                <a href="<?= clean($reference['link']) ?>" target="_blank" rel="noopener noreferrer" class="partner-link-pro">
                                    <img src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" alt="<?= clean($reference['name']) ?>" class="partner-logo-pro">
                                </a>
                            <?php else: ?>
                                <div class="partner-link-pro">
                                    <img src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" alt="<?= clean($reference['name']) ?>" class="partner-logo-pro">
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="partner-link-pro partner-text">
                                <span><?= clean($reference['name']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <!-- Duplicate for seamless loop -->
                <?php foreach ($references as $reference): ?>
                    <div class="partner-item-pro">
                        <?php if (!empty($reference['logo_url'])): ?>
                            <?php if (!empty($reference['link'])): ?>
                                <a href="<?= clean($reference['link']) ?>" target="_blank" rel="noopener noreferrer" class="partner-link-pro">
                                    <img src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" alt="<?= clean($reference['name']) ?>" class="partner-logo-pro">
                                </a>
                            <?php else: ?>
                                <div class="partner-link-pro">
                                    <img src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" alt="<?= clean($reference['name']) ?>" class="partner-logo-pro">
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="partner-link-pro partner-text">
                                <span><?= clean($reference['name']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
// Hero slider için Alpine.js data
if (typeof Alpine !== 'undefined') {
    Alpine.data('heroSlider', () => ({
        changingTexts: [
            'BİLGİSAYAR TAMİRİ',
            'TELEFON TAMİRİ',
            'TABLET TAMİRİ',
            'YAZICI TAMİRİ',
            'FORMAT',
            'YAZILIM KURULUMU',
            'PARÇA DEĞİŞİMİ',
            'KURUMSAL & BİREYSEL TEKNİK SERVİS'
        ],
        currentIndex: 0,
        init() {
            this.currentIndex = 0;
            setInterval(() => {
                this.currentIndex = (this.currentIndex + 1) % this.changingTexts.length;
            }, 3000);
        }
    }));
}

// Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number-pro');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const counterEl = counter.querySelector('.counter');
        if (!counterEl || counterEl.classList.contains('counted')) return;
        
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += step;
            if (current < target) {
                counterEl.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                counterEl.textContent = target;
                counterEl.classList.add('counted');
            }
        };
        
        updateCounter();
    });
}

// Intersection Observer for counter animation
const statsSection = document.querySelector('.stats-section-pro');
if (statsSection) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    
    observer.observe(statsSection);
}

// Fade in animation on scroll
const fadeElements = document.querySelectorAll('.fade-in-up');
const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

fadeElements.forEach(el => fadeObserver.observe(el));
</script>
