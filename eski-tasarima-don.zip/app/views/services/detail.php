<!-- Slider (Hero) - Service detail, same design as homepage -->
<section id="slider" class="hero-section-pro hero-section-service slider">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    <div class="hero-grid-pro"></div>
    <div class="cube-container">
        <div class="cube cube-1">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-2">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-3">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
    </div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    <div class="light-beam light-beam-1"></div>
    <div class="light-beam light-beam-2"></div>

    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7 hero-content-pro">
                <div class="status-badge">
                    <span class="status-dot"></span>
                    <span class="status-text">Hizmet</span>
                </div>
                <h1 class="hero-title-pro hero-title-service">
                    <span class="title-main"><?= clean($service['name']) ?></span>
                </h1>
                <?php if (!empty($service['subtitle'])): ?>
                    <p class="hero-desc-pro"><?= clean($service['subtitle']) ?></p>
                <?php endif; ?>
                <div class="hero-cta-pro">
                    <a href="<?= url('iletisim') ?>" class="cta-primary-pro">
                        <span class="cta-text">Teklif Al</span>
                        <span class="cta-arrow-pro"></span>
                    </a>
                    <a href="<?= url('hizmetler') ?>" class="cta-secondary-pro">
                        <span class="cta-text">Tüm Hizmetler</span>
                    </a>
                </div>
                <div class="hero-stats-pro">
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">10+</span>
                        <span class="stat-label-pro">Yıl Deneyim</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">500+</span>
                        <span class="stat-label-pro">Mutlu Müşteri</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">24/7</span>
                        <span class="stat-label-pro">Destek</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 hero-visual-pro">
                <div class="tech-visual-container">
                    <div class="tech-ring tech-ring-1"></div>
                    <div class="tech-ring tech-ring-2"></div>
                    <div class="tech-ring tech-ring-3"></div>
                    <div class="tech-core">
                        <div class="core-inner"></div>
                        <div class="core-pulse"></div>
                    </div>
                    <div class="orbit orbit-1"><div class="orbit-dot"></div></div>
                    <div class="orbit orbit-2"><div class="orbit-dot"></div></div>
                    <div class="orbit orbit-3"><div class="orbit-dot"></div></div>
                </div>
            </div>
        </div>
    </div>
    <div class="hero-bottom-fade"></div>
</section>

<!-- Service Description -->
<section class="about-section service-detail-section">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-lg-12 fade-in-up">
                <div class="service-detail-content">
                    <div class="section-header-inline">
                        <span class="section-label-small">Hizmet Detayları</span>
                        <h2 class="section-title-inline"><?= clean($service['name']) ?> Hakkında</h2>
                    </div>
                    
                    <?php if (!empty($service['description'])): ?>
                        <div class="service-description-text">
                            <?= nl2br(clean($service['description'])) ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php 
                    $features = !empty($service['features']) ? json_decode($service['features'], true) : [];
                    if (!empty($features)): 
                    ?>
                        <div class="service-features-section">
                            <h3 class="features-title">
                                <span class="features-icon">✓</span>
                                Hizmet Kapsamı
                            </h3>
                            <div class="features-grid-modern">
                                <?php foreach ($features as $index => $feature): ?>
                                    <div class="feature-item-modern">
                                        <div class="feature-check">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                                <polyline points="20 6 9 17 4 12"></polyline>
                                            </svg>
                                        </div>
                                        <span><?= clean($feature) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose This Service -->
<?php if (!empty($features)): ?>
<section class="why-section" style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Neden Bu Hizmeti Seçmelisiniz</span>
            <h2 class="section-title">Size Özel Avantajlar</h2>
            <p class="section-subtitle">
                <?= clean($service['name']) ?> hizmetimizle size sunduğumuz özel avantajlar ve faydalar
            </p>
        </div>
        
        <div class="features-grid">
            <?php 
            $benefitIcons = ['✓', '⚡', '🛡️', '⭐', '🚀', '💎', '🎯', '💼'];
            foreach ($features as $index => $feature): 
                $icon = $benefitIcons[$index % count($benefitIcons)];
            ?>
                <div class="feature-box fade-in-up stagger-<?= ($index % 4) + 1 ?>" style="background: white; border-radius: 20px; padding: 35px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 1px solid rgba(0,102,255,0.1);">
                    <div class="feature-icon" style="font-size: 3rem; margin-bottom: 20px; display: flex; align-items: center; justify-content: center; width: 80px; height: 80px; background: linear-gradient(135deg, rgba(0,102,255,0.1), rgba(0,212,255,0.1)); border-radius: 50%; margin: 0 auto 20px;">
                        <?= $icon ?>
                    </div>
                    <h3 class="feature-title" style="font-size: 1.3rem; margin-bottom: 12px;"><?= clean($feature) ?></h3>
                    <p class="feature-description" style="color: #666; line-height: 1.7;">
                        Profesyonel ekibimiz ve yılların tecrübesi ile size en iyi hizmeti sunuyoruz. Müşteri memnuniyeti bizim önceliğimizdir.
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Process Timeline -->
<section class="process-section" style="background: var(--white);">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Süreç</span>
            <h2 class="section-title">Nasıl Çalışıyoruz</h2>
            <p class="section-subtitle">
                <?= clean($service['name']) ?> hizmetimiz için basit ve hızlı süreçlerimizle size en iyi hizmeti sunuyoruz.
            </p>
        </div>
        
        <div class="process-grid">
            <div class="process-step fade-in-up stagger-1" style="background: white; border-radius: 20px; padding: 35px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); transition: all 0.3s ease;">
                <div class="process-number" style="width: 70px; height: 70px; background: linear-gradient(135deg, #0066FF, #00D4FF); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; font-weight: 900; margin: 0 auto 20px; box-shadow: 0 5px 15px rgba(0,102,255,0.3);">1</div>
                <h3 class="process-title" style="font-size: 1.3rem; margin-bottom: 12px;">İletişime Geçin</h3>
                <p class="process-description" style="color: #666; line-height: 1.7;">
                    Bize ulaşın ve <?= strtolower(clean($service['name'])) ?> ihtiyacınızı anlatın. Ücretsiz teşhis için randevu alın.
                </p>
            </div>
            <div class="process-step fade-in-up stagger-2" style="background: white; border-radius: 20px; padding: 35px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); transition: all 0.3s ease;">
                <div class="process-number" style="width: 70px; height: 70px; background: linear-gradient(135deg, #0066FF, #00D4FF); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; font-weight: 900; margin: 0 auto 20px; box-shadow: 0 5px 15px rgba(0,102,255,0.3);">2</div>
                <h3 class="process-title" style="font-size: 1.3rem; margin-bottom: 12px;">Teşhis & Değerlendirme</h3>
                <p class="process-description" style="color: #666; line-height: 1.7;">
                    Uzman ekibimiz durumu inceler ve size en uygun çözümü sunar. Detaylı analiz sonrası size bilgi verilir.
                </p>
            </div>
            <div class="process-step fade-in-up stagger-3" style="background: white; border-radius: 20px; padding: 35px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); transition: all 0.3s ease;">
                <div class="process-number" style="width: 70px; height: 70px; background: linear-gradient(135deg, #0066FF, #00D4FF); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; font-weight: 900; margin: 0 auto 20px; box-shadow: 0 5px 15px rgba(0,102,255,0.3);">3</div>
                <h3 class="process-title" style="font-size: 1.3rem; margin-bottom: 12px;">Onay & Uygulama</h3>
                <p class="process-description" style="color: #666; line-height: 1.7;">
                    Onayınızın ardından profesyonel hizmet süreci başlar. Tüm işlemler şeffaf bir şekilde yürütülür.
                </p>
            </div>
            <div class="process-step fade-in-up stagger-4" style="background: white; border-radius: 20px; padding: 35px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); transition: all 0.3s ease;">
                <div class="process-number" style="width: 70px; height: 70px; background: linear-gradient(135deg, #0066FF, #00D4FF); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; font-weight: 900; margin: 0 auto 20px; box-shadow: 0 5px 15px rgba(0,102,255,0.3);">4</div>
                <h3 class="process-title" style="font-size: 1.3rem; margin-bottom: 12px;">Teslimat & Garanti</h3>
                <p class="process-description" style="color: #666; line-height: 1.7;">
                    Hizmet tamamlandıktan sonra size teslim edilir ve garanti kapsamına alınır. Memnuniyetiniz bizim için önemlidir.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<?php 
$faq = !empty($service['faq']) ? json_decode($service['faq'], true) : [];
if (!empty($faq) && is_array($faq)): 
?>
<section class="about-section" style="background: #f8f9fa;">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Sıkça Sorulan Sorular</span>
            <h2 class="section-title"><?= clean($service['name']) ?> Hakkında Sorular</h2>
            <p class="section-subtitle">
                <?= clean($service['name']) ?> hizmetimiz hakkında en çok merak edilen sorular ve cevapları
            </p>
        </div>
        
        <div class="faq-container">
            <?php foreach ($faq as $index => $item): 
                if (!isset($item['question']) || !isset($item['answer'])) continue;
            ?>
                <div class="faq-item fade-in-up stagger-<?= ($index % 4) + 1 ?>">
                    <div class="faq-question" onclick="toggleFaq(this)" role="button" tabindex="0" aria-expanded="false">
                        <span><?= clean($item['question']) ?></span>
                        <span class="faq-icon">+</span>
                    </div>
                    <div class="faq-answer">
                        <div>
                            <?= nl2br(clean($item['answer'])) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
function toggleFaq(element) {
    const faqItem = element.closest('.faq-item');
    const isActive = faqItem.classList.contains('active');
    
    // Tüm FAQ'ları kapat
    document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
        const q = item.querySelector('.faq-question');
        if (q) q.setAttribute('aria-expanded', 'false');
    });
    
    // Tıklanan FAQ'yı aç (eğer kapalıysa)
    if (!isActive) {
        faqItem.classList.add('active');
        element.setAttribute('aria-expanded', 'true');
    }
}

// FAQ'ları klavye ile de açıp kapatabilme
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        if (question) {
            question.setAttribute('tabindex', '0');
            question.setAttribute('role', 'button');
            question.setAttribute('aria-expanded', 'false');
            
            question.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleFaq(this);
                }
            });
        }
    });
});
</script>
<?php endif; ?>

<!-- Related Services -->
<?php if (!empty($relatedServices)): ?>
<section class="services-section" style="background: var(--white);">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Diğer Hizmetler</span>
            <h2 class="section-title">İlgili Hizmetlerimiz</h2>
            <p class="section-subtitle">
                Size daha fazla yardımcı olabilecek diğer hizmetlerimizi keşfedin.
            </p>
        </div>
        
        <div class="services-grid">
            <?php 
            $serviceIcons = [
                'laptop' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg>',
                'smartphone' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>',
                'tablet' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M21 4H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-2 14H5V6h14v12z"/></svg>',
                'printer' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>',
                'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>',
                'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>'
            ];
            ?>
            <?php foreach ($relatedServices as $related): ?>
                <?php 
                $iconName = $related['icon'] ?? 'settings';
                $icon = $serviceIcons[$iconName] ?? $serviceIcons['settings'];
                $slug = $related['slug'] ?? createSlug($related['name']);
                ?>
                <div class="service-card">
                    <div class="service-icon-wrapper">
                        <div class="service-icon">
                            <?= $icon ?>
                        </div>
                    </div>
                    <h3 class="service-title"><?= clean($related['name']) ?></h3>
                    <?php if (!empty($related['subtitle'])): ?>
                        <p class="service-subtitle"><?= clean($related['subtitle']) ?></p>
                    <?php endif; ?>
                    <a href="<?= url('hizmet/' . $slug) ?>" class="card-link">
                        Detayları Gör
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA Section -->
<section class="cta-section" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);">
    <div class="container">
        <div class="cta-content fade-in-up" style="text-align: center; max-width: 800px; margin: 0 auto;">
            <h2 class="cta-title" style="font-size: 2.5rem; margin-bottom: 20px;"><?= clean($service['name']) ?> için teklif almak ister misiniz?</h2>
            <p class="cta-description" style="font-size: 1.2rem; margin-bottom: 40px; opacity: 0.95;">
                Hemen iletişime geçin, size özel teklif hazırlayalım. Ücretsiz teşhis ve danışmanlık hizmetimizden yararlanın.
            </p>
            <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                <a href="<?= url('iletisim') ?>" class="btn btn-secondary btn-lg" style="padding: 16px 40px; font-size: 1.1rem; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.2);">Teklif Al</a>
                <a href="tel:05548634870" class="btn btn-outline btn-lg" style="background: rgba(255,255,255,0.1); color: white; border: 2px solid white; padding: 16px 40px; font-size: 1.1rem; border-radius: 12px; backdrop-filter: blur(10px);">📞 Hemen Ara</a>
            </div>
        </div>
    </div>
</section>
