<!-- Services Page Hero - Professional Design -->
<section class="hero-section-pro services-hero">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    
    <!-- Animated Grid -->
    <div class="hero-grid-pro"></div>
    
    <!-- 3D Floating Cubes -->
    <div class="cube-container">
        <div class="cube cube-1">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-2">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
    </div>
    
    <!-- Glowing Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    
    <!-- Light Beams -->
    <div class="light-beam light-beam-1"></div>
    <div class="light-beam light-beam-2"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content-pro">
                <!-- Status Badge -->
                <div class="status-badge">
                    <span class="status-dot"></span>
                    <span class="status-text">Profesyonel Teknik Servis</span>
                </div>
                
                <!-- Main Title -->
                <h1 class="hero-title-pro services-title">
                    <span class="title-main">Tüm Teknoloji</span>
                    <span class="title-highlight">HİZMETLERİMİZ</span>
                    <span class="title-main">Tek Çatı Altında</span>
                </h1>
                
                <!-- Description -->
                <p class="hero-desc-pro">
                    Bilgisayar, telefon, tablet ve yazıcı tamirinden yazılım kurulumuna kadar tüm teknik servis ihtiyaçlarınız için profesyonel çözümler sunuyoruz.
                </p>
                
                <!-- Quick Stats -->
                <div class="hero-stats-pro">
                    <div class="stat-item-pro">
                        <span class="stat-number-pro"><?= count($services ?? []) ?>+</span>
                        <span class="stat-label-pro">Hizmet</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">%100</span>
                        <span class="stat-label-pro">Memnuniyet</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">24/7</span>
                        <span class="stat-label-pro">Destek</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 hero-visual-pro">
                <!-- 3D Tech Visual -->
                <div class="tech-visual-container services-visual">
                    <div class="tech-ring tech-ring-1"></div>
                    <div class="tech-ring tech-ring-2"></div>
                    <div class="tech-ring tech-ring-3"></div>
                    <div class="tech-core">
                        <div class="core-inner">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="currentColor" style="color: white;">
                                <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>
                            </svg>
                        </div>
                        <div class="core-pulse"></div>
                    </div>
                    <!-- Orbiting Elements -->
                    <div class="orbit orbit-1">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-2">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-3">
                        <div class="orbit-dot"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bottom Gradient -->
    <div class="hero-bottom-fade"></div>
</section>

<!-- Services Filter Section -->
<section class="services-filter-section">
    <div class="container">
        <div class="filter-wrapper-pro fade-in-up">
            <div class="filter-label">Kategoriler:</div>
            <div class="filter-buttons">
                <button class="filter-btn-pro active" data-filter="all">
                    <span>Tümü</span>
                </button>
                <button class="filter-btn-pro" data-filter="computer">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/>
                    </svg>
                    <span>Bilgisayar</span>
                </button>
                <button class="filter-btn-pro" data-filter="mobile">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/>
                    </svg>
                    <span>Telefon & Tablet</span>
                </button>
                <button class="filter-btn-pro" data-filter="printer">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/>
                    </svg>
                    <span>Yazıcı</span>
                </button>
                <button class="filter-btn-pro" data-filter="software">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/>
                    </svg>
                    <span>Yazılım</span>
                </button>
            </div>
        </div>
    </div>
</section>

<!-- Services Grid Section -->
<section class="services-grid-section">
    <div class="container">
        <?php if (empty($services)): ?>
            <div class="empty-state-pro fade-in-up">
                <div class="empty-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
                    </svg>
                </div>
                <h3>Henüz Hizmet Eklenmemiş</h3>
                <p>Admin panelinden hizmetlerinizi ekleyebilirsiniz.</p>
                <a href="<?= adminUrl('site-services.php') ?>" class="empty-btn">
                    <span>Admin Panel</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        <?php else: ?>
            <?php 
            $serviceIcons = [
                'laptop' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg>',
                'smartphone' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>',
                'tablet' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M21 4H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-2 14H5V6h14v12z"/></svg>',
                'printer' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>',
                'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>',
                'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>'
            ];
            ?>
            
            <div class="services-grid-pro">
                <?php foreach ($services as $index => $service): ?>
                    <?php 
                    $iconName = $service['icon'] ?? 'settings';
                    $icon = $serviceIcons[$iconName] ?? $serviceIcons['settings'];
                    $slug = $service['slug'] ?? createSlug($service['name']);
                    $features = !empty($service['features']) ? json_decode($service['features'], true) : [];
                    $serviceUrl = url('hizmet/' . $slug);
                    $delay = ($index % 6) * 0.1;
                    
                    // Kategori belirleme (icon'a göre)
                    $categoryMap = [
                        'laptop' => 'computer',
                        'smartphone' => 'mobile',
                        'tablet' => 'mobile',
                        'printer' => 'printer',
                        'settings' => 'software',
                        'users' => 'software'
                    ];
                    $category = $categoryMap[$iconName] ?? 'software';
                    ?>
                    <a href="<?= $serviceUrl ?>" class="service-card-pro fade-in-up" style="animation-delay: <?= $delay ?>s;" data-category="<?= $category ?>">
                        <div class="service-card-inner">
                            <!-- Glow Effect -->
                            <div class="card-glow"></div>
                            
                            <!-- Card Header -->
                            <div class="service-card-header">
                                <div class="service-icon-pro">
                                    <div class="icon-bg"></div>
                                    <div class="icon-inner">
                                        <?= $icon ?>
                                    </div>
                                </div>
                                <div class="service-badge">Popüler</div>
                            </div>
                            
                            <!-- Card Content -->
                            <div class="service-card-content">
                                <h3 class="service-title-pro"><?= clean($service['name']) ?></h3>
                                <?php if (!empty($service['subtitle'])): ?>
                                    <p class="service-subtitle-pro"><?= clean($service['subtitle']) ?></p>
                                <?php endif; ?>
                                <?php if (!empty($service['description'])): ?>
                                    <p class="service-desc-pro"><?= clean(mb_substr($service['description'], 0, 100)) ?><?= mb_strlen($service['description']) > 100 ? '...' : '' ?></p>
                                <?php endif; ?>
                                
                                <!-- Features Preview -->
                                <?php if (!empty($features) && is_array($features)): ?>
                                    <div class="service-features-preview">
                                        <?php foreach (array_slice($features, 0, 3) as $feature): ?>
                                            <div class="feature-item-mini">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                                </svg>
                                                <span><?= clean($feature) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Card Footer -->
                            <div class="service-card-footer">
                                <span class="view-details">
                                    Detayları İncele
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </span>
                            </div>
                            
                            <!-- Hover Border Effect -->
                            <div class="card-border-effect"></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Process Section -->
<section class="process-section-pro">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Süreç</span>
            <h2 class="section-title">Nasıl Çalışıyoruz?</h2>
            <p class="section-subtitle">Basit ve hızlı süreçlerimizle size en iyi hizmeti sunuyoruz.</p>
        </div>
        
        <div class="process-timeline-pro">
            <div class="timeline-line"></div>
            
            <div class="process-step-pro fade-in-up">
                <div class="step-number">01</div>
                <div class="step-content">
                    <div class="step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                    </div>
                    <h4>İletişime Geçin</h4>
                    <p>Bize ulaşın ve sorununuzu anlatın. Ücretsiz teşhis için randevu alın.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="step-number">02</div>
                <div class="step-content">
                    <div class="step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>
                        </svg>
                    </div>
                    <h4>Teşhis</h4>
                    <p>Uzman ekibimiz cihazınızı inceler ve sorunu tespit eder.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="step-number">03</div>
                <div class="step-content">
                    <div class="step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>
                        </svg>
                    </div>
                    <h4>Onay & Tamir</h4>
                    <p>Onayınızın ardından profesyonel tamir işlemi başlar.</p>
                </div>
            </div>
            
            <div class="process-step-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="step-number">04</div>
                <div class="step-content">
                    <div class="step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                    </div>
                    <h4>Teslimat</h4>
                    <p>Tamir tamamlandıktan sonra cihazınız size teslim edilir.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section-pro">
    <div class="container">
        <div class="cta-wrapper-pro fade-in-up">
            <div class="cta-bg-elements">
                <div class="cta-circle cta-circle-1"></div>
                <div class="cta-circle cta-circle-2"></div>
                <div class="cta-circle cta-circle-3"></div>
            </div>
            <div class="cta-content-pro">
                <h2 class="cta-title-pro">Cihazınızla İlgili Sorun mu Yaşıyorsunuz?</h2>
                <p class="cta-desc-pro">Hemen bizimle iletişime geçin, ücretsiz teşhis ve uygun fiyatlı çözümler sunalım.</p>
                <div class="cta-buttons-pro">
                    <a href="<?= url('iletisim') ?>" class="cta-btn-primary">
                        <span>Ücretsiz Teşhis İste</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="tel:<?= getThemeSetting('contact_phone', '05548634870') ?>" class="cta-btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                        <span>Hemen Ara</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Services Page Specific Styles */
.services-hero {
    min-height: 75vh;
    padding-top: 120px;
}

.services-visual .core-inner {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Fix title overflow */
.services-title .title-highlight {
    font-size: clamp(2rem, 5vw, 3.5rem);
    letter-spacing: -0.02em;
    word-break: keep-all;
    white-space: nowrap;
}

@media (max-width: 1400px) {
    .services-title .title-highlight {
        font-size: clamp(1.8rem, 4.5vw, 3rem);
    }
}

@media (max-width: 1200px) {
    .services-title .title-highlight {
        font-size: clamp(1.6rem, 4vw, 2.5rem);
    }
}

/* Filter Section */
.services-filter-section {
    padding: 40px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #0d0d1f 100%);
    position: relative;
    z-index: 10;
}

.filter-wrapper-pro {
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.filter-label {
    color: rgba(255,255,255,0.6);
    font-weight: 500;
    font-size: 0.95rem;
}

.filter-buttons {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.filter-btn-pro {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    color: rgba(255,255,255,0.7);
    padding: 10px 20px;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
}

.filter-btn-pro:hover {
    background: rgba(0, 102, 255, 0.1);
    border-color: rgba(0, 102, 255, 0.3);
    color: white;
}

.filter-btn-pro.active {
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border-color: transparent;
    color: white;
}

.filter-btn-pro svg {
    opacity: 0.7;
}

.filter-btn-pro.active svg,
.filter-btn-pro:hover svg {
    opacity: 1;
}

/* Services Grid */
.services-grid-section {
    padding: 60px 0 100px;
    background: linear-gradient(180deg, #0d0d1f 0%, #12122a 100%);
}

.services-grid-pro {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

/* Service Card Pro */
.service-card-pro {
    text-decoration: none;
    display: block;
}

.service-card-inner {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 32px;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.service-card-pro:hover .service-card-inner {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
    box-shadow: 0 25px 50px rgba(0, 102, 255, 0.15);
}

/* Card Glow Effect */
.card-glow {
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(0, 102, 255, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.4s ease;
    pointer-events: none;
}

.service-card-pro:hover .card-glow {
    opacity: 1;
}

/* Card Border Effect */
.card-border-effect {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.service-card-pro:hover .card-border-effect {
    transform: scaleX(1);
}

/* Service Card Header */
.service-card-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 24px;
}

.service-icon-pro {
    position: relative;
    width: 70px;
    height: 70px;
}

.service-icon-pro .icon-bg {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    transform: rotate(45deg);
    transition: transform 0.4s ease;
}

.service-card-pro:hover .icon-bg {
    transform: rotate(0deg);
}

.service-icon-pro .icon-inner {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.service-icon-pro .icon-inner svg {
    width: 32px;
    height: 32px;
    color: #00D4FF;
}

.service-badge {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.1) 100%);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #10B981;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
}

.service-card-pro:hover .service-badge {
    opacity: 1;
    transform: translateY(0);
}

/* Service Card Content */
.service-card-content {
    flex: 1;
}

.service-title-pro {
    font-size: 1.4rem;
    font-weight: 700;
    color: white;
    margin-bottom: 8px;
    font-family: 'Poppins', sans-serif;
    transition: color 0.3s ease;
}

.service-card-pro:hover .service-title-pro {
    color: #00D4FF;
}

.service-subtitle-pro {
    color: #00D4FF;
    font-size: 0.9rem;
    font-weight: 500;
    margin-bottom: 12px;
}

.service-desc-pro {
    color: rgba(255,255,255,0.6);
    font-size: 0.95rem;
    line-height: 1.6;
    margin-bottom: 20px;
}

/* Features Preview */
.service-features-preview {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 20px;
}

.feature-item-mini {
    display: flex;
    align-items: center;
    gap: 8px;
    color: rgba(255,255,255,0.7);
    font-size: 0.85rem;
}

.feature-item-mini svg {
    color: #10B981;
    flex-shrink: 0;
}

/* Service Card Footer */
.service-card-footer {
    margin-top: auto;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

.view-details {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #00D4FF;
    font-weight: 600;
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.view-details svg {
    transition: transform 0.3s ease;
}

.service-card-pro:hover .view-details svg {
    transform: translateX(5px);
}

/* Empty State */
.empty-state-pro {
    text-align: center;
    padding: 80px 40px;
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
}

.empty-icon {
    color: rgba(255,255,255,0.2);
    margin-bottom: 24px;
}

.empty-state-pro h3 {
    color: white;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 12px;
}

.empty-state-pro p {
    color: rgba(255,255,255,0.6);
    margin-bottom: 24px;
}

.empty-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 12px 24px;
    border-radius: 10px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.empty-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0, 102, 255, 0.4);
}

/* No Results Message */
.no-results-message {
    grid-column: 1 / -1;
    text-align: center;
    padding: 60px 40px;
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
}

.no-results-message p {
    color: rgba(255,255,255,0.6);
    font-size: 1.1rem;
    margin: 0;
}

/* Process Section */
.process-section-pro {
    padding: 100px 0;
    background: #0a0a1a;
    position: relative;
}

.process-timeline-pro {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
    position: relative;
    margin-top: 60px;
}

.timeline-line {
    position: absolute;
    top: 60px;
    left: 10%;
    right: 10%;
    height: 2px;
    background: linear-gradient(90deg, #0066FF, #00D4FF, #0066FF, #00D4FF);
    background-size: 200% 100%;
    animation: gradientMove 3s linear infinite;
}

@keyframes gradientMove {
    0% { background-position: 0% 0%; }
    100% { background-position: 200% 0%; }
}

.process-step-pro {
    text-align: center;
    position: relative;
}

.step-number {
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.3));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 20px;
}

.step-content {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 30px 24px;
    transition: all 0.4s ease;
}

.process-step-pro:hover .step-content {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
}

.step-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}

.step-icon svg {
    width: 28px;
    height: 28px;
    color: #00D4FF;
}

.step-content h4 {
    color: white;
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 10px;
    font-family: 'Poppins', sans-serif;
}

.step-content p {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    line-height: 1.6;
    margin: 0;
}

/* CTA Section Pro */
.cta-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
}

.cta-wrapper-pro {
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.1) 100%);
    border: 1px solid rgba(0, 212, 255, 0.3);
    border-radius: 30px;
    padding: 80px;
    position: relative;
    overflow: hidden;
    text-align: center;
}

.cta-bg-elements {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.cta-circle {
    position: absolute;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.1));
}

.cta-circle-1 {
    width: 300px;
    height: 300px;
    top: -150px;
    right: -100px;
}

.cta-circle-2 {
    width: 200px;
    height: 200px;
    bottom: -100px;
    left: -50px;
}

.cta-circle-3 {
    width: 100px;
    height: 100px;
    top: 50%;
    left: 20%;
    opacity: 0.5;
}

.cta-content-pro {
    position: relative;
    z-index: 1;
}

.cta-title-pro {
    font-size: 2.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 16px;
    font-family: 'Poppins', sans-serif;
}

.cta-desc-pro {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 40px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.cta-buttons-pro {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.cta-btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(0, 102, 255, 0.4);
}

.cta-btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-secondary:hover {
    background: rgba(255,255,255,0.2);
    transform: translateY(-3px);
}

/* Responsive */
@media (max-width: 1200px) {
    .services-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .process-timeline-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .timeline-line {
        display: none;
    }
}

@media (max-width: 992px) {
    .services-hero {
        min-height: auto;
        padding: 140px 0 60px;
    }
    
    .services-hero .hero-visual-pro {
        display: none;
    }
    
    .filter-wrapper-pro {
        flex-direction: column;
        align-items: flex-start;
    }
}

@media (max-width: 768px) {
    .services-grid-pro {
        grid-template-columns: 1fr;
    }
    
    .process-timeline-pro {
        grid-template-columns: 1fr;
    }
    
    .cta-wrapper-pro {
        padding: 40px 24px;
    }
    
    .cta-title-pro {
        font-size: 1.8rem;
    }
    
    .filter-buttons {
        width: 100%;
    }
    
    .filter-btn-pro {
        flex: 1;
        justify-content: center;
        min-width: calc(50% - 6px);
    }
}
</style>

<script>
// Filter functionality with animation
document.querySelectorAll('.filter-btn-pro').forEach(btn => {
    btn.addEventListener('click', function() {
        // Update active state
        document.querySelectorAll('.filter-btn-pro').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        const filter = this.dataset.filter;
        const cards = document.querySelectorAll('.service-card-pro');
        let visibleCount = 0;
        
        cards.forEach((card, index) => {
            const category = card.dataset.category;
            const shouldShow = filter === 'all' || category === filter;
            
            if (shouldShow) {
                // Show with animation
                card.style.display = 'block';
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, visibleCount * 100);
                
                visibleCount++;
            } else {
                // Hide with animation
                card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                card.style.opacity = '0';
                card.style.transform = 'translateY(-10px)';
                
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
        
        // Show "no results" message if needed
        setTimeout(() => {
            const noResultsEl = document.querySelector('.no-results-message');
            if (visibleCount === 0) {
                if (!noResultsEl) {
                    const msg = document.createElement('div');
                    msg.className = 'no-results-message';
                    msg.innerHTML = '<p>Bu kategoride henüz hizmet bulunmamaktadır.</p>';
                    document.querySelector('.services-grid-pro').appendChild(msg);
                }
            } else if (noResultsEl) {
                noResultsEl.remove();
            }
        }, 350);
    });
});

// Animate cards on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

document.querySelectorAll('.service-card-pro').forEach(card => {
    observer.observe(card);
});
</script>
