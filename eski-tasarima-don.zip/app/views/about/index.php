<!-- About Page Hero - Professional Design -->
<section class="hero-section-pro about-hero">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    
    <!-- Animated Grid -->
    <div class="hero-grid-pro"></div>
    
    <!-- 3D Floating Cubes -->
    <div class="cube-container">
        <div class="cube cube-1">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-2">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
    </div>
    
    <!-- Glowing Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    
    <!-- Light Beams -->
    <div class="light-beam light-beam-1"></div>
    <div class="light-beam light-beam-2"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content-pro">
                <!-- Status Badge -->
                <div class="status-badge">
                    <span class="status-dot"></span>
                    <span class="status-text">10+ Yıllık Tecrübe</span>
                </div>
                
                <!-- Main Title -->
                <h1 class="hero-title-pro">
                    <span class="title-main">Teknolojide</span>
                    <span class="title-highlight">GÜVENİLİR ÇÖZÜM</span>
                    <span class="title-main">Ortağınız</span>
                </h1>
                
                <!-- Description -->
                <p class="hero-desc-pro">
                    <?= getThemeSetting('about_content', 'Yıllardır sektörde edindiğimiz tecrübe ile müşterilerimize en kaliteli hizmeti sunmaktayız. Alanında uzman kadromuz ve modern ekipmanlarımızla tüm teknik servis ihtiyaçlarınızı karşılıyoruz.') ?>
                </p>
                
                <!-- CTA Buttons -->
                <div class="hero-cta-pro">
                    <a href="<?= url('hizmetler') ?>" class="cta-primary-pro">
                        <span class="cta-text">Hizmetlerimiz</span>
                        <span class="cta-arrow-pro"></span>
                    </a>
                    <a href="<?= url('iletisim') ?>" class="cta-secondary-pro">
                        <span class="cta-text">İletişime Geç</span>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-6 hero-visual-pro">
                <!-- 3D Building Visual -->
                <div class="tech-visual-container about-visual">
                    <div class="tech-ring tech-ring-1"></div>
                    <div class="tech-ring tech-ring-2"></div>
                    <div class="tech-ring tech-ring-3"></div>
                    <div class="tech-core">
                        <div class="core-inner">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="currentColor" style="color: white;">
                                <path d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"/>
                            </svg>
                        </div>
                        <div class="core-pulse"></div>
                    </div>
                    <!-- Orbiting Elements -->
                    <div class="orbit orbit-1">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-2">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-3">
                        <div class="orbit-dot"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bottom Gradient -->
    <div class="hero-bottom-fade"></div>
</section>

<!-- Story Section -->
<section class="story-section-pro">
    <div class="container">
        <div class="story-grid-pro">
            <div class="story-content-pro fade-in-left">
                <span class="section-label">Hikayemiz</span>
                <h2 class="story-title-pro">Teknoloji Tutkusuyla Başlayan Yolculuk</h2>
                <p class="story-text-pro">
                    2014 yılında küçük bir atölyede başlayan hikayemiz, bugün yüzlerce mutlu müşteriye hizmet veren profesyonel bir teknik servis merkezine dönüştü.
                </p>
                <p class="story-text-pro">
                    Bilgisayar, telefon, tablet ve yazıcı tamiri konusunda uzmanlaşmış ekibimiz, her gün kendini geliştirerek en son teknolojileri takip ediyor ve müşterilerimize en iyi hizmeti sunmak için çalışıyor.
                </p>
                
                <div class="story-features-pro">
                    <div class="story-feature-item">
                        <div class="feature-check-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </div>
                        <span>Deneyimli Teknik Kadro</span>
                    </div>
                    <div class="story-feature-item">
                        <div class="feature-check-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </div>
                        <span>Orijinal Yedek Parça</span>
                    </div>
                    <div class="story-feature-item">
                        <div class="feature-check-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </div>
                        <span>Hızlı Teslimat</span>
                    </div>
                    <div class="story-feature-item">
                        <div class="feature-check-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </div>
                        <span>İşlem Garantisi</span>
                    </div>
                </div>
            </div>
            
            <div class="story-visual-pro fade-in-right">
                <div class="story-image-stack">
                    <div class="story-image-card story-card-1">
                        <div class="card-year">2014</div>
                        <div class="card-content">
                            <h4>Kuruluş</h4>
                            <p>İlk adımlarımız</p>
                        </div>
                    </div>
                    <div class="story-image-card story-card-2">
                        <div class="card-year">2018</div>
                        <div class="card-content">
                            <h4>Büyüme</h4>
                            <p>Ekip genişlemesi</p>
                        </div>
                    </div>
                    <div class="story-image-card story-card-3">
                        <div class="card-year">2024</div>
                        <div class="card-content">
                            <h4>Bugün</h4>
                            <p>500+ Mutlu Müşteri</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section Pro -->
<section class="stats-section-pro">
    <div class="container">
        <div class="stats-grid-pro">
            <div class="stat-card-pro fade-in-up">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="10">0</div>
                <div class="stat-label-pro">Yıllık Tecrübe</div>
                <div class="stat-glow"></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="500">0</div>
                <div class="stat-label-pro">Mutlu Müşteri</div>
                <div class="stat-glow"></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM10 17l-3.5-3.5 1.41-1.41L10 14.17l4.59-4.59L16 11l-6 6z"/>
                    </svg>
                </div>
                <div class="stat-number-pro" data-target="1000">0</div>
                <div class="stat-label-pro">Tamamlanan İş</div>
                <div class="stat-glow"></div>
            </div>
            
            <div class="stat-card-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="stat-icon-pro">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
                    </svg>
                </div>
                <div class="stat-number-pro">24/7</div>
                <div class="stat-label-pro">Destek</div>
                <div class="stat-glow"></div>
            </div>
        </div>
    </div>
</section>

<!-- Values Section Pro -->
<section class="values-section-pro">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Değerlerimiz</span>
            <h2 class="section-title">Neden Bizi Tercih Etmelisiniz?</h2>
            <p class="section-subtitle">Müşteri memnuniyeti odaklı yaklaşımımız ve profesyonel hizmet anlayışımızla fark yaratıyoruz.</p>
        </div>
        
        <div class="values-grid-pro">
            <div class="value-card-pro fade-in-up">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Kaliteli Hizmet</h3>
                <p class="value-description">En yüksek kalite standartlarında, titizlikle hizmet veriyoruz.</p>
                <div class="value-line"></div>
            </div>
            
            <div class="value-card-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Uygun Fiyat</h3>
                <p class="value-description">Şeffaf ve rekabetçi fiyatlandırma ile bütçenize uygun çözümler.</p>
                <div class="value-line"></div>
            </div>
            
            <div class="value-card-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Hızlı Teslimat</h3>
                <p class="value-description">Sorunlarınıza anında müdahale, en kısa sürede teslimat.</p>
                <div class="value-line"></div>
            </div>
            
            <div class="value-card-pro fade-in-up" style="animation-delay: 0.3s;">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Garanti</h3>
                <p class="value-description">Tüm işlemlerimizde garanti ile güvenli hizmet.</p>
                <div class="value-line"></div>
            </div>
            
            <div class="value-card-pro fade-in-up" style="animation-delay: 0.4s;">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Ücretsiz Teşhis</h3>
                <p class="value-description">Tüm cihazlarınız için ücretsiz arıza teşhisi.</p>
                <div class="value-line"></div>
            </div>
            
            <div class="value-card-pro fade-in-up" style="animation-delay: 0.5s;">
                <div class="value-icon-wrapper">
                    <div class="value-icon-bg"></div>
                    <div class="value-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="value-title">Uzman Destek</h3>
                <p class="value-description">Alanında uzman teknik ekibimizle profesyonel destek.</p>
                <div class="value-line"></div>
            </div>
        </div>
    </div>
</section>

<!-- Team Section Pro -->
<section class="team-section-pro">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Ekibimiz</span>
            <h2 class="section-title">Uzman Kadromuz</h2>
            <p class="section-subtitle">Alanında deneyimli, müşteri memnuniyetini ön planda tutan profesyonel ekibimiz.</p>
        </div>
        
        <div class="team-grid-pro">
            <div class="team-card-pro fade-in-up">
                <div class="team-avatar">
                    <div class="avatar-placeholder">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                    <div class="avatar-ring"></div>
                </div>
                <h4 class="team-name">Teknik Servis Uzmanı</h4>
                <p class="team-role">Bilgisayar & Laptop</p>
                <div class="team-expertise">
                    <span>Hardware</span>
                    <span>Software</span>
                    <span>Format</span>
                </div>
            </div>
            
            <div class="team-card-pro fade-in-up" style="animation-delay: 0.1s;">
                <div class="team-avatar">
                    <div class="avatar-placeholder">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                    <div class="avatar-ring"></div>
                </div>
                <h4 class="team-name">Mobil Cihaz Uzmanı</h4>
                <p class="team-role">Telefon & Tablet</p>
                <div class="team-expertise">
                    <span>Ekran</span>
                    <span>Batarya</span>
                    <span>Yazılım</span>
                </div>
            </div>
            
            <div class="team-card-pro fade-in-up" style="animation-delay: 0.2s;">
                <div class="team-avatar">
                    <div class="avatar-placeholder">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                    <div class="avatar-ring"></div>
                </div>
                <h4 class="team-name">Yazıcı Uzmanı</h4>
                <p class="team-role">Yazıcı & Çevre Birimleri</p>
                <div class="team-expertise">
                    <span>Lazer</span>
                    <span>Inkjet</span>
                    <span>Kartuş</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section Pro -->
<section class="cta-section-pro">
    <div class="container">
        <div class="cta-wrapper-pro fade-in-up">
            <div class="cta-bg-elements">
                <div class="cta-circle cta-circle-1"></div>
                <div class="cta-circle cta-circle-2"></div>
                <div class="cta-circle cta-circle-3"></div>
            </div>
            <div class="cta-content-pro">
                <h2 class="cta-title-pro">Teknoloji Sorunlarınız İçin Yanınızdayız</h2>
                <p class="cta-desc-pro">Profesyonel teknik servis hizmetlerimizle cihazlarınıza en iyi bakımı sağlıyoruz.</p>
                <div class="cta-buttons-pro">
                    <a href="<?= url('iletisim') ?>" class="cta-btn-primary">
                        <span>Hemen İletişime Geçin</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="tel:<?= getThemeSetting('contact_phone', '05548634870') ?>" class="cta-btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                        <span>Bizi Arayın</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* About Page Specific Styles */
.about-hero {
    min-height: 80vh;
    padding-top: 120px;
}

.about-visual .core-inner {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Story Section */
.story-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
    position: relative;
    overflow: hidden;
}

.story-grid-pro {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    align-items: center;
}

.story-title-pro {
    font-size: 2.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 24px;
    font-family: 'Poppins', sans-serif;
    line-height: 1.3;
}

.story-text-pro {
    font-size: 1.1rem;
    line-height: 1.8;
    color: rgba(255,255,255,0.7);
    margin-bottom: 20px;
}

.story-features-pro {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin-top: 30px;
}

.story-feature-item {
    display: flex;
    align-items: center;
    gap: 12px;
    color: white;
    font-weight: 500;
}

.feature-check-icon {
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #00D4FF;
}

/* Story Visual */
.story-visual-pro {
    position: relative;
    height: 400px;
}

.story-image-stack {
    position: relative;
    width: 100%;
    height: 100%;
}

.story-image-card {
    position: absolute;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3) 0%, rgba(0, 212, 255, 0.1) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 30px;
    backdrop-filter: blur(10px);
    transition: all 0.4s ease;
}

.story-image-card:hover {
    transform: translateY(-10px) scale(1.02);
    border-color: rgba(0, 212, 255, 0.5);
}

.story-card-1 {
    top: 0;
    left: 0;
    width: 200px;
    z-index: 1;
}

.story-card-2 {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 220px;
    z-index: 2;
}

.story-card-3 {
    bottom: 0;
    right: 0;
    width: 200px;
    z-index: 3;
    background: linear-gradient(135deg, rgba(0, 212, 255, 0.3) 0%, rgba(0, 102, 255, 0.1) 100%);
}

.card-year {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 10px;
}

.card-content h4 {
    color: white;
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 4px;
}

.card-content p {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    margin: 0;
}

/* Stats Section Pro */
.stats-section-pro {
    padding: 80px 0;
    background: #0a0a1a;
    position: relative;
}

.stats-grid-pro {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
}

.stat-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 40px 30px;
    text-align: center;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
}

.stat-card-pro:hover {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
}

.stat-card-pro:hover .stat-glow {
    opacity: 1;
}

.stat-glow {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.stat-icon-pro {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}

.stat-icon-pro svg {
    width: 30px;
    height: 30px;
    color: #00D4FF;
}

.stat-card-pro .stat-number-pro {
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 8px;
}

.stat-card-pro .stat-label-pro {
    color: rgba(255,255,255,0.7);
    font-size: 1rem;
    font-weight: 500;
}

/* Values Section Pro */
.values-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
}

.values-grid-pro {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.value-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 40px;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
}

.value-card-pro:hover {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
}

.value-card-pro:hover .value-line {
    width: 100%;
}

.value-line {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 3px;
    width: 0;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transition: width 0.4s ease;
}

.value-icon-wrapper {
    position: relative;
    width: 70px;
    height: 70px;
    margin-bottom: 24px;
}

.value-icon-bg {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%);
    border-radius: 16px;
    transform: rotate(45deg);
}

.value-icon {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.value-icon svg {
    width: 32px;
    height: 32px;
    color: #00D4FF;
}

.value-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: white;
    margin-bottom: 12px;
    font-family: 'Poppins', sans-serif;
}

.value-description {
    color: rgba(255,255,255,0.6);
    font-size: 0.95rem;
    line-height: 1.6;
    margin: 0;
}

/* Team Section Pro */
.team-section-pro {
    padding: 100px 0;
    background: #0a0a1a;
}

.team-grid-pro {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.team-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    transition: all 0.4s ease;
}

.team-card-pro:hover {
    transform: translateY(-10px);
    border-color: rgba(0, 102, 255, 0.5);
}

.team-avatar {
    position: relative;
    width: 120px;
    height: 120px;
    margin: 0 auto 24px;
}

.avatar-placeholder {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.avatar-placeholder svg {
    width: 50px;
    height: 50px;
    color: white;
}

.avatar-ring {
    position: absolute;
    inset: -8px;
    border: 2px dashed rgba(0, 212, 255, 0.3);
    border-radius: 50%;
    animation: spin 20s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.team-name {
    font-size: 1.3rem;
    font-weight: 700;
    color: white;
    margin-bottom: 8px;
    font-family: 'Poppins', sans-serif;
}

.team-role {
    color: #00D4FF;
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 16px;
}

.team-expertise {
    display: flex;
    gap: 8px;
    justify-content: center;
    flex-wrap: wrap;
}

.team-expertise span {
    background: rgba(0, 102, 255, 0.2);
    color: rgba(255,255,255,0.8);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
}

/* CTA Section Pro */
.cta-section-pro {
    padding: 100px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
}

.cta-wrapper-pro {
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(0, 212, 255, 0.1) 100%);
    border: 1px solid rgba(0, 212, 255, 0.3);
    border-radius: 30px;
    padding: 80px;
    position: relative;
    overflow: hidden;
    text-align: center;
}

.cta-bg-elements {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.cta-circle {
    position: absolute;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.3), rgba(0, 212, 255, 0.1));
}

.cta-circle-1 {
    width: 300px;
    height: 300px;
    top: -150px;
    right: -100px;
}

.cta-circle-2 {
    width: 200px;
    height: 200px;
    bottom: -100px;
    left: -50px;
}

.cta-circle-3 {
    width: 100px;
    height: 100px;
    top: 50%;
    left: 20%;
    opacity: 0.5;
}

.cta-content-pro {
    position: relative;
    z-index: 1;
}

.cta-title-pro {
    font-size: 2.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 16px;
    font-family: 'Poppins', sans-serif;
}

.cta-desc-pro {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 40px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.cta-buttons-pro {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.cta-btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(0, 102, 255, 0.4);
}

.cta-btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.cta-btn-secondary:hover {
    background: rgba(255,255,255,0.2);
    transform: translateY(-3px);
}

/* Responsive */
@media (max-width: 1200px) {
    .values-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 992px) {
    .story-grid-pro {
        grid-template-columns: 1fr;
        gap: 40px;
    }
    
    .story-visual-pro {
        height: 300px;
    }
    
    .stats-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .team-grid-pro {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .about-hero {
        min-height: auto;
        padding: 140px 0 60px;
    }
    
    .about-hero .hero-visual-pro {
        display: none;
    }
}

@media (max-width: 768px) {
    .story-features-pro {
        grid-template-columns: 1fr;
    }
    
    .stats-grid-pro {
        grid-template-columns: 1fr;
    }
    
    .values-grid-pro {
        grid-template-columns: 1fr;
    }
    
    .team-grid-pro {
        grid-template-columns: 1fr;
    }
    
    .cta-wrapper-pro {
        padding: 40px 24px;
    }
    
    .cta-title-pro {
        font-size: 1.8rem;
    }
    
    .story-title-pro {
        font-size: 1.8rem;
    }
}
</style>

<script>
// Counter animation for stats
function animateCounters() {
    const counters = document.querySelectorAll('.stat-card-pro .stat-number-pro[data-target]');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current) + '+';
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target + '+';
            }
        };
        
        // Start animation when element is in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(counter);
    });
}

document.addEventListener('DOMContentLoaded', animateCounters);
</script>
