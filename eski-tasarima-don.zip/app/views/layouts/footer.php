    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div>
                    <h3 class="footer-title"><?= getThemeSetting('site_name', 'Bilişim Servis') ?></h3>
                    <p style="color: rgba(255,255,255,0.8); font-size: 0.95rem; line-height: 1.7; margin-bottom: 20px;">
                        <?= getThemeSetting('organization_description', 'Profesyonel bilişim ve teknik servis hizmetleri') ?>
                    </p>
                </div>
                <div>
                    <h3 class="footer-title">Hızlı Linkler</h3>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li><a href="<?= url() ?>" class="footer-link">Anasayfa</a></li>
                        <li><a href="<?= url('hizmetler') ?>" class="footer-link">Hizmetler</a></li>
                        <li><a href="<?= url('hakkimizda') ?>" class="footer-link">Hakkımızda</a></li>
                        <li><a href="<?= url('iletisim') ?>" class="footer-link">İletişim</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">İletişim</h3>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="margin-bottom: 12px;">
                            <a href="tel:05548634870" class="footer-link">
                                <span style="display: inline-block; margin-right: 8px;">📞</span>
                                0554 863 48 70
                            </a>
                        </li>
                        <li style="margin-bottom: 12px;">
                            <a href="mailto:info@bilisimservis.com" class="footer-link">
                                <span style="display: inline-block; margin-right: 8px;">✉️</span>
                                info@bilisimservis.com
                            </a>
                        </li>
                        <li>
                            <span class="footer-link" style="cursor: default;">
                                <span style="display: inline-block; margin-right: 8px;">📍</span>
                                <?= getThemeSetting('contact_address', 'Murat Tüfekçi') ?>
                            </span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">Çalışma Saatleri</h3>
                    <p style="color: rgba(255,255,255,0.8); font-size: 0.95rem; line-height: 1.7;">
                        <?= getThemeSetting('contact_working_hours', 'Pazartesi - Cuma: 09:00 - 18:00') ?>
                    </p>
                </div>
            </div>
            <div class="footer-bottom">
                <?= getThemeSetting('footer_text', '© 2024 Bilişim Servis. Tüm hakları saklıdır.') ?>
            </div>
        </div>
    </footer>
    
    <?php
    // Schema JSON-LD
    $organizationSchema = generateOrganizationSchema();
    $localBusinessSchema = generateLocalBusinessSchema();
    echo renderSchema($organizationSchema);
    echo renderSchema($localBusinessSchema);
    ?>
    <script src="<?= url('assets/js/frontend.js') ?>"></script>
    <script src="<?= url('assets/js/animations.js') ?>"></script>
    <script src="<?= url('assets/js/page-transitions.js') ?>"></script>
</body>
</html>
