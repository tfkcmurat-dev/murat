<?php
// Service-specific metadata; keep existing page SEO overrides.
$serviceMetaTitle = '';
$serviceMetaDescription = '';
$serviceCanonical = '';
if (isset($service) && is_array($service) && !empty($service['slug'])) {
    global $currentPageSlug;
    $currentPageSlug = 'hizmet/' . $service['slug'];
    $serviceMetaTitle = $service['name'] ?? '';
    $serviceMetaDescription = $service['subtitle'] ?? '';
    $serviceDescriptions = [
        'atasehir-elektrikci' => 'Ataşehir, Kadıköy, Maltepe ve Üsküdar’da avize, priz ve sigorta değişimi, ev elektriği, uydu kontrolü ve kanal ayarlama. Bilişim Servis.',
        'makine-elektrigi-otomasyon-projelendirme' => 'Ataşehir, Kadıköy, Maltepe ve Üsküdar’da otomasyon elektriği, elektrik projelendirme ve otomasyon sistemlerinin elektrik bağlantıları. Bilişim Servis.',
        'atasehir-tv-tamiri' => 'Ataşehir, Kadıköy, Maltepe ve Üsküdar için TV tamiri ve televizyon arıza tespiti. Cihaz bilgisi ve randevu için Bilişim Servis ile iletişime geçin.'
    ];
    $serviceMetaDescription = $serviceDescriptions[$service['slug']] ?? $serviceMetaDescription;
    $serviceCanonical = rtrim(SITE_URL, '/') . '/' . $currentPageSlug;
}
$renderedPageMeta = renderMetaTags($serviceMetaTitle, $serviceMetaDescription);
if ($serviceCanonical !== '' && strpos($renderedPageMeta, 'rel="canonical"') === false) {
    $renderedPageMeta .= '<link rel="canonical" href="' . htmlspecialchars($serviceCanonical, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <?= $renderedPageMeta ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderGoogleAnalytics() ?>
    <?= getHeaderCode() ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?= url('assets/css/frontend.css') ?>">
    <link rel="stylesheet" href="<?= url('assets/css/animations.css') ?>">
    <link rel="stylesheet" href="<?= url('assets/css/components.css') ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Prevent white screen - ensure body is visible */
        body {
            opacity: 1 !important;
            visibility: visible !important;
        }
    </style>
</head>
<body class="bg-white" style="opacity: 1; visibility: visible;">
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="navbar-brand">
                    <a href="<?= url() ?>">
                        <?php $logo = getThemeSetting('site_logo'); ?>
                        <?php if (!empty($logo)): ?>
                            <img src="<?= clean($logo) ?>" alt="<?= getThemeSetting('site_name', 'Logo') ?>">
                        <?php else: ?>
                            <img src="<?= url('assets/images/logo.png') ?>" alt="Bilişim Servis" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div style="display: none; flex-direction: column;">
                                <span style="font-size: 1.25rem; font-weight: 800; font-family: 'Poppins', sans-serif;">
                                    <span style="color: #0066FF;">BİLİŞİM</span>
                                    <span style="color: #1a1a2e;">SERVİS</span>
                                </span>
                                <span style="font-size: 0.75rem; color: #666;">Teknoloji Çözüm Merkezi</span>
                            </div>
                        <?php endif; ?>
                    </a>
                </div>
                <ul class="navbar-nav">
                    <?php 
                    $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                    $isHome = ($currentPath === '/' || $currentPath === '');
                    ?>
                    <li><a href="<?= url() ?>" class="nav-link <?= $isHome ? 'active' : '' ?>">Anasayfa</a></li>
                    <li><a href="<?= url('hizmetler') ?>" class="nav-link <?= strpos($currentPath, '/hizmet') !== false ? 'active' : '' ?>">Hizmetler</a></li>
                    <li><a href="<?= url('hakkimizda') ?>" class="nav-link <?= strpos($currentPath, '/hakkimizda') !== false ? 'active' : '' ?>">Hakkımızda</a></li>
                    <li><a href="<?= url('iletisim') ?>" class="btn btn-primary">İletişim</a></li>
                </ul>
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Menü" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </nav>
    </header>

