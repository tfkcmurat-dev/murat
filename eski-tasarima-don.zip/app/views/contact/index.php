<!-- Contact Page Hero - Professional Design -->
<section class="hero-section-pro contact-hero">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    
    <!-- Animated Grid -->
    <div class="hero-grid-pro"></div>
    
    <!-- 3D Floating Cubes -->
    <div class="cube-container">
        <div class="cube cube-1">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
        <div class="cube cube-2">
            <div class="cube-face cube-front"></div>
            <div class="cube-face cube-back"></div>
            <div class="cube-face cube-right"></div>
            <div class="cube-face cube-left"></div>
            <div class="cube-face cube-top"></div>
            <div class="cube-face cube-bottom"></div>
        </div>
    </div>
    
    <!-- Glowing Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    
    <!-- Light Beams -->
    <div class="light-beam light-beam-1"></div>
    <div class="light-beam light-beam-2"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content-pro">
                <!-- Status Badge -->
                <div class="status-badge">
                    <span class="status-dot"></span>
                    <span class="status-text">7/24 Destek</span>
                </div>
                
                <!-- Main Title -->
                <h1 class="hero-title-pro">
                    <span class="title-main">Bizimle</span>
                    <span class="title-highlight">İLETİŞİME GEÇİN</span>
                    <span class="title-main">Hemen Yardımcı Olalım</span>
                </h1>
                
                <!-- Description -->
                <p class="hero-desc-pro">
                    <?= getThemeSetting('contact_subtitle', 'Teknik servis ihtiyaçlarınız için bize ulaşın. Uzman ekibimiz en kısa sürede size dönüş yapacaktır.') ?>
                </p>
                
                <!-- Quick Contact Stats -->
                <div class="hero-stats-pro">
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                            </svg>
                        </span>
                        <span class="stat-label-pro">Hızlı Yanıt</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </span>
                        <span class="stat-label-pro">Ücretsiz Teşhis</span>
                    </div>
                    <div class="stat-divider-pro"></div>
                    <div class="stat-item-pro">
                        <span class="stat-number-pro">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
                            </svg>
                        </span>
                        <span class="stat-label-pro">Güvenli Hizmet</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 hero-visual-pro">
                <!-- Contact Icon Visual -->
                <div class="tech-visual-container contact-visual">
                    <div class="tech-ring tech-ring-1"></div>
                    <div class="tech-ring tech-ring-2"></div>
                    <div class="tech-ring tech-ring-3"></div>
                    <div class="tech-core">
                        <div class="core-inner">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="currentColor" style="color: white;">
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                            </svg>
                        </div>
                        <div class="core-pulse"></div>
                    </div>
                    <!-- Orbiting Elements -->
                    <div class="orbit orbit-1">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-2">
                        <div class="orbit-dot"></div>
                    </div>
                    <div class="orbit orbit-3">
                        <div class="orbit-dot"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bottom Gradient -->
    <div class="hero-bottom-fade"></div>
</section>

<!-- Contact Content Section -->
<section class="contact-content-section">
    <div class="container">
        <div class="contact-grid-pro">
            <!-- Contact Info Cards -->
            <div class="contact-info-side fade-in-left">
                <div class="contact-card-pro">
                    <div class="contact-card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                        </svg>
                    </div>
                    <div class="contact-card-content">
                        <h4>Adres</h4>
                        <p><?= getThemeSetting('contact_address', 'İstanbul, Türkiye') ?></p>
                    </div>
                    <div class="contact-card-glow"></div>
                </div>
                
                <div class="contact-card-pro">
                    <div class="contact-card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                    </div>
                    <div class="contact-card-content">
                        <h4>Telefon</h4>
                        <a href="tel:<?= getThemeSetting('contact_phone', '05548634870') ?>"><?= getThemeSetting('contact_phone_display', '0554 863 48 70') ?></a>
                    </div>
                    <div class="contact-card-glow"></div>
                </div>
                
                <div class="contact-card-pro">
                    <div class="contact-card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                        </svg>
                    </div>
                    <div class="contact-card-content">
                        <h4>E-posta</h4>
                        <a href="mailto:<?= getThemeSetting('contact_email', 'info@bilisimservis.com') ?>"><?= getThemeSetting('contact_email', 'info@bilisimservis.com') ?></a>
                    </div>
                    <div class="contact-card-glow"></div>
                </div>
                
                <div class="contact-card-pro">
                    <div class="contact-card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
                        </svg>
                    </div>
                    <div class="contact-card-content">
                        <h4>Çalışma Saatleri</h4>
                        <p><?= getThemeSetting('contact_working_hours', 'Pazartesi - Cumartesi: 09:00 - 19:00') ?></p>
                    </div>
                    <div class="contact-card-glow"></div>
                </div>
                
                <!-- Social Links -->
                <div class="social-links-pro">
                    <?php if (!empty($socialLinks['facebook'])): ?>
                    <a href="<?= clean($socialLinks['facebook']) ?>" class="social-link-pro" title="Facebook" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($socialLinks['instagram'])): ?>
                    <a href="<?= clean($socialLinks['instagram']) ?>" class="social-link-pro" title="Instagram" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($socialLinks['twitter'])): ?>
                    <a href="<?= clean($socialLinks['twitter']) ?>" class="social-link-pro" title="Twitter/X" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($socialLinks['whatsapp'])): ?>
                    <a href="<?= clean($socialLinks['whatsapp']) ?>" class="social-link-pro" title="WhatsApp" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($socialLinks['youtube'])): ?>
                    <a href="<?= clean($socialLinks['youtube']) ?>" class="social-link-pro" title="YouTube" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($socialLinks['linkedin'])): ?>
                    <a href="<?= clean($socialLinks['linkedin']) ?>" class="social-link-pro" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                        </svg>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Contact Form -->
            <div class="contact-form-side fade-in-right">
                <div class="contact-form-pro">
                    <div class="form-header-pro">
                        <h3>Mesaj Gönderin</h3>
                        <p>Formu doldurun, size en kısa sürede dönüş yapalım.</p>
                    </div>
                    
                    <?php 
                    $success = getFlash('success');
                    $error = getFlash('error');
                    ?>
                    <?php if ($success): ?>
                        <div class="alert-pro alert-success-pro">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                            <span><?= clean($success) ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="alert-pro alert-error-pro">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                            </svg>
                            <span><?= clean($error) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="<?= url('iletisim') ?>" id="contactForm" class="contact-form-fields">
                        <?= csrfField() ?>
                        <div class="form-row-pro">
                            <div class="form-group-pro">
                                <label class="form-label-pro">Adınız Soyadınız</label>
                                <div class="input-wrapper-pro">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                                    </svg>
                                    <input type="text" name="name" class="form-input-pro" required placeholder="Adınızı girin">
                                </div>
                            </div>
                            <div class="form-group-pro">
                                <label class="form-label-pro">E-posta Adresiniz</label>
                                <div class="input-wrapper-pro">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                                    </svg>
                                    <input type="email" name="email" class="form-input-pro" required placeholder="E-posta adresinizi girin">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group-pro">
                            <label class="form-label-pro">Konu</label>
                            <div class="input-wrapper-pro">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                                </svg>
                                <select name="subject" class="form-input-pro form-select-pro">
                                    <option value="general">Genel Bilgi</option>
                                    <option value="support">Teknik Destek</option>
                                    <option value="quote">Fiyat Teklifi</option>
                                    <option value="complaint">Şikayet</option>
                                    <option value="other">Diğer</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group-pro">
                            <label class="form-label-pro">Mesajınız</label>
                            <div class="input-wrapper-pro textarea-wrapper">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M21 6h-2V4c0-1.1-.9-2-2-2H3c-1.1 0-2 .9-2 2v13l4-4h9v-3h7V6zm-4 7l4 4H13c-1.1 0-2-.9-2-2V7h6v6z"/>
                                </svg>
                                <textarea name="message" class="form-input-pro form-textarea-pro" rows="5" required placeholder="Mesajınızı buraya yazın..."></textarea>
                            </div>
                        </div>
                        
                        <button type="submit" class="submit-btn-pro">
                            <span class="btn-text">Mesajı Gönder</span>
                            <span class="btn-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                                </svg>
                            </span>
                            <span class="btn-loader"></span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section (Optional) -->
<section class="map-section-pro">
    <div class="container">
        <div class="section-header fade-in-up">
            <span class="section-label">Konum</span>
            <h2 class="section-title">Bizi Ziyaret Edin</h2>
        </div>
        <div class="map-wrapper-pro fade-in-up">
            <div class="map-overlay-pro">
                <div class="map-info-card">
                    <h4>Bilişim Servis</h4>
                    <p><?= getThemeSetting('contact_address', 'İstanbul, Türkiye') ?></p>
                    <a href="https://maps.google.com" target="_blank" class="map-direction-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M21.71 11.29l-9-9c-.39-.39-1.02-.39-1.41 0l-9 9c-.39.39-.39 1.02 0 1.41l9 9c.39.39 1.02.39 1.41 0l9-9c.39-.38.39-1.01 0-1.41zM14 14.5V12h-4v3H8v-4c0-.55.45-1 1-1h5V7.5l3.5 3.5-3.5 3.5z"/>
                        </svg>
                        Yol Tarifi Al
                    </a>
                </div>
            </div>
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d385396.3509887381!2d28.731949265137816!3d41.00498228498498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14caa7040068086b%3A0xe1ccfe98bc01b0d0!2zxLBzdGFuYnVs!5e0!3m2!1str!2str!4v1704067200000!5m2!1str!2str" 
                width="100%" 
                height="450" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</section>

<style>
/* Contact Page Specific Styles */
.contact-hero {
    min-height: 70vh;
    padding-top: 120px;
}

.contact-visual .core-inner {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Contact Content Section */
.contact-content-section {
    padding: 80px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
    position: relative;
}

.contact-grid-pro {
    display: grid;
    grid-template-columns: 1fr 1.5fr;
    gap: 40px;
    align-items: start;
}

/* Contact Info Cards */
.contact-info-side {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.contact-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.contact-card-pro:hover {
    transform: translateX(10px);
    border-color: rgba(0, 102, 255, 0.5);
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.1) 0%, rgba(0, 212, 255, 0.05) 100%);
}

.contact-card-glow {
    position: absolute;
    top: 50%;
    left: 0;
    width: 4px;
    height: 0;
    background: linear-gradient(180deg, #0066FF, #00D4FF);
    border-radius: 4px;
    transition: height 0.3s ease;
    transform: translateY(-50%);
}

.contact-card-pro:hover .contact-card-glow {
    height: 60%;
}

.contact-card-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.contact-card-icon svg {
    width: 24px;
    height: 24px;
    color: white;
}

.contact-card-content h4 {
    color: rgba(255,255,255,0.6);
    font-size: 0.85rem;
    font-weight: 500;
    margin-bottom: 4px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.contact-card-content p,
.contact-card-content a {
    color: white;
    font-size: 1rem;
    font-weight: 600;
    margin: 0;
    text-decoration: none;
    transition: color 0.3s ease;
}

.contact-card-content a:hover {
    color: #00D4FF;
}

/* Social Links */
.social-links-pro {
    display: flex;
    gap: 12px;
    margin-top: 20px;
}

.social-link-pro {
    width: 44px;
    height: 44px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(255,255,255,0.6);
    transition: all 0.3s ease;
}

.social-link-pro:hover {
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border-color: transparent;
    color: white;
    transform: translateY(-3px);
}

/* Contact Form */
.contact-form-side {
    position: relative;
}

.contact-form-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 40px;
    position: relative;
    overflow: hidden;
}

.contact-form-pro::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #0066FF, #00D4FF, #0066FF);
    background-size: 200% 100%;
    animation: gradientMove 3s linear infinite;
}

@keyframes gradientMove {
    0% { background-position: 0% 0%; }
    100% { background-position: 200% 0%; }
}

.form-header-pro {
    margin-bottom: 30px;
}

.form-header-pro h3 {
    color: white;
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 8px;
    font-family: 'Poppins', sans-serif;
}

.form-header-pro p {
    color: rgba(255,255,255,0.6);
    font-size: 0.95rem;
}

/* Alert Styles */
.alert-pro {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    border-radius: 12px;
    margin-bottom: 24px;
}

.alert-success-pro {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #10B981;
}

.alert-error-pro {
    background: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #EF4444;
}

/* Form Fields */
.form-row-pro {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group-pro {
    margin-bottom: 20px;
}

.form-label-pro {
    display: block;
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
    font-weight: 500;
    margin-bottom: 8px;
}

.input-wrapper-pro {
    position: relative;
    display: flex;
    align-items: center;
}

.input-wrapper-pro svg {
    position: absolute;
    left: 16px;
    color: rgba(255,255,255,0.4);
    pointer-events: none;
    z-index: 1;
}

.input-wrapper-pro.textarea-wrapper svg {
    top: 16px;
    align-self: flex-start;
}

.form-input-pro {
    width: 100%;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    padding: 14px 16px 14px 50px;
    color: white;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-input-pro:focus {
    outline: none;
    border-color: #0066FF;
    background: rgba(0, 102, 255, 0.1);
    box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.1);
}

.form-input-pro::placeholder {
    color: rgba(255,255,255,0.4);
}

.form-select-pro {
    appearance: none;
    cursor: pointer;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='rgba(255,255,255,0.4)'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
}

.form-select-pro option {
    background-color: #0d0d1f;
    color: white;
    padding: 12px;
}

.form-select-pro option:hover,
.form-select-pro option:focus,
.form-select-pro option:checked {
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
}

.form-textarea-pro {
    resize: vertical;
    min-height: 120px;
}

/* Submit Button */
.submit-btn-pro {
    width: 100%;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border: none;
    border-radius: 12px;
    padding: 16px 32px;
    color: white;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.submit-btn-pro::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s ease;
}

.submit-btn-pro:hover::before {
    left: 100%;
}

.submit-btn-pro:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0, 102, 255, 0.4);
}

.submit-btn-pro .btn-icon {
    transition: transform 0.3s ease;
}

.submit-btn-pro:hover .btn-icon {
    transform: translateX(5px);
}

.submit-btn-pro .btn-loader {
    display: none;
    width: 20px;
    height: 20px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

.submit-btn-pro.loading .btn-text,
.submit-btn-pro.loading .btn-icon {
    display: none;
}

.submit-btn-pro.loading .btn-loader {
    display: block;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Map Section */
.map-section-pro {
    padding: 80px 0;
    background: #0a0a1a;
}

.map-wrapper-pro {
    position: relative;
    border-radius: 24px;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.1);
}

.map-overlay-pro {
    position: absolute;
    top: 20px;
    left: 20px;
    z-index: 10;
}

.map-info-card {
    background: rgba(10, 10, 26, 0.95);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 24px;
    min-width: 280px;
}

.map-info-card h4 {
    color: white;
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.map-info-card p {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.map-direction-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.map-direction-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(0, 102, 255, 0.4);
}

/* Responsive */
@media (max-width: 992px) {
    .contact-grid-pro {
        grid-template-columns: 1fr;
    }
    
    .contact-hero {
        min-height: auto;
        padding: 140px 0 60px;
    }
    
    .contact-hero .hero-visual-pro {
        display: none;
    }
}

@media (max-width: 768px) {
    .form-row-pro {
        grid-template-columns: 1fr;
    }
    
    .contact-form-pro {
        padding: 24px;
    }
    
    .hero-stats-pro {
        flex-wrap: wrap;
        gap: 15px;
    }
    
    .stat-divider-pro {
        display: none;
    }
}
</style>

<script>
// Form submission animation
document.getElementById('contactForm')?.addEventListener('submit', function(e) {
    const btn = this.querySelector('.submit-btn-pro');
    btn.classList.add('loading');
});

// Input focus animations
document.querySelectorAll('.form-input-pro').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });
    input.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });
});
</script>
