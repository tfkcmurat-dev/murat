<?php
/**
 * SEO ve Schema Fonksiyonları
 */

/**
 * Meta title oluştur
 */
function getMetaTitle($pageTitle = '') {
    $siteName = getThemeSetting('site_name', 'Bilişim Servis');
    
    if (empty($pageTitle)) {
        return $siteName;
    }
    
    return $pageTitle . ' - ' . $siteName;
}

/**
 * Meta description getir
 */
function getMetaDescription($default = '') {
    // Sayfa bazlı meta description kontrolü yapılabilir
    return getThemeSetting('meta_description', $default);
}

/**
 * JSON-LD Organization Schema oluştur
 */
function generateOrganizationSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Organization',
        'name' => getThemeSetting('organization_name', getThemeSetting('site_name', 'Bilişim Servis')),
        'url' => SITE_URL,
    ];
    
    $logo = getThemeSetting('organization_logo');
    if (!empty($logo)) {
        $schema['logo'] = $logo;
    }
    
    $description = getThemeSetting('organization_description');
    if (!empty($description)) {
        $schema['description'] = $description;
    }
    
    $email = getThemeSetting('site_email');
    if (!empty($email)) {
        $schema['email'] = $email;
    }
    
    $phone = getThemeSetting('site_phone');
    if (!empty($phone)) {
        $schema['telephone'] = $phone;
    }
    
    $address = getThemeSetting('site_address');
    if (!empty($address)) {
        $schema['address'] = [
            '@type' => 'PostalAddress',
            'addressLocality' => $address
        ];
    }
    
    return $schema;
}

/**
 * JSON-LD LocalBusiness Schema oluştur
 */
function generateLocalBusinessSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => getThemeSetting('local_business_type', 'LocalBusiness'),
        'name' => getThemeSetting('organization_name', getThemeSetting('site_name', 'Bilişim Servis')),
        'url' => SITE_URL,
    ];
    
    $address = getThemeSetting('local_business_address');
    if (!empty($address)) {
        $schema['address'] = [
            '@type' => 'PostalAddress',
            'addressLocality' => $address
        ];
    }
    
    $phone = getThemeSetting('local_business_phone');
    if (!empty($phone)) {
        $schema['telephone'] = $phone;
    }
    
    $email = getThemeSetting('site_email');
    if (!empty($email)) {
        $schema['email'] = $email;
    }
    
    return $schema;
}

/**
 * JSON-LD Service Schema oluştur
 */
function generateServiceSchema($serviceName, $description = '', $price = '') {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Service',
        'name' => $serviceName,
        'provider' => [
            '@type' => 'Organization',
            'name' => getThemeSetting('organization_name', getThemeSetting('site_name', 'Bilişim Servis'))
        ]
    ];
    
    if (!empty($description)) {
        $schema['description'] = $description;
    }
    
    if (!empty($price)) {
        $schema['offers'] = [
            '@type' => 'Offer',
            'price' => $price,
            'priceCurrency' => 'TRY'
        ];
    }
    
    return $schema;
}

/**
 * Schema JSON-LD script tag'i oluştur
 */
function renderSchema($schema) {
    if (empty($schema)) {
        return '';
    }
    
    $json = json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return '<script type="application/ld+json">' . $json . '</script>';
}

/**
 * Header code injection (Google Analytics, Meta Pixel vb.)
 */
function getHeaderCode() {
    return getThemeSetting('header_code', '');
}

/**
 * Meta tag'leri render et
 * Sayfa bazlı SEO desteği ile
 */
function renderMetaTags($title = '', $description = '', $keywords = '') {
    global $noIndex; // noindex flag'i controller'dan alınabilir
    global $currentPageSlug; // Sayfa slug'ı
    
    // Sayfa slug'ını belirle
    $pageSlug = $currentPageSlug ?? getCurrentPageSlug();
    
    // Sayfa bazlı SEO ayarlarını al
    $pageSeo = getPageSeoSettings($pageSlug);
    
    // Meta title
    $metaTitle = $title;
    if (!empty($pageSeo['meta_title'])) {
        $metaTitle = $pageSeo['meta_title'];
    } elseif (empty($metaTitle)) {
        $metaTitle = getThemeSetting('site_name', 'Bilişim Servis');
    } else {
        $metaTitle = $metaTitle . ' - ' . getThemeSetting('site_name', 'Bilişim Servis');
    }
    
    // Meta description
    $metaDescription = $description;
    if (!empty($pageSeo['meta_description'])) {
        $metaDescription = $pageSeo['meta_description'];
    } elseif (empty($metaDescription)) {
        $metaDescription = getMetaDescription();
    }
    
    // Meta keywords
    $metaKeywords = $keywords;
    if (!empty($pageSeo['meta_keywords'])) {
        $metaKeywords = $pageSeo['meta_keywords'];
    }
    
    // Robots
    $robots = 'index, follow';
    if (!empty($noIndex)) {
        $robots = 'noindex, nofollow';
    } elseif (!empty($pageSeo['robots'])) {
        $robots = $pageSeo['robots'];
    }
    
    // OG tags
    $ogTitle = !empty($pageSeo['og_title']) ? $pageSeo['og_title'] : $metaTitle;
    $ogDescription = !empty($pageSeo['og_description']) ? $pageSeo['og_description'] : $metaDescription;
    $ogImage = !empty($pageSeo['og_image']) ? $pageSeo['og_image'] : getThemeSetting('og_image', '');
    
    // Canonical
    $canonical = !empty($pageSeo['canonical_url']) ? $pageSeo['canonical_url'] : '';
    
    $html = '<meta charset="UTF-8">' . "\n";
    $html .= '<title>' . htmlspecialchars($metaTitle) . '</title>' . "\n";
    
    // Favicon
    $favicon = getThemeSetting('favicon', '');
    if (!empty($favicon)) {
        $html .= '<link rel="icon" type="image/x-icon" href="' . htmlspecialchars($favicon) . '">' . "\n";
        $html .= '<link rel="shortcut icon" type="image/x-icon" href="' . htmlspecialchars($favicon) . '">' . "\n";
    }
    
    // Robots
    $html .= '<meta name="robots" content="' . htmlspecialchars($robots) . '">' . "\n";
    
    // Description
    if (!empty($metaDescription)) {
        $html .= '<meta name="description" content="' . htmlspecialchars($metaDescription) . '">' . "\n";
    }
    
    // Keywords
    if (!empty($metaKeywords)) {
        $html .= '<meta name="keywords" content="' . htmlspecialchars($metaKeywords) . '">' . "\n";
    }
    
    // Canonical
    if (!empty($canonical)) {
        $html .= '<link rel="canonical" href="' . htmlspecialchars($canonical) . '">' . "\n";
    }
    
    // Open Graph tags
    $siteName = getThemeSetting('site_name', 'Bilişim Servis');
    $html .= '<meta property="og:site_name" content="' . htmlspecialchars($siteName) . '">' . "\n";
    $html .= '<meta property="og:title" content="' . htmlspecialchars($ogTitle) . '">' . "\n";
    if (!empty($ogDescription)) {
        $html .= '<meta property="og:description" content="' . htmlspecialchars($ogDescription) . '">' . "\n";
    }
    $html .= '<meta property="og:url" content="' . getCurrentUrl() . '">' . "\n";
    $html .= '<meta property="og:type" content="website">' . "\n";
    if (!empty($ogImage)) {
        $html .= '<meta property="og:image" content="' . htmlspecialchars($ogImage) . '">' . "\n";
    }
    
    // Twitter Card tags
    $html .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
    $html .= '<meta name="twitter:title" content="' . htmlspecialchars($ogTitle) . '">' . "\n";
    if (!empty($ogDescription)) {
        $html .= '<meta name="twitter:description" content="' . htmlspecialchars($ogDescription) . '">' . "\n";
    }
    if (!empty($ogImage)) {
        $html .= '<meta name="twitter:image" content="' . htmlspecialchars($ogImage) . '">' . "\n";
    }
    
    // Google Search Console doğrulama
    $searchConsole = getThemeSetting('google_search_console', '');
    if (!empty($searchConsole)) {
        $html .= '<meta name="google-site-verification" content="' . htmlspecialchars($searchConsole) . '">' . "\n";
    }
    
    // Custom Schema
    if (!empty($pageSeo['custom_schema'])) {
        $html .= '<script type="application/ld+json">' . "\n";
        $html .= $pageSeo['custom_schema'] . "\n";
        $html .= '</script>' . "\n";
    }
    
    return $html;
}

/**
 * Mevcut sayfa slug'ını al
 */
function getCurrentPageSlug() {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $path = trim($path, '/');
    
    if (empty($path)) {
        return 'anasayfa';
    }
    
    // Bilinen sayfalar
    $knownPages = [
        'hakkimizda' => 'hakkimizda',
        'hizmetler' => 'hizmetler',
        'iletisim' => 'iletisim',
        'blog' => 'blog'
    ];
    
    if (isset($knownPages[$path])) {
        return $knownPages[$path];
    }
    
    // İlk segment'i al
    $segments = explode('/', $path);
    return $segments[0];
}

/**
 * Mevcut URL'i al
 */
function getCurrentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Sayfa bazlı SEO ayarlarını getir
 */
function getPageSeoSettings($pageSlug) {
    $db = Database::getInstance();
    
    $seo = $db->fetch(
        "SELECT * FROM page_seo WHERE page_slug = ? AND is_active = 1",
        [$pageSlug]
    );
    
    return $seo ?: [];
}

/**
 * Google Analytics kodu render et
 */
function renderGoogleAnalytics() {
    $gaId = getThemeSetting('google_analytics_id', '');
    
    if (empty($gaId)) {
        return '';
    }
    
    $html = '';
    
    // GA4
    if (strpos($gaId, 'G-') === 0) {
        $html .= '<script async src="https://www.googletagmanager.com/gtag/js?id=' . htmlspecialchars($gaId) . '"></script>' . "\n";
        $html .= '<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(\'js\', new Date());
  gtag(\'config\', \'' . htmlspecialchars($gaId) . '\');
</script>' . "\n";
    }
    // Universal Analytics
    elseif (strpos($gaId, 'UA-') === 0) {
        $html .= '<script async src="https://www.googletagmanager.com/gtag/js?id=' . htmlspecialchars($gaId) . '"></script>' . "\n";
        $html .= '<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(\'js\', new Date());
  gtag(\'config\', \'' . htmlspecialchars($gaId) . '\');
</script>' . "\n";
    }
    
    return $html;
}
