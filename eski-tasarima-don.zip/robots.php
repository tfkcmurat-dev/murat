<?php
/**
 * Robots.txt Generator
 * Dinamik robots.txt oluşturur
 */

require_once __DIR__ . '/app/config/config.php';

header('Content-Type: text/plain; charset=UTF-8');

$baseUrl = url('');
$sitemapUrl = url('sitemap.xml');
?>
# Robots.txt - <?= getThemeSetting('site_name', 'Bilişim Servis') ?>

User-agent: *
Allow: /

# Admin paneli engelle
Disallow: /admin/
Disallow: /app/
Disallow: /vendor/

# Teklif sayfalarını engelle (noindex zaten var)
Disallow: /teklif/

# Sitemap
Sitemap: <?= $sitemapUrl ?>
