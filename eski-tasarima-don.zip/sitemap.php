<?php
/**
 * Sitemap XML Generator
 * Dinamik sitemap.xml oluşturur
 */

require_once __DIR__ . '/app/config/config.php';

// Sitemap aktif mi kontrol et
if (getThemeSetting('sitemap_enabled', '1') != '1') {
    http_response_code(404);
    exit('Sitemap is disabled');
}

header('Content-Type: application/xml; charset=UTF-8');

$baseUrl = url('');
$changefreq = getThemeSetting('sitemap_changefreq', 'weekly');
$includeServices = getThemeSetting('sitemap_include_services', '1') == '1';
$includeBlog = getThemeSetting('sitemap_include_blog', '1') == '1';

// Database bağlantısı
$db = Database::getInstance();

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <!-- Ana Sayfa -->
    <url>
        <loc><?= $baseUrl ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq><?= $changefreq ?></changefreq>
        <priority>1.0</priority>
    </url>
    
    <!-- Hakkımızda -->
    <url>
        <loc><?= url('hakkimizda') ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>
    
    <!-- Hizmetler -->
    <url>
        <loc><?= url('hizmetler') ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq><?= $changefreq ?></changefreq>
        <priority>0.9</priority>
    </url>
    
    <!-- İletişim -->
    <url>
        <loc><?= url('iletisim') ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </url>
    
<?php if ($includeServices): ?>
    <!-- Hizmet Detay Sayfaları -->
<?php
    try {
        $services = $db->fetchAll("SELECT slug, updated_at FROM site_services WHERE is_active = 1 ORDER BY id ASC");
        foreach ($services as $service):
            $lastmod = !empty($service['updated_at']) ? date('Y-m-d', strtotime($service['updated_at'])) : date('Y-m-d');
?>
    <url>
        <loc><?= url('hizmet/' . $service['slug']) ?></loc>
        <lastmod><?= $lastmod ?></lastmod>
        <changefreq><?= $changefreq ?></changefreq>
        <priority>0.7</priority>
    </url>
<?php 
        endforeach;
    } catch (Exception $e) {
        // site_services tablosu yoksa sessizce geç
    }
?>
<?php endif; ?>

<?php if ($includeBlog): ?>
    <!-- Blog Sayfası -->
    <url>
        <loc><?= url('blog') ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq><?= $changefreq ?></changefreq>
        <priority>0.8</priority>
    </url>
    
    <!-- Blog Yazıları -->
<?php
    // Blog tablosu varsa
    try {
        $posts = $db->fetchAll("SELECT slug, updated_at FROM blog_posts WHERE is_active = 1 ORDER BY created_at DESC LIMIT 100");
        foreach ($posts as $post):
            $lastmod = !empty($post['updated_at']) ? date('Y-m-d', strtotime($post['updated_at'])) : date('Y-m-d');
?>
    <url>
        <loc><?= url('blog/' . $post['slug']) ?></loc>
        <lastmod><?= $lastmod ?></lastmod>
        <changefreq><?= $changefreq ?></changefreq>
        <priority>0.6</priority>
    </url>
<?php 
        endforeach;
    } catch (Exception $e) {
        // Blog tablosu yoksa sessizce geç
    }
?>
<?php endif; ?>

</urlset>
