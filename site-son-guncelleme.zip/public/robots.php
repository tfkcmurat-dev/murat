<?php
require __DIR__ . '/../robots.php';
