<?php
// Service-specific metadata; keep existing page SEO overrides.
$serviceMetaTitle = '';
$serviceMetaDescription = '';
$serviceCanonical = '';
if (isset($service) && is_array($service) && !empty($service['slug'])) {
    global $currentPageSlug;
    $currentPageSlug = 'hizmet/' . $service['slug'];
    $serviceMetaTitle = $service['name'] ?? '';
    $serviceMetaDescription = $service['subtitle'] ?? '';
    $serviceCanonical = rtrim(SITE_URL, '/') . '/' . $currentPageSlug;
}
$renderedPageMeta = renderMetaTags($serviceMetaTitle, $serviceMetaDescription);
if ($serviceCanonical !== '' && strpos($renderedPageMeta, 'rel="canonical"') === false) {
    $renderedPageMeta .= '<link rel="canonical" href="' . htmlspecialchars($serviceCanonical, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <?= $renderedPageMeta ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderGoogleAnalytics() ?>
    <?= getHeaderCode() ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?= url('assets/css/frontend.css') ?>">
    <link rel="stylesheet" href="<?= url('assets/css/animations.css') ?>">
    <link rel="stylesheet" href="<?= url('assets/css/components.css') ?>">
    <link rel="stylesheet" href="<?= url('public/assets/css/modern.css?v=20261009-r4') ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Prevent white screen - ensure body is visible */
        body {
            opacity: 1 !important;
            visibility: visible !important;
        }
    </style>
</head>
<body class="bg-white bs-modern" style="opacity: 1; visibility: visible;">
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="navbar-brand">
                    <a class="bs-brand" href="<?= url() ?>" aria-label="Bilişim Servis Anasayfa">
                        <span class="bs-brand-symbol" aria-hidden="true"><img src="<?= url('public/assets/images/bilisim-servis-symbol.png') ?>" alt="" width="56" height="56"></span>
                        <span class="bs-brand-copy"><strong>Bilişim <span>Servis</span></strong><small>Bilgisayar · Elektrik · Elektronik · TV · Uydu · Kamera</small></span>
                    </a>
                </div>
                <ul class="navbar-nav">
                    <?php 
                    $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                    $isHome = ($currentPath === '/' || $currentPath === '');
                    ?>
                    <li><a href="<?= url() ?>" class="nav-link <?= $isHome ? 'active' : '' ?>">Anasayfa</a></li>
                    <li><a href="<?= url('hizmetler') ?>" class="nav-link <?= strpos($currentPath, '/hizmet') !== false ? 'active' : '' ?>">Hizmetler</a></li>
                    <li><a href="<?= url('hakkimizda') ?>" class="nav-link <?= strpos($currentPath, '/hakkimizda') !== false ? 'active' : '' ?>">Hakkımızda</a></li>
                    <li><a href="<?= url('iletisim') ?>" class="btn btn-primary">İletişim</a></li>
                </ul>
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Menü" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </nav>
    </header>

