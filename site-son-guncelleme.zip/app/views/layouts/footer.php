    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div>
                    <h3 class="footer-title"><?= getThemeSetting('site_name', 'Bilişim Servis') ?></h3>
                    <p style="color: rgba(255,255,255,0.8); font-size: 0.95rem; line-height: 1.7; margin-bottom: 20px;">
                        <?= getThemeSetting('organization_description', 'Profesyonel bilişim ve teknik servis hizmetleri') ?>
                    </p>
                </div>
                <div>
                    <h3 class="footer-title">Hızlı Linkler</h3>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li><a href="<?= url() ?>" class="footer-link">Anasayfa</a></li>
                        <li><a href="<?= url('hizmetler') ?>" class="footer-link">Hizmetler</a></li>
                        <li><a href="<?= url('hakkimizda') ?>" class="footer-link">Hakkımızda</a></li>
                        <li><a href="<?= url('iletisim') ?>" class="footer-link">İletişim</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">İletişim</h3>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="margin-bottom: 12px;">
                            <a href="tel:05548634870" class="footer-link">
                                <span style="display: inline-block; margin-right: 8px;">📞</span>
                                0554 863 48 70
                            </a>
                        </li>
                        <li style="margin-bottom: 12px;">
                            <a href="mailto:info@bilisimservis.com" class="footer-link">
                                <span style="display: inline-block; margin-right: 8px;">✉️</span>
                                info@bilisimservis.com
                            </a>
                        </li>
                        <li>
                            <span class="footer-link" style="cursor: default;">
                                <span style="display: inline-block; margin-right: 8px;">📍</span>
                                <?= getThemeSetting('contact_address', 'Murat Tüfekçi') ?>
                            </span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">Çalışma Saatleri</h3>
                    <p style="color: rgba(255,255,255,0.8); font-size: 0.95rem; line-height: 1.7;">
                        <?= getThemeSetting('contact_working_hours', 'Pazartesi - Cuma: 09:00 - 18:00') ?>
                    </p>
                </div>
            </div>
            <div class="footer-bottom">
                <?= getThemeSetting('footer_text', '© 2024 Bilişim Servis. Tüm hakları saklıdır.') ?>
            </div>
        </div>
    </footer>
    
    <?php
    // Schema JSON-LD
    $organizationSchema = generateOrganizationSchema();
    $localBusinessSchema = generateLocalBusinessSchema();
    echo renderSchema($organizationSchema);
    echo renderSchema($localBusinessSchema);
    ?>
    <?php
    $whatsappPhone = preg_replace('/[^0-9]/', '', getThemeSetting('contact_phone', '05548634870'));
    if (strlen($whatsappPhone) === 11 && substr($whatsappPhone, 0, 1) === '0') $whatsappPhone = '90' . substr($whatsappPhone, 1);
    elseif (strlen($whatsappPhone) === 10 && substr($whatsappPhone, 0, 1) === '5') $whatsappPhone = '90' . $whatsappPhone;
    if (!preg_match('/^[1-9][0-9]{9,14}$/', $whatsappPhone)) $whatsappPhone = '905548634870';
    if (preg_match('/^[1-9][0-9]{9,14}$/', $whatsappPhone)):
        $whatsappMessage = 'Merhaba, Bilişim Servis hizmetleriniz hakkında bilgi almak istiyorum.';
    ?>
    <a class="bs-whatsapp" href="https://wa.me/<?= clean($whatsappPhone) ?>?text=<?= rawurlencode($whatsappMessage) ?>" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp üzerinden Bilişim Servis'e mesaj gönderin"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 11.5a9 9 0 0 1-13.5 7.8L3 21l1.6-4.6A9 9 0 1 1 21 11.5Z"/><path d="M8 7.5c-.5.4-.6 1-.3 1.9 1 2.5 2.8 4.3 5.3 5.3.9.3 1.5.2 1.9-.3l1-1.4-2.5-1.3-.9.9c-1.1-.5-2-1.4-2.5-2.5l.9-.9-1.3-2.5Z"/></svg><span>WhatsApp</span></a>
    <?php endif; ?>
    <script src="<?= url('assets/js/frontend.js') ?>"></script>
    <script src="<?= url('assets/js/animations.js') ?>"></script>
    <script src="<?= url('assets/js/page-transitions.js') ?>"></script>
</body>
</html>
