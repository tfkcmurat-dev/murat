<?php
require_once APP_PATH . '/helpers/service-catalog.php';
$visibleSlugs = array_column($services ?? [], 'slug');
$catalog = bsServiceCatalog();
$visibleCatalog = array_values(array_filter($catalog, function ($item) use ($visibleSlugs) { return in_array($item['slug'], $visibleSlugs, true); }));
$featured = array_slice($catalog, 0, 4);
$shortcutItems = array_merge(array_slice($catalog, 4, 9), [$catalog[3]], array_slice($catalog, 13, 2));
$shortcuts = array_filter($shortcutItems, function ($item) use ($visibleSlugs) { return in_array($item['slug'], $visibleSlugs, true); });
?>
<main>
<section class="bs-home-hero">
    <div class="bs-hero-photo" aria-hidden="true"></div>
    <div class="container bs-home-hero-content">
        <span class="bs-eyebrow">İstanbul için teknik servis çözümleri</span>
        <h1>Bilgisayardan Elektriğe,<br>Tüm Teknik Çözümler<br><span>Tek Adreste</span></h1>
        <p>Bilgisayar ve elektronik cihaz tamirinden elektrik tesisatına, TV-uydu ve kamera sistemlerine kadar teknik ihtiyaçlarınız için yanınızdayız.</p>
        <div class="bs-actions">
            <a class="bs-button" href="tel:<?= clean(preg_replace('/[^+0-9]/', '', bsPublicPhone())) ?>">Hemen Ara</a>
            <a class="bs-button bs-button-glass" href="<?= url('hizmetler') ?>">Hizmetleri İncele →</a>
        </div>
        <div class="bs-hero-assurances"><span>Teknik değerlendirme</span><span>İhtiyaca uygun çözümler</span><span>İşlem öncesi bilgilendirme</span></div>
    </div>
    <div class="bs-hero-categories">
        <?php foreach ($featured as $item): ?>
        <div class="bs-hero-category"><span><?= clean($item['name']) ?></span></div>
        <?php endforeach; ?>
    </div>
</section>
<section class="bs-home-services" aria-label="Ana hizmetler">
    <div class="container bs-home-card-grid">
        <?php foreach ($featured as $item): ?>
        <a class="bs-home-card" href="<?= url('hizmet/' . $item['slug']) ?>">
            <div class="bs-card-photo <?= bsServicePhotoClass($item) ?>" role="img" aria-label="<?= clean($item['name']) ?> hizmet görseli"></div>
            <div class="bs-home-card-body"><h2><?= clean($item['name']) ?></h2><p><?= clean($item['subtitle']) ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="container">
        <nav class="bs-shortcuts" aria-label="Hizmet detaylarına hızlı erişim">
            <?php foreach ($shortcuts as $i => $item): ?>
            <a href="<?= url('hizmet/' . $item['slug']) ?>"><span class="bs-shortcut-icon" aria-hidden="true"><?= ['▱','⌘','▣','ϟ','⏚','☼','▤','◉','◎','▥','⚙'][$i % 11] ?></span><span><?= clean($item['name']) ?></span></a>
            <?php endforeach; ?>
        </nav>
    </div>
</section>
<section class="bs-why">
    <div class="container bs-why-grid">
        <div><span class="bs-eyebrow">Neden Bilişim Servis?</span><h2>Teknik Serviste<br>Çözüm Ortağınız</h2><p>Bireysel ve kurumsal müşterilerimizin bilgisayar, elektronik, elektrik, TV-uydu, kamera ve küçük ev aletleri ihtiyaçları için bakım ve onarım çözümleri sunuyoruz.</p><a class="bs-button" href="<?= url('hakkimizda') ?>">Hakkımızda →</a></div>
        <ul class="bs-why-list"><li>Cihaz ve ihtiyaca göre değerlendirme</li><li>İşlem öncesinde kapsam ve ücret bilgisi</li><li>Marka ve modele uygun parça seçenekleri</li><li>Bireysel ve kurumsal çözümler</li><li>Bakım, kurulum ve onarım desteği</li></ul>
        <a class="bs-workshop-photo bs-photo-computer" href="<?= url('hizmet/bilgisayar-mac-servis') ?>"><span>Teknolojiye<br>Değer Katıyoruz →</span></a>
    </div>
</section>
<section class="bs-brand-strip" aria-label="Marka ve model değerlendirmesi"><div class="container"><span>Marka ve modele göre<br>teknik değerlendirme</span><strong>Apple</strong><strong>HP</strong><strong>Lenovo</strong><strong>ASUS</strong><strong>Dell</strong><strong>Samsung</strong><strong>Canon</strong><strong>Vestel</strong></div></section>
<section class="bs-audiences"><div class="container bs-home-card-grid">
<?php foreach (array_slice($catalog, 15, 4) as $i => $item): ?>
<a class="bs-audience-card bs-audience-<?= $i ?>" href="<?= url('hizmet/' . $item['slug']) ?>"><span><?= clean(['Evler', 'Ofisler', 'İşletmeler', 'Sanayi'][$i]) ?> →</span></a>
<?php endforeach; ?>
</div></section>
<section class="bs-support-strip"><div class="container">
<?php foreach (array_slice($catalog, 19, 3) as $item): ?>
<a href="<?= url('hizmet/' . $item['slug']) ?>"><strong><?= clean($item['name']) ?> →</strong><span><?= clean($item['subtitle']) ?></span></a>
<?php endforeach; ?>
</div></section>
<section class="bs-section">
    <div class="container"><span class="bs-eyebrow">Hizmetlerimizi keşfedin</span><h2>İhtiyacınıza uygun teknik destek</h2><div class="bs-existing-services">
        <?php foreach ($services ?? [] as $item): ?>
        <a href="<?= url('hizmet/' . ($item['slug'] ?? createSlug($item['name']))) ?>"><span><?= clean($item['name']) ?></span><span aria-hidden="true">→</span></a>
        <?php endforeach; ?>
    </div></div>
</section>
<?php if (!empty($references)): ?>
<section class="bs-section bs-section-tint" id="referanslar"><div class="container"><span class="bs-eyebrow">Referanslar</span><h2>Birlikte çalıştığımız işletmeler</h2><div class="bs-reference-grid">
<?php foreach ($references as $reference): ?>
<div><?php if (!empty($reference['logo_url'])): ?><img loading="lazy" src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" alt="<?= clean($reference['name']) ?>"><?php else: ?><?= clean($reference['name']) ?><?php endif; ?></div>
<?php endforeach; ?>
</div></div></section>
<?php endif; ?>
</main>
