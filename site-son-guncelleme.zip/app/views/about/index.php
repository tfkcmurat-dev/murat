<?php
require_once APP_PATH . '/helpers/service-catalog.php';
$aboutContent = getThemeSetting('about_content', '');
$mainServices = array_slice(bsServiceCatalog(), 0, 4);
?>
<main>
<section class="bs-hero bs-about-hero"><div class="container bs-hero-grid">
<div><span class="bs-eyebrow">Bilişim Servis · Hakkımızda</span><h1>Teknolojiye değer,<br><span>ihtiyacınıza çözüm.</span></h1><p>Bilgisayar, elektrik, elektronik, TV-uydu, kamera ve küçük ev aletleri için teknik servis çözümlerini tek adreste bir araya getiriyoruz.</p><div class="bs-actions"><a class="bs-button" href="<?= url('iletisim') ?>">Bize Ulaşın →</a><a class="bs-button bs-button-light" href="<?= url('hizmetler') ?>">Hizmetlerimizi Keşfedin</a></div></div>
<div class="bs-service-image bs-card-photo bs-photo-computer" role="img" aria-label="Bilgisayar ve teknik servis için temsili çalışma alanı görseli"></div>
</div></section>
<section class="bs-section"><div class="container bs-about-story"><div><span class="bs-eyebrow">Biz kimiz?</span><h2>Teknik ihtiyaçlarınız için<br>aynı noktada buluşalım.</h2></div><div>
<?php if (trim(strip_tags($aboutContent)) !== ''): ?><div class="bs-about-admin-content"><?= cleanHtml($aboutContent) ?></div><?php else: ?><p>Bilişim Servis olarak bireysel ve kurumsal müşterilerimizin cihaz, bakım, kurulum ve onarım ihtiyaçları için çözümler sunuyoruz. Bilgisayar ve elektronik cihazlardan elektrik tesisatına, televizyon ve uydu sistemlerinden güvenlik kameralarına kadar farklı teknik alanlarda ihtiyaca göre değerlendirme yapıyoruz.</p><?php endif; ?>
<p class="bs-about-story-note">Önce ihtiyacınızı dinler, cihazın veya sistemin durumunu değerlendiririz. Yapılabilecek işlemleri, kapsamı ve ücret bilgisini sizinle paylaşır; onayınızla ilerleriz.</p>
</div></div></section>
<section class="bs-section bs-section-tint"><div class="container"><span class="bs-eyebrow">Hizmet alanlarımız</span><h2>Birbirini tamamlayan teknik çözümler.</h2><div class="bs-home-card-grid">
<?php foreach ($mainServices as $item): ?><a class="bs-home-card" href="<?= url('hizmet/' . $item['slug']) ?>"><div class="bs-card-photo <?= bsServicePhotoClass($item) ?>" role="img" aria-label="<?= clean($item['name']) ?> için temsili görsel"></div><div class="bs-home-card-body"><h2><?= clean($item['name']) ?></h2><p><?= clean($item['subtitle']) ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div></a><?php endforeach; ?>
</div></div></section>
<section class="bs-section"><div class="container"><span class="bs-eyebrow">Çalışma yaklaşımımız</span><h2>Her adımda açık iletişim.</h2><div class="bs-steps">
<div class="bs-step"><span class="bs-step-number">01 / DİNLERİZ</span><h3>İhtiyacınızı anlarız</h3><p>Cihaz bilgilerini, yaşadığınız sorunu ve beklentinizi birlikte değerlendiririz.</p></div>
<div class="bs-step"><span class="bs-step-number">02 / BİLGİLENDİRİRİZ</span><h3>Seçenekleri açıklarız</h3><p>İşlem kapsamını, uygun parça seçeneklerini, ücret ve süre bilgisini değerlendirme sonrasında paylaşırız.</p></div>
<div class="bs-step"><span class="bs-step-number">03 / UYGULARIZ</span><h3>Onayınızla ilerleriz</h3><p>Kararlaştırılan uygulamayı tamamlar; yapılan işlemler ve kullanım hakkında bilgi veririz.</p></div>
</div></div></section>
<section class="bs-about-contact"><div class="container"><div><span class="bs-eyebrow">Birlikte çözüm bulalım</span><h2>Teknik bir ihtiyacınız mı var?</h2><p>Cihaz veya sistem bilgilerinizi paylaşın; uygun hizmet kapsamını birlikte belirleyelim.</p></div><a class="bs-button" href="<?= url('iletisim') ?>">İletişime Geç →</a></div></section>
</main>
