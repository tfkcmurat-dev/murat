<?php
require_once __DIR__ . '/app/config/config.php';
require_once APP_PATH . '/helpers/service-catalog.php';
if (getThemeSetting('sitemap_enabled', '1') !== '1') {
    http_response_code(404); exit;
}
header('Content-Type: application/xml; charset=UTF-8');
$urls = ['/', '/hakkimizda', '/hizmetler', '/iletisim'];
if (getThemeSetting('sitemap_include_services', '1') === '1') {
    $active = []; $records = [];
    try {
        $db = Database::getInstance();
        $records = $db->fetchAll('SELECT slug FROM site_services');
        $active = $db->fetchAll('SELECT slug FROM site_services WHERE is_active = 1');
    } catch (Exception $e) { error_log('Sitemap service lookup unavailable'); }
    foreach (bsMergeServices($active, $records) as $item) $urls[] = '/hizmet/' . $item['slug'];
}
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach (array_unique($urls) as $path) {
    echo '  <url><loc>' . htmlspecialchars(bsSeoBaseUrl() . $path, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc></url>' . "\n";
}
echo '</urlset>';
