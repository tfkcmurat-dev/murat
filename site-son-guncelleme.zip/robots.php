<?php
require_once __DIR__ . '/app/config/config.php';
header('Content-Type: text/plain; charset=UTF-8');
echo "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /app/\nDisallow: /vendor/\nDisallow: /logs/\nDisallow: /teklif/\n\nSitemap: " . bsSeoBaseUrl() . "/sitemap.xml\n";
