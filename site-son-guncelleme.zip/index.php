<?php
/**
 * Frontend Ana Giriş Noktası
 * Apache için routing - Ana dizinden çalışır
 */

require_once __DIR__ . '/app/config/config.php';

// Request path'i al
$requestUri = $_SERVER['REQUEST_URI'];
$requestPath = parse_url($requestUri, PHP_URL_PATH);
$requestPath = strtok($requestPath, '?');

// Ana sayfa
if ($requestPath === '/' || $requestPath === '' || $requestPath === '/index.php') {
    require_once APP_PATH . '/controllers/HomeController.php';
    $controller = new HomeController();
    $controller->index();
    exit;
}

// Statik route'lar
$routes = [
    '/hizmetler' => ['controller' => 'ServiceController', 'method' => 'index'],
    '/hakkimizda' => ['controller' => 'AboutController', 'method' => 'index'],
    '/iletisim' => ['controller' => 'ContactController', 'method' => 'index'],
];

// Statik route kontrolü
if (isset($routes[$requestPath])) {
    $route = $routes[$requestPath];
    require_once APP_PATH . '/controllers/' . $route['controller'] . '.php';
    $controller = new $route['controller']();
    $controller->{$route['method']}();
    exit;
}

// Hizmet detay sayfası: /hizmet/[slug]
if (preg_match('#^/hizmet/([a-z0-9-]+)$#', $requestPath, $matches)) {
    $_GET['slug'] = $matches[1];
    require_once APP_PATH . '/controllers/ServiceDetailController.php';
    $controller = new ServiceDetailController();
    $controller->show($matches[1]);
    exit;
}

// Teklif görüntüleme sayfası: /teklif/[quote_number]
if (preg_match('#^/teklif/([A-Za-z0-9-]+)$#', $requestPath, $matches)) {
    $_GET['quote_number'] = $matches[1];
    require_once APP_PATH . '/controllers/QuoteViewController.php';
    $controller = new QuoteViewController();
    $controller->view($matches[1]);
    exit;
}

// Teklif yanıt: /teklif/[quote_number]/yanit
if (preg_match('#^/teklif/([A-Za-z0-9-]+)/yanit$#', $requestPath, $matches)) {
    $_GET['quote_number'] = $matches[1];
    require_once APP_PATH . '/controllers/QuoteViewController.php';
    $controller = new QuoteViewController();
    $controller->respond($matches[1]);
    exit;
}

// sitemap.xml
if ($requestPath === '/sitemap.xml') {
    require_once __DIR__ . '/sitemap.php';
    exit;
}

// robots.txt
if ($requestPath === '/robots.txt') {
    require_once __DIR__ . '/robots.php';
    exit;
}

// Unknown routes must not masquerade as successful homepages.
bsRenderNotFound();
