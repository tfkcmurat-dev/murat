<?php
/**
 * Main Layout Wrapper
 */
require_once __DIR__ . '/header.php';
?>

<main>
    <?php if (isset($content)): ?>
        <?= $content ?>
    <?php endif; ?>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>
