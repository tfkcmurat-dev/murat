<?php
$statusColors = [
    'sent' => '#3b82f6',
    'approved' => '#10b981',
    'rejected' => '#ef4444'
];
$statusLabels = [
    'sent' => 'Beklemede',
    'approved' => 'Onaylandı',
    'rejected' => 'Reddedildi'
];
$customerResponse = $quote['customer_response'] ?? 'pending';
$customerResponseLabels = [
    'pending' => 'Yanıt Bekleniyor',
    'approved' => 'Onaylandı',
    'rejected' => 'Reddedildi',
    'revision_requested' => 'Revize Talep Edildi'
];
?>

<!-- Quote Hero Section -->
<section class="hero-section-pro quote-hero">
    <!-- 3D Background Layers -->
    <div class="hero-bg-layer hero-bg-layer-1"></div>
    <div class="hero-bg-layer hero-bg-layer-2"></div>
    <div class="hero-bg-layer hero-bg-layer-3"></div>
    
    <!-- Animated Grid -->
    <div class="hero-grid-pro"></div>
    
    <!-- Glowing Orbs -->
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 hero-content-pro" style="margin: 0 auto;">
                <!-- Status Badge -->
                <div class="status-badge" style="justify-content: center;">
                    <span class="status-dot"></span>
                    <span class="status-text"><?= clean($quote['quote_number']) ?></span>
                </div>
                
                <!-- Main Title -->
                <h1 class="hero-title-pro" style="text-align: center;">
                    <span class="title-main">Fiyat Teklifiniz</span>
                    <span class="title-highlight"><?= clean($quote['subject']) ?></span>
                </h1>
                
                <!-- Quote Meta -->
                <div class="quote-hero-meta">
                    <div class="meta-item">
                        <span class="meta-badge" style="background: <?= $statusColors[$quote['status']] ?? '#3b82f6' ?>;">
                            <?= $statusLabels[$quote['status']] ?? $quote['status'] ?>
                        </span>
                    </div>
                    <div class="meta-item">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" fill="none" stroke="currentColor" stroke-width="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" stroke-width="2"></line>
                            <line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" stroke-width="2"></line>
                            <line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" stroke-width="2"></line>
                        </svg>
                        <span><?= date('d.m.Y', strtotime($quote['created_at'])) ?></span>
                    </div>
                    <?php if (!empty($quote['valid_until'])): ?>
                    <div class="meta-item validity">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        <span>Geçerlilik: <?= date('d.m.Y', strtotime($quote['valid_until'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bottom Gradient -->
    <div class="hero-bottom-fade"></div>
</section>

<!-- Flash Message -->
<?php if (!empty($flashMessage)): ?>
<section class="flash-section">
    <div class="container">
        <div class="alert-pro alert-<?= $flashType ?>-pro">
            <?php if ($flashType === 'success'): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
            <?php else: ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
            </svg>
            <?php endif; ?>
            <span><?= clean($flashMessage) ?></span>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Customer Response Status -->
<?php if ($customerResponse !== 'pending'): ?>
<section class="response-section">
    <div class="container">
        <div class="response-card <?= $customerResponse ?>">
            <div class="response-icon">
                <?php if ($customerResponse === 'approved'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                <?php elseif ($customerResponse === 'rejected'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/>
                </svg>
                <?php else: ?>
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                </svg>
                <?php endif; ?>
            </div>
            <h3>
                <?php if ($customerResponse === 'approved'): ?>
                    Bu Teklifi Onayladınız
                <?php elseif ($customerResponse === 'rejected'): ?>
                    Bu Teklifi Reddettiniz
                <?php else: ?>
                    Revize Talep Ettiniz
                <?php endif; ?>
            </h3>
            <?php if (!empty($quote['customer_response_date'])): ?>
                <p class="response-date">Yanıt tarihi: <?= date('d.m.Y H:i', strtotime($quote['customer_response_date'])) ?></p>
            <?php endif; ?>
            <?php if ($customerResponse === 'revision_requested' && !empty($quote['customer_response_message'])): ?>
                <div class="response-message">
                    <strong>Mesajınız:</strong>
                    <p><?= nl2br(clean($quote['customer_response_message'])) ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Quote Details Section -->
<section class="quote-details-section">
    <div class="container">
        <!-- Info Cards Grid -->
        <div class="quote-info-grid fade-in-up">
            <div class="quote-info-card-pro">
                <div class="info-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"/>
                    </svg>
                </div>
                <div class="info-card-content">
                    <h4>Müşteri</h4>
                    <p class="main-text"><?= clean($quote['company_name']) ?></p>
                    <?php if (!empty($quote['province']) && !empty($quote['district'])): ?>
                        <p class="sub-text"><?= clean($quote['province']) ?> / <?= clean($quote['district']) ?></p>
                    <?php endif; ?>
                </div>
                <div class="info-card-glow"></div>
            </div>
            
            <div class="quote-info-card-pro">
                <div class="info-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                    </svg>
                </div>
                <div class="info-card-content">
                    <h4>İletişim</h4>
                    <?php if (!empty($quote['phone'])): ?>
                        <p class="main-text">
                            <a href="tel:<?= clean($quote['phone']) ?>"><?= clean($quote['phone']) ?></a>
                        </p>
                    <?php endif; ?>
                    <?php if (!empty($quote['email'])): ?>
                        <p class="sub-text">
                            <a href="mailto:<?= clean($quote['email']) ?>"><?= clean($quote['email']) ?></a>
                        </p>
                    <?php endif; ?>
                </div>
                <div class="info-card-glow"></div>
            </div>
            
            <div class="quote-info-card-pro highlight">
                <div class="info-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
                    </svg>
                </div>
                <div class="info-card-content">
                    <h4>Toplam Tutar</h4>
                    <p class="main-text grand-total"><?= formatMoney($quote['grand_total']) ?></p>
                    <p class="sub-text">KDV Dahil</p>
                </div>
                <div class="info-card-glow"></div>
            </div>
        </div>
        
        <!-- Quote Items Table -->
        <div class="quote-items-wrapper fade-in-up">
            <div class="items-header">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/>
                </svg>
                <h3>Teklif Kalemleri</h3>
            </div>
            
            <div class="items-table-wrapper">
                <table class="quote-items-table-pro">
                    <thead>
                        <tr>
                            <th>Hizmet / Ürün</th>
                            <th class="text-center">Miktar</th>
                            <th class="text-right">Birim Fiyat</th>
                            <th class="text-center">KDV</th>
                            <th class="text-right">Toplam</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($quote['items'] as $item): ?>
                        <tr>
                            <td>
                                <div class="item-name"><?= clean($item['item_name']) ?></div>
                                <?php if (!empty($item['description'])): ?>
                                    <div class="item-desc"><?= clean($item['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?= number_format($item['quantity'], 0, ',', '.') ?></td>
                            <td class="text-right"><?= formatMoney($item['unit_price']) ?></td>
                            <td class="text-center">%<?= number_format($item['tax_rate'], 0) ?></td>
                            <td class="text-right item-total"><?= formatMoney($item['total']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Totals -->
            <div class="quote-totals-pro">
                <div class="totals-row">
                    <span>Ara Toplam</span>
                    <span><?= formatMoney($quote['subtotal']) ?></span>
                </div>
                <div class="totals-row">
                    <span>KDV Toplamı</span>
                    <span><?= formatMoney($quote['tax_total']) ?></span>
                </div>
                <?php if ($quote['discount_total'] > 0): ?>
                <div class="totals-row discount">
                    <span>İndirim</span>
                    <span>-<?= formatMoney($quote['discount_total']) ?></span>
                </div>
                <?php endif; ?>
                <div class="totals-row grand">
                    <span>Genel Toplam</span>
                    <span><?= formatMoney($quote['grand_total']) ?></span>
                </div>
            </div>
        </div>
        
        <!-- Customer Note -->
        <?php if (!empty($quote['customer_note'])): ?>
        <div class="quote-note-wrapper fade-in-up">
            <div class="note-header">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                </svg>
                <h3>Notlar ve Koşullar</h3>
            </div>
            <div class="note-content">
                <?= nl2br(clean($quote['customer_note'])) ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Action Section (Only for pending quotes) -->
<?php if ($quote['status'] === 'sent' && $customerResponse === 'pending'): ?>
<section class="quote-action-section">
    <div class="container">
        <div class="action-wrapper fade-in-up">
            <div class="action-bg-elements">
                <div class="action-circle action-circle-1"></div>
                <div class="action-circle action-circle-2"></div>
            </div>
            <div class="action-content">
                <h2>Bu Teklif Hakkında Kararınız</h2>
                <p>Lütfen teklifi inceledikten sonra aşağıdaki seçeneklerden birini seçin.</p>
                
                <div class="action-buttons">
                    <form method="POST" action="<?= url('teklif/' . $quote['quote_number'] . '/yanit') ?>" style="display: inline;">
                        <input type="hidden" name="response" value="approved">
                        <button type="submit" class="action-btn approve" onclick="return confirm('Bu teklifi onaylamak istediğinize emin misiniz?')">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                            <span>Teklifi Kabul Et</span>
                        </button>
                    </form>
                    
                    <form method="POST" action="<?= url('teklif/' . $quote['quote_number'] . '/yanit') ?>" style="display: inline;">
                        <input type="hidden" name="response" value="rejected">
                        <button type="submit" class="action-btn reject" onclick="return confirm('Bu teklifi reddetmek istediğinize emin misiniz?')">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/>
                            </svg>
                            <span>Teklifi Reddet</span>
                        </button>
                    </form>
                    
                    <button type="button" class="action-btn revision" onclick="document.getElementById('revisionModal').classList.add('active')">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                        </svg>
                        <span>Revize Talep Et</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Revision Modal -->
<div id="revisionModal" class="revision-modal">
    <div class="revision-modal-content">
        <button type="button" class="modal-close" onclick="document.getElementById('revisionModal').classList.remove('active')">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
        </button>
        <div class="modal-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
            </svg>
        </div>
        <h3>Revize Talebi</h3>
        <p>Lütfen teklifte değiştirilmesini istediğiniz kısımları ve nedenlerini belirtin.</p>
        
        <form method="POST" action="<?= url('teklif/' . $quote['quote_number'] . '/yanit') ?>">
            <input type="hidden" name="response" value="revision_requested">
            <textarea name="message" class="form-input-pro" placeholder="Revize talebinizi buraya yazın... (zorunlu)" required></textarea>
            
            <div class="modal-buttons">
                <button type="button" class="modal-btn cancel" onclick="document.getElementById('revisionModal').classList.remove('active')">
                    İptal
                </button>
                <button type="submit" class="modal-btn submit">
                    Revize Talebi Gönder
                </button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- CTA Section -->
<section class="cta-section-pro">
    <div class="container">
        <div class="cta-wrapper-pro fade-in-up">
            <div class="cta-bg-elements">
                <div class="cta-circle cta-circle-1"></div>
                <div class="cta-circle cta-circle-2"></div>
                <div class="cta-circle cta-circle-3"></div>
            </div>
            <div class="cta-content-pro">
                <h2 class="cta-title-pro">Sorularınız mı var?</h2>
                <p class="cta-desc-pro">Bu teklif hakkında daha fazla bilgi almak için bizimle iletişime geçebilirsiniz.</p>
                <div class="cta-buttons-pro">
                    <a href="<?= url('iletisim') ?>" class="cta-btn-primary">
                        <span>İletişime Geçin</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="tel:<?= getThemeSetting('contact_phone', '05548634870') ?>" class="cta-btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                        <span>Bizi Arayın</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Quote Hero */
.quote-hero {
    min-height: 50vh;
    padding-top: 120px;
    padding-bottom: 60px;
}

.quote-hero-meta {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 24px;
    flex-wrap: wrap;
    margin-top: 24px;
}

.quote-hero-meta .meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
    color: rgba(255,255,255,0.7);
    font-size: 0.95rem;
}

.quote-hero-meta .meta-badge {
    padding: 8px 20px;
    border-radius: 30px;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
}

.quote-hero-meta .meta-item.validity {
    background: rgba(245, 158, 11, 0.15);
    padding: 8px 16px;
    border-radius: 8px;
    color: #f59e0b;
}

/* Flash Section */
.flash-section {
    padding: 20px 0;
    background: #0a0a1a;
}

.alert-pro {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 24px;
    border-radius: 12px;
    max-width: 600px;
    margin: 0 auto;
}

.alert-success-pro {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #10B981;
}

.alert-error-pro {
    background: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #EF4444;
}

/* Response Section */
.response-section {
    padding: 40px 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #12122a 100%);
}

.response-card {
    max-width: 600px;
    margin: 0 auto;
    text-align: center;
    padding: 40px;
    border-radius: 20px;
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 2px solid rgba(255,255,255,0.1);
}

.response-card.approved {
    border-color: rgba(16, 185, 129, 0.5);
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.02) 100%);
}

.response-card.approved .response-icon {
    color: #10b981;
}

.response-card.rejected {
    border-color: rgba(239, 68, 68, 0.5);
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(239, 68, 68, 0.02) 100%);
}

.response-card.rejected .response-icon {
    color: #ef4444;
}

.response-card.revision_requested {
    border-color: rgba(245, 158, 11, 0.5);
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(245, 158, 11, 0.02) 100%);
}

.response-card.revision_requested .response-icon {
    color: #f59e0b;
}

.response-icon {
    margin-bottom: 16px;
}

.response-card h3 {
    color: white;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.response-date {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.response-message {
    background: rgba(0,0,0,0.2);
    padding: 16px;
    border-radius: 12px;
    text-align: left;
    margin-top: 16px;
}

.response-message strong {
    color: rgba(255,255,255,0.8);
    display: block;
    margin-bottom: 8px;
}

.response-message p {
    color: rgba(255,255,255,0.7);
    margin: 0;
    line-height: 1.6;
}

/* Quote Details Section */
.quote-details-section {
    padding: 60px 0;
    background: linear-gradient(180deg, #12122a 0%, #0a0a1a 100%);
}

/* Info Cards Grid */
.quote-info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
    margin-bottom: 40px;
}

.quote-info-card-pro {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 28px;
    display: flex;
    align-items: flex-start;
    gap: 20px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.quote-info-card-pro:hover {
    transform: translateY(-5px);
    border-color: rgba(0, 102, 255, 0.5);
}

.quote-info-card-pro.highlight {
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.15) 0%, rgba(0, 212, 255, 0.05) 100%);
    border-color: rgba(0, 212, 255, 0.3);
}

.info-card-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.info-card-icon svg {
    width: 28px;
    height: 28px;
    color: white;
}

.info-card-content h4 {
    color: rgba(255,255,255,0.5);
    font-size: 0.85rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 8px;
}

.info-card-content .main-text {
    color: white;
    font-size: 1.15rem;
    font-weight: 600;
    margin: 0 0 4px;
}

.info-card-content .main-text a {
    color: #00D4FF;
    text-decoration: none;
    transition: color 0.3s;
}

.info-card-content .main-text a:hover {
    color: white;
}

.info-card-content .sub-text {
    color: rgba(255,255,255,0.6);
    font-size: 0.9rem;
    margin: 0;
}

.info-card-content .sub-text a {
    color: rgba(255,255,255,0.6);
    text-decoration: none;
}

.info-card-content .grand-total {
    font-size: 1.5rem;
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.info-card-glow {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 3px;
    background: linear-gradient(90deg, #0066FF, #00D4FF);
    transition: width 0.3s ease;
}

.quote-info-card-pro:hover .info-card-glow {
    width: 100%;
}

/* Items Wrapper */
.quote-items-wrapper {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    overflow: hidden;
    margin-bottom: 40px;
}

.items-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 24px 28px;
    background: linear-gradient(135deg, #0066FF 0%, #00D4FF 100%);
    color: white;
}

.items-header h3 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
}

.items-table-wrapper {
    overflow-x: auto;
}

.quote-items-table-pro {
    width: 100%;
    border-collapse: collapse;
}

.quote-items-table-pro th {
    background: rgba(0, 102, 255, 0.1);
    padding: 16px 20px;
    text-align: left;
    font-size: 0.85rem;
    font-weight: 600;
    color: rgba(255,255,255,0.7);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.quote-items-table-pro td {
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.05);
    color: rgba(255,255,255,0.8);
}

.quote-items-table-pro tr:last-child td {
    border-bottom: none;
}

.quote-items-table-pro .item-name {
    font-weight: 600;
    color: white;
    margin-bottom: 4px;
}

.quote-items-table-pro .item-desc {
    font-size: 0.85rem;
    color: rgba(255,255,255,0.5);
}

.quote-items-table-pro .text-center {
    text-align: center;
}

.quote-items-table-pro .text-right {
    text-align: right;
}

.quote-items-table-pro .item-total {
    font-weight: 700;
    color: #00D4FF;
}

/* Totals */
.quote-totals-pro {
    background: rgba(0, 102, 255, 0.05);
    padding: 24px 28px;
}

.quote-totals-pro .totals-row {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    color: rgba(255,255,255,0.7);
    max-width: 350px;
    margin-left: auto;
}

.quote-totals-pro .totals-row.discount span:last-child {
    color: #10b981;
}

.quote-totals-pro .totals-row.grand {
    margin-top: 12px;
    padding-top: 16px;
    border-top: 2px solid rgba(255,255,255,0.1);
    font-size: 1.3rem;
    font-weight: 700;
    color: white;
}

.quote-totals-pro .totals-row.grand span:last-child {
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Note Wrapper */
.quote-note-wrapper {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    overflow: hidden;
}

.note-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 20px 28px;
    background: rgba(0, 102, 255, 0.1);
    color: #00D4FF;
}

.note-header h3 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: white;
}

.note-content {
    padding: 24px 28px;
    color: rgba(255,255,255,0.7);
    line-height: 1.8;
}

/* Action Section */
.quote-action-section {
    padding: 60px 0;
    background: #0a0a1a;
}

.action-wrapper {
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.15) 0%, rgba(0, 212, 255, 0.05) 100%);
    border: 1px solid rgba(0, 212, 255, 0.3);
    border-radius: 24px;
    padding: 60px;
    position: relative;
    overflow: hidden;
    text-align: center;
}

.action-bg-elements {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.action-circle {
    position: absolute;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(0, 102, 255, 0.2), rgba(0, 212, 255, 0.1));
}

.action-circle-1 {
    width: 200px;
    height: 200px;
    top: -100px;
    right: -50px;
}

.action-circle-2 {
    width: 150px;
    height: 150px;
    bottom: -75px;
    left: -30px;
}

.action-content {
    position: relative;
    z-index: 1;
}

.action-content h2 {
    font-size: 2rem;
    font-weight: 700;
    color: white;
    margin-bottom: 12px;
}

.action-content p {
    color: rgba(255,255,255,0.7);
    font-size: 1.1rem;
    margin-bottom: 40px;
}

.action-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 18px 36px;
    border-radius: 14px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.3s ease;
}

.action-btn.approve {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
}

.action-btn.approve:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(16, 185, 129, 0.4);
}

.action-btn.reject {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    color: white;
}

.action-btn.reject:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(239, 68, 68, 0.4);
}

.action-btn.revision {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
}

.action-btn.revision:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 40px rgba(245, 158, 11, 0.4);
}

/* Revision Modal */
.revision-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    backdrop-filter: blur(5px);
    z-index: 1000;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.revision-modal.active {
    display: flex;
}

.revision-modal-content {
    background: linear-gradient(135deg, #12122a 0%, #1a1a3a 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 40px;
    max-width: 500px;
    width: 100%;
    position: relative;
    text-align: center;
}

.modal-close {
    position: absolute;
    top: 16px;
    right: 16px;
    background: rgba(255,255,255,0.1);
    border: none;
    border-radius: 10px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(255,255,255,0.6);
    cursor: pointer;
    transition: all 0.3s;
}

.modal-close:hover {
    background: rgba(255,255,255,0.2);
    color: white;
}

.modal-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.2) 0%, rgba(245, 158, 11, 0.1) 100%);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    color: #f59e0b;
}

.revision-modal-content h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 12px;
}

.revision-modal-content > p {
    color: rgba(255,255,255,0.6);
    margin-bottom: 24px;
}

.revision-modal-content textarea {
    width: 100%;
    min-height: 150px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    padding: 16px;
    color: white;
    font-size: 1rem;
    resize: vertical;
    margin-bottom: 24px;
}

.revision-modal-content textarea:focus {
    outline: none;
    border-color: #f59e0b;
}

.revision-modal-content textarea::placeholder {
    color: rgba(255,255,255,0.4);
}

.modal-buttons {
    display: flex;
    gap: 12px;
    justify-content: center;
}

.modal-btn {
    padding: 14px 28px;
    border-radius: 10px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.modal-btn.cancel {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
}

.modal-btn.cancel:hover {
    background: rgba(255,255,255,0.2);
}

.modal-btn.submit {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    border: none;
    color: white;
}

.modal-btn.submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(245, 158, 11, 0.3);
}

/* Responsive */
@media (max-width: 992px) {
    .quote-info-grid {
        grid-template-columns: 1fr;
    }
    
    .quote-hero {
        min-height: auto;
        padding: 140px 0 40px;
    }
    
    .action-wrapper {
        padding: 40px 24px;
    }
    
    .action-content h2 {
        font-size: 1.5rem;
    }
}

@media (max-width: 768px) {
    .quote-hero-meta {
        flex-direction: column;
        gap: 12px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .action-btn {
        width: 100%;
        justify-content: center;
    }
    
    .quote-items-table-pro th,
    .quote-items-table-pro td {
        padding: 12px;
        font-size: 0.9rem;
    }
}
</style>

<script>
// Modal dışına tıklayınca kapat
document.getElementById('revisionModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        this.classList.remove('active');
    }
});

// ESC tuşu ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('revisionModal')?.classList.remove('active');
    }
});
</script>
