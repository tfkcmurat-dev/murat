<style>
.not-found-container {
    max-width: 600px;
    margin: 100px auto;
    text-align: center;
    padding: 40px 20px;
}

.not-found-icon {
    width: 120px;
    height: 120px;
    margin: 0 auto 32px;
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.2));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.not-found-icon svg {
    width: 60px;
    height: 60px;
    stroke: #ef4444;
}

.not-found-title {
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 16px;
}

.not-found-message {
    color: var(--text-secondary);
    font-size: 1.1rem;
    line-height: 1.7;
    margin-bottom: 32px;
}

.not-found-btn {
    display: inline-block;
    background: linear-gradient(135deg, #0066FF, #00D4FF);
    color: white;
    padding: 14px 32px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
    transition: transform 0.3s, box-shadow 0.3s;
}

.not-found-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
    color: white;
}
</style>

<div class="not-found-container">
    <div class="not-found-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
    </div>
    
    <h1 class="not-found-title">Teklif Bulunamadı</h1>
    
    <p class="not-found-message">
        Aradığınız teklif bulunamadı veya artık mevcut değil. 
        Lütfen teklif numarasını kontrol edin veya bizimle iletişime geçin.
    </p>
    
    <a href="<?= url('iletisim') ?>" class="not-found-btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
            <polyline points="22,6 12,13 2,6"></polyline>
        </svg>
        İletişime Geçin
    </a>
</div>
