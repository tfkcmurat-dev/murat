<div class="bs-appliance-groups">
<?php foreach ($applianceGroups as $key => $group): ?>
<details class="bs-appliance-subgroup">
<summary><span><?= clean($group['name']) ?></span><span class="bs-category-count"><?= count($group['services']) ?> cihaz</span><span aria-hidden="true">+</span></summary>
<div class="bs-service-list-grid bs-category-content">
<?php foreach ($group['services'] as $item): ?>
<a class="bs-home-card" href="<?= url('hizmet/' . $item['slug']) ?>"><div class="bs-card-photo <?= bsServicePhotoClass($item) ?>" role="img" aria-label="<?= clean($item['name']) ?> için temsili cihaz grubu görseli"></div><div class="bs-home-card-body"><h2><?= clean($item['name']) ?></h2><p><?= clean($item['subtitle'] ?? '') ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div></a>
<?php endforeach; ?>
</div></details>
<?php endforeach; ?>
</div>
