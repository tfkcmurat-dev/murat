<?php
/**
 * Yardımcı Fonksiyonlar
 */

/**
 * View dosyasını render et
 */
function view($viewPath, $data = []) {
    extract($data);
    $viewFile = APP_PATH . '/views/' . $viewPath . '.php';
    
    if (!file_exists($viewFile)) {
        die("View dosyası bulunamadı: {$viewPath}");
    }
    
    require_once $viewFile;
}

/**
 * Admin view dosyasını render et
 */
function adminView($viewPath, $data = []) {
    extract($data);
    $viewFile = ADMIN_PATH . '/views/' . $viewPath . '.php';
    
    if (!file_exists($viewFile)) {
        die("Admin view dosyası bulunamadı: {$viewPath}");
    }
    
    require_once $viewFile;
}

/**
 * URL oluştur
 */
function url($path = '') {
    return BASE_URL . '/' . ltrim($path, '/');
}

/**
 * Admin URL oluştur
 */
function adminUrl($path = '') {
    return ADMIN_URL . '/' . ltrim($path, '/');
}

/**
 * Asset URL oluştur
 */
function asset($path) {
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

/**
 * Görsel URL'ini normalize et (localhost URL'lerini düzelt)
 */
function normalizeImageUrl($url) {
    if (empty($url)) {
        return '';
    }
    
    // Eğer URL zaten tam bir URL ise (http:// veya https:// ile başlıyorsa)
    if (preg_match('/^https?:\/\//', $url)) {
        // localhost URL'lerini mevcut domain ile değiştir
        if (preg_match('/localhost|127\.0\.0\.1|::1/', $url)) {
            $path = parse_url($url, PHP_URL_PATH);
            return BASE_URL . $path;
        }
        return $url;
    }
    
    // Relative path ise BASE_URL ekle
    return BASE_URL . '/' . ltrim($url, '/');
}

/**
 * Yönlendirme yap
 */
function redirect($url) {
    header("Location: " . $url);
    exit;
}

/**
 * Flash mesaj ayarla
 */
function setFlash($key, $message) {
    $_SESSION['flash'][$key] = $message;
}

/**
 * Flash mesaj al ve temizle
 */
function getFlash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    return null;
}

/**
 * Tema ayarı getir
 */
function getThemeSetting($key, $default = '') {
    $db = Database::getInstance();
    $setting = $db->fetch(
        "SELECT setting_value FROM theme_settings WHERE setting_key = ?",
        [$key]
    );
    
    return $setting ? $setting['setting_value'] : $default;
}

/**
 * Tema ayarı kaydet
 */
function setThemeSetting($key, $value, $type = 'text', $group = 'general', $description = null) {
    $db = Database::getInstance();
    
    // Mevcut ayarı kontrol et
    $existing = $db->fetch(
        "SELECT id FROM theme_settings WHERE setting_key = ?",
        [$key]
    );
    
    if ($existing) {
        // Güncelle
        $db->update('theme_settings', [
            'setting_value' => $value,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'setting_key = ?', [$key]);
    } else {
        // Yeni ekle
        $db->insert('theme_settings', [
            'setting_key' => $key,
            'setting_value' => $value,
            'setting_type' => $type,
            'group_name' => $group,
            'description' => $description
        ]);
    }
}

/**
 * Tarih formatla
 */
function formatDate($date, $format = 'd.m.Y') {
    if (empty($date)) {
        return '';
    }
    return date($format, strtotime($date));
}

/**
 * Para formatla
 */
function formatMoney($amount, $currency = '₺') {
    return number_format($amount, 2, ',', '.') . ' ' . $currency;
}

/**
 * Slug oluştur
 */
function createSlug($text) {
    $turkish = ['ş', 'Ş', 'ı', 'İ', 'ğ', 'Ğ', 'ü', 'Ü', 'ö', 'Ö', 'ç', 'Ç'];
    $english = ['s', 'S', 'i', 'I', 'g', 'G', 'u', 'U', 'o', 'O', 'c', 'C'];
    $text = str_replace($turkish, $english, $text);
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

/**
 * Teklif numarası oluştur
 */
function generateQuoteNumber() {
    $db = Database::getInstance();
    $year = date('Y');
    $month = date('m');
    
    // Bu ayki son numarayı bul
    $lastQuote = $db->fetch(
        "SELECT quote_number FROM quotes WHERE quote_number LIKE ? ORDER BY id DESC LIMIT 1",
        ["TEK-{$year}{$month}-%"]
    );
    
    if ($lastQuote) {
        $parts = explode('-', $lastQuote['quote_number']);
        $lastNum = (int)end($parts);
        $newNum = $lastNum + 1;
    } else {
        $newNum = 1;
    }
    
    return sprintf("TEK-%s%s-%04d", $year, $month, $newNum);
}

/**
 * Aktif kullanıcı kontrolü
 */
function isLoggedIn() {
    if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
        return false;
    }
    
    // Session timeout kontrolü (1 saat)
    if (isset($_SESSION['login_time'])) {
        $sessionLifetime = defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 3600;
        if (time() - $_SESSION['login_time'] > $sessionLifetime) {
            // Session süresi dolmuş
            session_destroy();
            session_start();
            return false;
        }
    }
    
    // Session fingerprint kontrolü
    if (function_exists('validateSessionFingerprint') && !validateSessionFingerprint()) {
        // Session hijacking şüphesi
        session_destroy();
        session_start();
        return false;
    }
    
    return true;
}

/**
 * Admin kontrolü
 */
function requireAuth() {
    if (!isLoggedIn()) {
        // Session'da mesaj bırak
        setFlash('error', 'Bu sayfaya erişmek için giriş yapmalısınız.');
        redirect(adminUrl('login.php'));
    }
    
    // Activity timeout - son aktiviteden 30 dakika geçmişse uyar
    if (isset($_SESSION['last_activity'])) {
        $inactiveTime = time() - $_SESSION['last_activity'];
        if ($inactiveTime > 1800) { // 30 dakika
            setFlash('warning', 'Uzun süredir aktif değilsiniz. Güvenliğiniz için tekrar giriş yapmanız önerilir.');
        }
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Debug için var_dump wrapper
 */
function dd($data) {
    echo '<pre>';
    var_dump($data);
    echo '</pre>';
    die();
}
