<?php
/** Public service content; no database writes. Existing records take precedence. */
function bsServiceCatalog() {
    return json_decode(<<<'CATALOG_JSON'
[
  {
    "id": "catalog-bilgisayar-mac-servis",
    "slug": "bilgisayar-mac-servis",
    "name": "Bilgisayar & Mac Servis",
    "subtitle": "Bilgisayar, MacBook, iMac ve laptop için onarım, bakım ve performans çözümleri.",
    "description": "Cihazınızın açılmaması, yavaş çalışması veya ısınması gibi sorunları donanım ve yazılım açısından değerlendiriyoruz. Yapılacak işlemleri ve parça seçeneklerini sizinle paylaşarak onayınız doğrultusunda ilerliyoruz.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Arıza tespiti ve donanım kontrolü\", \"İşletim sistemi ve yazılım kurulumu\", \"SSD ve bellek yükseltme\", \"Soğutma sistemi temizliği ve bakım\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektrik-elektronik",
    "slug": "elektrik-elektronik",
    "name": "Elektrik & Elektronik",
    "subtitle": "Elektrik tesisatı, aydınlatma ve elektronik cihazlar için teknik çözümler.",
    "description": "Ev ve iş yerlerindeki elektrik ve elektronik ihtiyaçlarını işin kapsamına göre değerlendiriyoruz. Tesisatın mevcut durumu incelenerek uygun malzeme ve uygulama seçenekleri belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Priz ve sigorta kontrolü\", \"Aydınlatma ve avize montajı\", \"Elektrik tesisatı arıza tespiti\", \"Elektronik devre değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tv-uydu-kamera",
    "slug": "tv-uydu-kamera",
    "name": "TV - Uydu - Kamera",
    "subtitle": "Televizyon tamiri, uydu kurulumu ve güvenlik kamera sistemleri.",
    "description": "Görüntü, sinyal ve kayıt sorunları için cihaz ve bağlantıları birlikte inceliyoruz. Televizyon, uydu ve kamera sistemlerinde ihtiyacınıza uygun kurulum veya onarım sürecini planlıyoruz.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Televizyon arıza tespiti\", \"Uydu anteni ve kanal ayarı\", \"Kamera sistemi planlaması\", \"Kayıt ve görüntü bağlantılarının kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kucuk-ev-aletleri-tamiri",
    "slug": "kucuk-ev-aletleri-tamiri",
    "name": "Küçük Ev Aletleri Tamiri",
    "subtitle": "Kişisel bakım, mutfak, temizlik, ütü ve ev konforu cihazları için bakım ve onarım değerlendirmesi.",
    "description": "Fön makinesi, saç maşası, kahve makinesi, airfryer, süpürge, ütü ve diğer küçük ev aletlerinin çalışma sorunlarını marka ve modele göre inceliyoruz. Uygun parça seçenekleri, onarım imkânı, işlem süresi ve ücret inceleme sonrasında paylaşılır.",
    "category": "appliance",
    "icon": "settings",
    "image": "",
    "features": "[\"Cihaz ve model değerlendirmesi\", \"Güç ve çalışma kontrolü\", \"Uygun parça seçenekleri\", \"Onarım sonrası işlev kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-bilgisayar-tamiri",
    "slug": "bilgisayar-tamiri",
    "name": "Bilgisayar Tamiri",
    "subtitle": "Masaüstü ve dizüstü bilgisayarlarda donanım ve yazılım arızaları.",
    "description": "Bilgisayarınızdaki sorunun kaynağını belirlemek için güç, depolama, bellek ve yazılım bileşenlerini kontrol ediyoruz. Veri içeren işlemlerden önce yedekleme ihtiyacını sizinle değerlendiriyoruz.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Açılmama ve görüntü sorunları\", \"Isınma ve fan kontrolü\", \"Disk ve bellek değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-macbook-imac-servis",
    "slug": "macbook-imac-servis",
    "name": "MacBook & iMac Servis",
    "subtitle": "Apple bilgisayarlar için bakım ve onarım değerlendirmesi.",
    "description": "MacBook ve iMac cihazlarda performans, açılış ve donanım sorunlarını modelin özelliklerine göre inceliyoruz. İşlem ve parça uygunluğu cihaz değerlendirmesi sonrasında belirlenir.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Model bazlı arıza tespiti\", \"Depolama ve sistem kontrolü\", \"Soğutma bakımı\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-donanim-yukseltme",
    "slug": "donanim-yukseltme",
    "name": "Donanım Yükseltme",
    "subtitle": "Uyumlu SSD ve bellek seçenekleriyle cihaz performansını geliştirin.",
    "description": "Mevcut bilgisayarınızın ihtiyaçlarını ve yükseltme sınırlarını kontrol ediyoruz. Uyumlu parçalar, veri aktarımı ve kurulum seçenekleri işlem öncesinde sizinle paylaşılır.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"SSD uyumluluk kontrolü\", \"RAM kapasitesi değerlendirmesi\", \"Veri aktarımı planlaması\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektrik-tesisati",
    "slug": "elektrik-tesisati",
    "name": "Elektrik Tesisatı",
    "subtitle": "Ev ve iş yerleri için tesisat kontrolü ve elektrik uygulamaları.",
    "description": "Elektrik tesisatının durumunu ve kullanım ihtiyacını yerinde inceleyerek yapılacak işlemleri planlıyoruz. Uygulama kapsamı ve malzeme seçimi inceleme sonrasında netleştirilir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Tesisat arıza tespiti\", \"Hat ve bağlantı kontrolü\", \"İhtiyaca uygun uygulama planı\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-priz-sigorta-aydinlatma",
    "slug": "priz-sigorta-aydinlatma",
    "name": "Priz - Sigorta - Aydınlatma",
    "subtitle": "Priz, anahtar, sigorta ve aydınlatma sorunları için destek.",
    "description": "Çalışmayan priz, atan sigorta veya aydınlatma problemlerinde bağlantı ve kullanım koşullarını birlikte değerlendiriyoruz. Uygun çözüm, arızanın kaynağı tespit edildikten sonra belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Priz ve anahtar kontrolü\", \"Sigorta arızalarının değerlendirilmesi\", \"Aydınlatma bağlantıları\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-avize-montaji",
    "slug": "avize-montaji",
    "name": "Avize Montajı",
    "subtitle": "Avize ve aydınlatma ürünleri için montaj desteği.",
    "description": "Avizenin ağırlığı, montaj yüzeyi ve elektrik bağlantıları değerlendirilerek montaj planlanır. İşlem öncesinde ürün bilgisi ve montaj yerinin fotoğrafı hazırlık sürecine yardımcı olur.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Montaj noktasının kontrolü\", \"Ürün ve bağlantı uygunluğu\", \"Montaj sonrası çalışma kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tv-tamiri",
    "slug": "tv-tamiri",
    "name": "TV Tamiri",
    "subtitle": "Televizyonlarda görüntü, ses ve açılma sorunlarının değerlendirilmesi.",
    "description": "Televizyonunuzun marka, model ve arıza belirtisine göre inceleme yapıyoruz. Ekran, güç veya bağlantı kaynaklı sorunlar için onarım seçenekleri değerlendirme sonrasında paylaşılır.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Görüntü ve ses kontrolü\", \"Güç ve bağlantı değerlendirmesi\", \"Model bazlı parça uygunluğu\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-uydu-sistemleri",
    "slug": "uydu-sistemleri",
    "name": "Uydu Sistemleri",
    "subtitle": "Uydu anteni, sinyal ve kanal ayarlama işlemleri.",
    "description": "Sinyal kaybı ve kanal sorunlarında anten, kablo ve uydu alıcısını birlikte kontrol ediyoruz. Kurulum veya ayar işlemleri mevcut sistemin durumuna göre planlanır.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Anten ve kablo kontrolü\", \"Sinyal değerlendirmesi\", \"Kanal ve alıcı ayarları\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kamera-sistemleri",
    "slug": "kamera-sistemleri",
    "name": "Kamera Sistemleri",
    "subtitle": "Ev ve işletmeler için görüntüleme ve kayıt çözümleri.",
    "description": "Kamera sistemini izlemek istediğiniz alan ve kayıt ihtiyacına göre planlıyoruz. Mevcut sistemlerde görüntü ve bağlantı sorunları değerlendirilerek uygun çözüm seçenekleri sunulur.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Görüntüleme alanının planlanması\", \"Kamera ve kayıt cihazı seçimi\", \"Bağlantı ve kayıt kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-yazici-toner-servisi",
    "slug": "yazici-toner-servisi",
    "name": "Yazıcı & Toner Servisi",
    "subtitle": "Yazıcı kurulumu, baskı sorunları ve toner değerlendirmesi.",
    "description": "Yazıcılarda baskı kalitesi, kağıt besleme ve bağlantı sorunlarını model bilgisiyle birlikte değerlendiriyoruz. Toner ve diğer sarf malzemeleri cihaz uyumluluğuna göre seçilir.",
    "category": "computer",
    "icon": "printer",
    "image": "",
    "features": "[\"Baskı kalitesinin kontrolü\", \"Bağlantı ve sürücü kurulumu\", \"Modele uygun sarf malzemesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektronik-onarim",
    "slug": "elektronik-onarim",
    "name": "Elektronik Onarım",
    "subtitle": "Elektronik cihaz ve devrelerde arıza değerlendirmesi.",
    "description": "Elektronik cihazlardaki çalışma problemlerini cihazın kullanım alanı ve arıza belirtilerine göre inceliyoruz. Parça bulunabilirliği ve onarım uygunluğu değerlendirme sonrasında belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Cihaz ve devre incelemesi\", \"Güç ve bileşen kontrolü\", \"Onarım uygunluğu değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-evler-icin-teknik-servis",
    "slug": "evler-icin-teknik-servis",
    "name": "Evler İçin Teknik Servis",
    "subtitle": "Evde kullanılan bilgisayar, elektrik, TV, uydu ve küçük ev aletleri için destek.",
    "category": "appliance",
    "icon": "settings",
    "image": "",
    "description": "Evde kullanılan bilgisayar, elektrik, TV, uydu ve küçük ev aletleri için destek. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"İhtiyacın ve cihazın değerlendirilmesi\", \"Uygun bakım ve onarım seçenekleri\", \"İşlem öncesinde kapsam bilgisi\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-ofisler-icin-teknik-servis",
    "slug": "ofisler-icin-teknik-servis",
    "name": "Ofisler İçin Teknik Servis",
    "subtitle": "Ofis bilgisayarları, yazıcılar ve teknik altyapı için bakım ve destek.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Ofis bilgisayarları, yazıcılar ve teknik altyapı için bakım ve destek. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Bilgisayar ve yazıcı kontrolü\", \"Kurulum ve bağlantı değerlendirmesi\", \"Bakım ihtiyaçlarının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-isletmeler-icin-teknik-servis",
    "slug": "isletmeler-icin-teknik-servis",
    "name": "İşletmeler İçin Teknik Servis",
    "subtitle": "İşletmelerin cihaz ve teknik sistem ihtiyaçlarına yönelik çözümler.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "description": "İşletmelerin cihaz ve teknik sistem ihtiyaçlarına yönelik çözümler. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"İşletmenin ihtiyaçlarının değerlendirilmesi\", \"Kamera ve cihaz sistemi kontrolü\", \"İş kapsamının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-sanayi-icin-teknik-servis",
    "slug": "sanayi-icin-teknik-servis",
    "name": "Sanayi İçin Teknik Servis",
    "subtitle": "Elektrik, elektronik ve otomasyon bağlantıları için iş kapsamı değerlendirmesi.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "description": "Elektrik, elektronik ve otomasyon bağlantıları için iş kapsamı değerlendirmesi. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Sistem ve bağlantı incelemesi\", \"Elektrik ve elektronik ihtiyaçlarının belirlenmesi\", \"Uygulama kapsamının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tamir-bakim",
    "slug": "tamir-bakim",
    "name": "Tamir & Bakım",
    "subtitle": "Cihazların bakım ve onarım ihtiyaçlarını birlikte değerlendirelim.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Cihazların bakım ve onarım ihtiyaçlarını birlikte değerlendirelim. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Arıza ve bakım ihtiyacının tespiti\", \"Uyumlu parça seçenekleri\", \"İşlem sonrası işlev kontrolü\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-cihaz-satis-aksesuar",
    "slug": "cihaz-satis-aksesuar",
    "name": "Cihaz Satış & Aksesuar",
    "subtitle": "Bilgisayar, yazıcı ve aksesuar seçiminde ihtiyaca uygun seçenekler.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Bilgisayar, yazıcı ve aksesuar seçiminde ihtiyaca uygun seçenekler. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Kullanım ihtiyacının belirlenmesi\", \"Cihaz ve aksesuar uyumluluğu\", \"Güncel stok ve fiyat bilgisi\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-satis-sonrasi-destek",
    "slug": "satis-sonrasi-destek",
    "name": "Satış Sonrası Destek",
    "subtitle": "Kurulum, kullanım ve teknik sorular için iletişim desteği.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Kurulum, kullanım ve teknik sorular için iletişim desteği. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Kurulum ve bağlantı desteği\", \"Cihaz kullanım sorularının değerlendirilmesi\", \"İşlem kapsamına göre destek seçenekleri\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kahve-makinesi-tamiri",
    "slug": "kahve-makinesi-tamiri",
    "name": "Kahve Makinesi Tamiri",
    "subtitle": "Su akışı, ısıtma ve çalışma problemlerini marka ve modele göre değerlendiriyoruz.",
    "description": "Su akışı, ısıtma ve çalışma problemlerini marka ve modele göre değerlendiriyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 0,
    "icon": "settings",
    "image": "",
    "features": "[\"Su akışı ve ısıtma kontrolü\", \"Güç ve çalışma değerlendirmesi\", \"Temizlik ve bakım ihtiyacının belirlenmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "mutfak"
  },
  {
    "id": "catalog-su-isiticisi-tamiri",
    "slug": "su-isiticisi-tamiri",
    "name": "Su Isıtıcısı Tamiri",
    "subtitle": "Elektrikli su ısıtıcılarında açılmama ve ısıtmama sorunlarını inceliyoruz.",
    "description": "Elektrikli su ısıtıcılarında açılmama ve ısıtmama sorunlarını inceliyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 1,
    "icon": "settings",
    "image": "",
    "features": "[\"Güç bağlantısı kontrolü\", \"Isıtma ve termostat değerlendirmesi\", \"Onarım uygunluğunun belirlenmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "mutfak"
  },
  {
    "id": "catalog-tost-makinesi-tamiri",
    "slug": "tost-makinesi-tamiri",
    "name": "Tost Makinesi Tamiri",
    "subtitle": "Tost makinelerinin ısıtma ve güç sorunları için teknik değerlendirme.",
    "description": "Tost makinelerinin ısıtma ve güç sorunları için teknik değerlendirme. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 2,
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve güç kontrolü\", \"Termostat ve bağlantı değerlendirmesi\", \"İşlem sonrası çalışma kontrolü\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "mutfak"
  },
  {
    "id": "catalog-blender-tamiri",
    "slug": "blender-tamiri",
    "name": "Blender Tamiri",
    "subtitle": "Blender cihazlarında motor ve çalışma problemlerinin değerlendirilmesi.",
    "description": "Blender cihazlarında motor ve çalışma problemlerinin değerlendirilmesi. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 3,
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve güç kontrolü\", \"Hazne ve bağlantı uygunluğu\", \"Parça bulunabilirliğinin değerlendirilmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "mutfak"
  },
  {
    "id": "catalog-mikser-tamiri",
    "slug": "mikser-tamiri",
    "name": "Mikser Tamiri",
    "subtitle": "Mikserlerde hız, motor ve çalışma sorunlarını inceliyoruz.",
    "description": "Mikserlerde hız, motor ve çalışma sorunlarını inceliyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 4,
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve hız kontrolü\", \"Güç ve bağlantı incelemesi\", \"Parça ve onarım uygunluğu\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "mutfak"
  },
  {
    "id": "catalog-supurge-tamiri",
    "slug": "supurge-tamiri",
    "name": "Süpürge Tamiri",
    "subtitle": "Elektrikli süpürgelerde çekiş, motor ve açılmama sorunlarına yönelik değerlendirme.",
    "description": "Elektrikli süpürgelerde çekiş, motor ve açılmama sorunlarına yönelik değerlendirme. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 5,
    "icon": "settings",
    "image": "",
    "features": "[\"Çekiş ve hava akışı kontrolü\", \"Motor ve güç incelemesi\", \"Filtre ve bakım ihtiyacının değerlendirilmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1,
    "appliance_group": "temizlik"
  },
  {
    "id": "catalog-fon-makinesi-tamiri",
    "slug": "fon-makinesi-tamiri",
    "name": "Fön / Saç Kurutma Makinesi Tamiri",
    "subtitle": "Isıtmama, hava üflememe ve çalışmama sorunlarını inceliyoruz.",
    "description": "Isıtmama, hava üflememe ve çalışmama sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "kisisel-bakim",
    "photo_group": "kisisel-bakim",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve hava akışı kontrolü\", \"Motor ve kademe anahtarı değerlendirmesi\", \"Kablo ve güç bağlantısı incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-sac-masasi-tamiri",
    "slug": "sac-masasi-tamiri",
    "name": "Saç Maşası Tamiri",
    "subtitle": "Saç maşalarında ısıtma, sıcaklık ayarı ve açılma problemlerini değerlendiriyoruz.",
    "description": "Saç maşalarında ısıtma, sıcaklık ayarı ve açılma problemlerini değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "kisisel-bakim",
    "photo_group": "kisisel-bakim",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve sıcaklık kontrolü\", \"Kablo ve bağlantı incelemesi\", \"Gövde ve kullanım güvenliği değerlendirmesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-sac-duzlestirici-tamiri",
    "slug": "sac-duzlestirici-tamiri",
    "name": "Saç Düzleştirici Tamiri",
    "subtitle": "Düzleştiricilerde ısınmama ve sıcaklık kontrolü sorunlarını inceliyoruz.",
    "description": "Düzleştiricilerde ısınmama ve sıcaklık kontrolü sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "kisisel-bakim",
    "photo_group": "kisisel-bakim",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı plaka kontrolü\", \"Sıcaklık ayarı değerlendirmesi\", \"Güç ve kablo bağlantısı incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tras-makinesi-tamiri",
    "slug": "tras-makinesi-tamiri",
    "name": "Tıraş Makinesi Tamiri",
    "subtitle": "Tıraş ve saç kesme makinelerinde şarj, motor ve çalışma sorunlarını inceliyoruz.",
    "description": "Tıraş ve saç kesme makinelerinde şarj, motor ve çalışma sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "kisisel-bakim",
    "photo_group": "kisisel-bakim",
    "icon": "settings",
    "image": "",
    "features": "[\"Şarj ve batarya değerlendirmesi\", \"Motor ve kesici bağlantısı kontrolü\", \"Modele uygun parça değerlendirmesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-epilator-tamiri",
    "slug": "epilator-tamiri",
    "name": "Epilatör Tamiri",
    "subtitle": "Epilatörlerde açılmama, şarj ve başlık çalışma sorunlarını değerlendiriyoruz.",
    "description": "Epilatörlerde açılmama, şarj ve başlık çalışma sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "kisisel-bakim",
    "photo_group": "kisisel-bakim",
    "icon": "settings",
    "image": "",
    "features": "[\"Güç ve şarj bağlantısı kontrolü\", \"Motor ve başlık değerlendirmesi\", \"Bakım ve parça uygunluğu\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-cay-makinesi-tamiri",
    "slug": "cay-makinesi-tamiri",
    "name": "Çay Makinesi Tamiri",
    "subtitle": "Çay makinelerinde ısıtma ve sıcak tutma problemlerini inceliyoruz.",
    "description": "Çay makinelerinde ısıtma ve sıcak tutma problemlerini inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve sıcak tutma kontrolü\", \"Termostat ve anahtar değerlendirmesi\", \"Güç tabanı ve kablo kontrolü\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-airfryer-tamiri",
    "slug": "airfryer-tamiri",
    "name": "Airfryer Tamiri",
    "subtitle": "Airfryer cihazlarında ısıtma, fan ve kontrol paneli sorunlarını değerlendiriyoruz.",
    "description": "Airfryer cihazlarında ısıtma, fan ve kontrol paneli sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve fan kontrolü\", \"Kontrol paneli değerlendirmesi\", \"Güç ve çalışma bağlantıları\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-fritoz-tamiri",
    "slug": "fritoz-tamiri",
    "name": "Fritöz Tamiri",
    "subtitle": "Fritözlerde ısıtmama ve sıcaklık kontrolü problemlerini inceliyoruz.",
    "description": "Fritözlerde ısıtmama ve sıcaklık kontrolü problemlerini inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve termostat kontrolü\", \"Anahtar ve güç değerlendirmesi\", \"Onarım uygunluğunun belirlenmesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-mutfak-robotu-tamiri",
    "slug": "mutfak-robotu-tamiri",
    "name": "Mutfak Robotu Tamiri",
    "subtitle": "Mutfak robotlarında motor, hız ve hazne bağlantısı sorunlarını inceliyoruz.",
    "description": "Mutfak robotlarında motor, hız ve hazne bağlantısı sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve hız kontrolü\", \"Hazne bağlantısı değerlendirmesi\", \"Güç ve mekanik aktarım incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-rondo-tamiri",
    "slug": "rondo-tamiri",
    "name": "Rondo / Doğrayıcı Tamiri",
    "subtitle": "Doğrayıcılarda motor ve çalıştırma mekanizması sorunlarını değerlendiriyoruz.",
    "description": "Doğrayıcılarda motor ve çalıştırma mekanizması sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve anahtar kontrolü\", \"Kapak ve bağlantı değerlendirmesi\", \"Parça ve onarım uygunluğu\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-ekmek-kizartma-makinesi-tamiri",
    "slug": "ekmek-kizartma-makinesi-tamiri",
    "name": "Ekmek Kızartma Makinesi Tamiri",
    "subtitle": "Ekmek kızartma makinelerinde ısıtma ve mekanizma sorunlarını inceliyoruz.",
    "description": "Ekmek kızartma makinelerinde ısıtma ve mekanizma sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı eleman kontrolü\", \"Kaldırma ve kademe mekanizması\", \"Kablo ve güç kontrolü\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-meyve-sikacagi-tamiri",
    "slug": "meyve-sikacagi-tamiri",
    "name": "Meyve / Narenciye Sıkacağı Tamiri",
    "subtitle": "Meyve ve narenciye sıkacaklarında motor ve çalışma problemlerini inceliyoruz.",
    "description": "Meyve ve narenciye sıkacaklarında motor ve çalışma problemlerini inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve aktarım kontrolü\", \"Hazne ve bağlantı değerlendirmesi\", \"Parça uygunluğu incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-ekmek-yapma-makinesi-tamiri",
    "slug": "ekmek-yapma-makinesi-tamiri",
    "name": "Ekmek Yapma Makinesi Tamiri",
    "subtitle": "Ekmek yapma makinelerinde yoğurma, ısıtma ve program sorunlarını değerlendiriyoruz.",
    "description": "Ekmek yapma makinelerinde yoğurma, ısıtma ve program sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "mutfak",
    "photo_group": "mutfak",
    "icon": "settings",
    "image": "",
    "features": "[\"Yoğurma motoru ve mekanizması\", \"Isıtıcı kontrolü\", \"Program ve güç değerlendirmesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-robot-supurge-tamiri",
    "slug": "robot-supurge-tamiri",
    "name": "Robot Süpürge Tamiri",
    "subtitle": "Robot süpürgelerde şarj, hareket ve temizlik performansı sorunlarını inceliyoruz.",
    "description": "Robot süpürgelerde şarj, hareket ve temizlik performansı sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "temizlik",
    "photo_group": "temizlik",
    "icon": "settings",
    "image": "",
    "features": "[\"Şarj istasyonu ve batarya kontrolü\", \"Tekerlek ve fırça değerlendirmesi\", \"Sensör ve hava akışı kontrolü\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-dikey-supurge-tamiri",
    "slug": "dikey-supurge-tamiri",
    "name": "Dikey / Şarjlı Süpürge Tamiri",
    "subtitle": "Dikey ve şarjlı süpürgelerde çekiş, motor ve şarj sorunlarını değerlendiriyoruz.",
    "description": "Dikey ve şarjlı süpürgelerde çekiş, motor ve şarj sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "temizlik",
    "photo_group": "temizlik",
    "icon": "settings",
    "image": "",
    "features": "[\"Batarya ve şarj kontrolü\", \"Motor ve çekiş değerlendirmesi\", \"Filtre ve fırça bağlantısı\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-buharli-temizleyici-tamiri",
    "slug": "buharli-temizleyici-tamiri",
    "name": "Buharlı Temizleyici Tamiri",
    "subtitle": "Buharlı temizleyicilerde ısıtma ve buhar çıkışı sorunlarını inceliyoruz.",
    "description": "Buharlı temizleyicilerde ısıtma ve buhar çıkışı sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "temizlik",
    "photo_group": "temizlik",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtma ve buhar kontrolü\", \"Su akışı değerlendirmesi\", \"Bağlantı ve güç incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-utu-tamiri",
    "slug": "utu-tamiri",
    "name": "Ütü Tamiri",
    "subtitle": "Ütülerde ısıtmama, buhar ve sıcaklık ayarı sorunlarını değerlendiriyoruz.",
    "description": "Ütülerde ısıtmama, buhar ve sıcaklık ayarı sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "ev-konforu",
    "photo_group": "ev-konforu",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve termostat kontrolü\", \"Buhar ve su akışı değerlendirmesi\", \"Kablo ve güç bağlantısı\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kazanli-utu-tamiri",
    "slug": "kazanli-utu-tamiri",
    "name": "Kazanlı Ütü Tamiri",
    "subtitle": "Kazanlı ütülerde buhar, ısıtma ve su besleme problemlerini inceliyoruz.",
    "description": "Kazanlı ütülerde buhar, ısıtma ve su besleme problemlerini inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "ev-konforu",
    "photo_group": "ev-konforu",
    "icon": "settings",
    "image": "",
    "features": "[\"Kazan ve ısıtma değerlendirmesi\", \"Pompa ve su akışı kontrolü\", \"Güç ve bağlantı incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-vantilator-tamiri",
    "slug": "vantilator-tamiri",
    "name": "Vantilatör Tamiri",
    "subtitle": "Vantilatörlerde motor, hız ve salınım sorunlarını değerlendiriyoruz.",
    "description": "Vantilatörlerde motor, hız ve salınım sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "ev-konforu",
    "photo_group": "ev-konforu",
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve hız kontrolü\", \"Salınım mekanizması değerlendirmesi\", \"Anahtar ve kablo incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektrikli-isitici-tamiri",
    "slug": "elektrikli-isitici-tamiri",
    "name": "Elektrikli Isıtıcı Tamiri",
    "subtitle": "Taşınabilir elektrikli ısıtıcılarda ısıtma ve çalışma sorunlarını inceliyoruz.",
    "description": "Taşınabilir elektrikli ısıtıcılarda ısıtma ve çalışma sorunlarını inceliyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "ev-konforu",
    "photo_group": "ev-konforu",
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve fan değerlendirmesi\", \"Termostat ve güç kontrolü\", \"Güvenlik bileşenlerinin incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-hava-nemlendirici-tamiri",
    "slug": "hava-nemlendirici-tamiri",
    "name": "Hava Nemlendirici Tamiri",
    "subtitle": "Hava nemlendiricilerde buhar üretimi ve güç sorunlarını değerlendiriyoruz.",
    "description": "Hava nemlendiricilerde buhar üretimi ve güç sorunlarını değerlendiriyoruz. Cihazın marka ve modelini, arıza belirtilerini ve varsa fotoğraflarını paylaşabilirsiniz. Onarım ve parça uygunluğu inceleme sonrasında belirlenir; yapılacak işlemler ve ücret onayınıza sunulur.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "appliance_group": "ev-konforu",
    "photo_group": "ev-konforu",
    "icon": "settings",
    "image": "",
    "features": "[\"Su haznesi ve akış değerlendirmesi\", \"Buhar üretimi kontrolü\", \"Güç ve kontrol paneli incelemesi\"]",
    "faq": "[{\"question\": \"Hangi marka ve modeller için destek alabilirim?\", \"answer\": \"Marka ve model bilgisiyle bize ulaşabilirsiniz. Onarım imkânı cihazın durumu ve uyumlu parça bulunabilirliğine göre değerlendirilir.\"}, {\"question\": \"İşlem ücreti ve süresi nasıl belirlenir?\", \"answer\": \"İnceleme sonrasında arıza, parça ihtiyacı, işlem kapsamı ve süre hakkında bilgi verilir. Onayınız alınmadan uygulamaya geçilmez.\"}]",
    "is_active": 1
  }
]
CATALOG_JSON
, true);
}
function bsMergeServices($existing, $allRecords = []) {
    $allowedSlugs = array_column(bsServiceCatalog(), 'slug');
    $result = is_array($existing) ? array_values(array_filter($existing, function ($item) use ($allowedSlugs) { return in_array($item['slug'] ?? '', $allowedSlugs, true); })) : [];
    $slugs = array_merge(array_column($result, 'slug'), array_column($allRecords, 'slug'));
    foreach (bsServiceCatalog() as $item) {
        if (!in_array($item['slug'], $slugs, true)) $result[] = $item;
    }
    return $result;
}
function bsServicePhotoClass($service) {
    if (isset($service['photo_group']) && in_array($service['photo_group'], ['kisisel-bakim', 'mutfak', 'temizlik', 'ev-konforu'], true)) return 'bs-expanded-appliance bs-appliance-' . $service['photo_group'];
    if (isset($service['photo_index']) && is_int($service['photo_index']) && $service['photo_index'] >= 0 && $service['photo_index'] <= 5) return 'bs-appliance-photo bs-appliance-' . $service['photo_index'];
    $category = $service['category'] ?? '';
    if (in_array($category, ['computer', 'electric', 'screen', 'appliance'], true)) return 'bs-photo-' . $category;
    $text = mb_strtolower(($service['name'] ?? '') . ' ' . ($service['slug'] ?? ''), 'UTF-8');
    if (preg_match('/kahve|blender|ev.alet|süpürge/u', $text)) return 'bs-photo-appliance';
    if (preg_match('/tv|televizyon|uydu|kamera/u', $text)) return 'bs-photo-screen';
    if (preg_match('/elektr|avize|priz|sigorta|otomasyon/u', $text)) return 'bs-photo-electric';
    return 'bs-photo-computer';
}
function bsServiceGroups($services) {
    $definitions = [
        'bilgisayar-mac' => ['name' => 'Bilgisayar & Mac', 'description' => 'Bilgisayar, Apple cihazları, donanım ve yazıcı çözümleri.', 'slugs' => ['bilgisayar-mac-servis', 'bilgisayar-tamiri', 'macbook-imac-servis', 'donanim-yukseltme', 'yazici-toner-servisi']],
        'elektrik-elektronik' => ['name' => 'Elektrik & Elektronik', 'description' => 'Tesisat, aydınlatma ve elektronik onarım hizmetleri.', 'slugs' => ['elektrik-elektronik', 'elektrik-tesisati', 'priz-sigorta-aydinlatma', 'avize-montaji', 'elektronik-onarim']],
        'tv-uydu-kamera' => ['name' => 'TV · Uydu · Kamera', 'description' => 'Televizyon, uydu ve kamera sistemi çözümleri.', 'slugs' => ['tv-uydu-kamera', 'tv-tamiri', 'uydu-sistemleri', 'kamera-sistemleri']],
        'kucuk-ev-aletleri' => ['name' => 'Küçük Ev Aletleri', 'description' => 'Kişisel bakım, mutfak, temizlik, ütü ve ev konforu cihazları.', 'slugs' => array_merge(['kucuk-ev-aletleri-tamiri'], array_column(array_filter(bsServiceCatalog(), function ($item) { return ($item['parent'] ?? '') === 'kucuk-ev-aletleri-tamiri'; }), 'slug'))],
        'hizmet-alanlari' => ['name' => 'Hizmet Verdiğimiz Alanlar', 'description' => 'Evler, ofisler, işletmeler ve sanayi için teknik destek.', 'slugs' => ['evler-icin-teknik-servis', 'ofisler-icin-teknik-servis', 'isletmeler-icin-teknik-servis', 'sanayi-icin-teknik-servis']],
        'satis-bakim-destek' => ['name' => 'Satış · Bakım · Destek', 'description' => 'Bakım, cihaz ve aksesuar seçimi, satış sonrası destek.', 'slugs' => ['tamir-bakim', 'cihaz-satis-aksesuar', 'satis-sonrasi-destek']]
    ];
    $bySlug = [];
    foreach ($services as $service) $bySlug[$service['slug']] = $service;
    $result = [];
    foreach ($definitions as $id => $definition) {
        $items = [];
        foreach ($definition['slugs'] as $slug) if (isset($bySlug[$slug])) $items[] = $bySlug[$slug];
        if ($items) $result[$id] = ['name' => $definition['name'], 'description' => $definition['description'], 'services' => $items];
    }
    return $result;
}

function bsApplianceGroups($services) {
    $definitions = ['kisisel-bakim' => 'Kişisel Bakım', 'mutfak' => 'Mutfak Aletleri', 'temizlik' => 'Temizlik Cihazları', 'ev-konforu' => 'Ütü & Ev Konforu'];
    $catalog = [];
    foreach (bsServiceCatalog() as $item) $catalog[$item['slug']] = $item;
    $result = [];
    foreach ($definitions as $key => $name) {
        $items = [];
        foreach ($services as $item) {
            $definition = $catalog[$item['slug'] ?? ''] ?? [];
            if (($definition['appliance_group'] ?? '') === $key) $items[] = array_merge($definition, $item);
        }
        if ($items) $result[$key] = ['name' => $name, 'services' => $items];
    }
    return $result;
}
