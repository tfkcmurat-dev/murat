<?php
/**
 * Güvenlik Fonksiyonları
 * CSRF, XSS koruması, brute force koruması ve input validation
 */

// Güvenlik header'larını ayarla
function setSecurityHeaders() {
    // XSS koruması
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    
    // Referrer policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Content Security Policy (temel)
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://www.googletagmanager.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net; img-src 'self' data: https:; connect-src 'self' https://www.google-analytics.com;");
    
    // HTTPS kullanılıyorsa HSTS
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// Sayfa yüklenirken güvenlik header'larını ayarla
if (!headers_sent()) {
    setSecurityHeaders();
}

/**
 * CSRF token oluştur
 */
function generateCsrfToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * CSRF token kontrolü
 */
function validateCsrfToken($token) {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }
    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * CSRF token input alanı
 */
function csrfField() {
    $token = generateCsrfToken();
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars($token) . '">';
}

/**
 * XSS koruması - HTML temizleme
 */
function clean($data) {
    if (is_array($data)) {
        return array_map('clean', $data);
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * XSS koruması - HTML'e izin verilen içerik için
 */
function cleanHtml($html) {
    // Basit HTML temizleme - production'da HTMLPurifier gibi kütüphane kullanılabilir
    $allowedTags = '<p><br><strong><em><u><a><ul><ol><li><h1><h2><h3><h4><h5><h6>';
    return strip_tags($html, $allowedTags);
}

/**
 * Input validation - Email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Input validation - Telefon
 */
function validatePhone($phone) {
    // Türkiye telefon numarası formatı kontrolü
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return preg_match('/^(\+90|0)?[0-9]{10}$/', $phone);
}

/**
 * Input validation - URL
 */
function validateUrl($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Şifre hash'leme
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Şifre doğrulama
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * SQL injection koruması için input temizleme
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    // PDO prepared statements kullanıldığı için burada sadece temel temizlik yapıyoruz
    return trim($data);
}

/**
 * Dosya yükleme güvenliği
 */
function validateUploadedFile($file) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    // Dosya boyutu kontrolü
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return false;
    }
    
    // Dosya tipi kontrolü (sadece resim için)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, ALLOWED_IMAGE_TYPES)) {
        return false;
    }
    
    return true;
}

/**
 * Güvenli dosya adı oluştur
 */
function generateSafeFileName($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $name = pathinfo($originalName, PATHINFO_FILENAME);
    $name = preg_replace('/[^a-zA-Z0-9_-]/', '', $name);
    return $name . '_' . time() . '.' . $extension;
}

/**
 * Rate limiting için basit kontrol (session tabanlı - fallback)
 */
function checkRateLimit($action, $maxAttempts = 5, $timeWindow = 300) {
    $key = 'rate_limit_' . $action;
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [
            'attempts' => 0,
            'reset_time' => time() + $timeWindow
        ];
    }
    
    // Zaman penceresi dolmuşsa sıfırla
    if (time() > $_SESSION[$key]['reset_time']) {
        $_SESSION[$key] = [
            'attempts' => 0,
            'reset_time' => time() + $timeWindow
        ];
    }
    
    $_SESSION[$key]['attempts']++;
    
    if ($_SESSION[$key]['attempts'] > $maxAttempts) {
        return false;
    }
    
    return true;
}

/**
 * IP tabanlı brute force koruması (veritabanı tabanlı)
 */
function checkLoginAttempts($ip, $maxAttempts = 5, $lockoutMinutes = 15) {
    $db = Database::getInstance();
    
    // Son X dakikadaki başarısız denemeleri say
    $since = date('Y-m-d H:i:s', strtotime("-{$lockoutMinutes} minutes"));
    
    try {
        $result = $db->fetch(
            "SELECT COUNT(*) as attempts FROM login_attempts 
             WHERE ip_address = ? AND attempted_at > ? AND success = 0",
            [$ip, $since]
        );
        
        return ($result['attempts'] ?? 0) < $maxAttempts;
    } catch (Exception $e) {
        // Tablo yoksa session tabanlı kontrole düş
        return checkRateLimit('login', $maxAttempts, $lockoutMinutes * 60);
    }
}

/**
 * Login denemesini kaydet
 */
function logLoginAttempt($ip, $username, $success = false) {
    $db = Database::getInstance();
    
    try {
        $db->insert('login_attempts', [
            'ip_address' => $ip,
            'username' => $username,
            'success' => $success ? 1 : 0
        ]);
    } catch (Exception $e) {
        // Sessizce geç - tablo yoksa
    }
}

/**
 * Güvenlik logu kaydet
 */
function logSecurityEvent($action, $userId = null, $details = null) {
    $db = Database::getInstance();
    
    try {
        $db->insert('security_logs', [
            'user_id' => $userId,
            'action' => $action,
            'ip_address' => getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'details' => $details
        ]);
    } catch (Exception $e) {
        // Sessizce geç - tablo yoksa
    }
}

/**
 * Gerçek IP adresini al
 */
function getClientIp() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    // Proxy arkasındaysa
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    
    // IP validasyonu
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        return $ip;
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Şifre güçlülük kontrolü
 */
function validatePasswordStrength($password) {
    $errors = [];
    
    // Minimum 8 karakter
    if (strlen($password) < 8) {
        $errors[] = 'Şifre en az 8 karakter olmalıdır.';
    }
    
    // En az bir büyük harf
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Şifre en az bir büyük harf içermelidir.';
    }
    
    // En az bir küçük harf
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Şifre en az bir küçük harf içermelidir.';
    }
    
    // En az bir rakam
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Şifre en az bir rakam içermelidir.';
    }
    
    // En az bir özel karakter (opsiyonel ama önerilen)
    // if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
    //     $errors[] = 'Şifre en az bir özel karakter içermelidir.';
    // }
    
    return $errors;
}

/**
 * Session güvenliğini yenile (login sonrası)
 */
function regenerateSession() {
    // Mevcut session verilerini sakla
    $sessionData = $_SESSION;
    
    // Session ID'yi yenile
    session_regenerate_id(true);
    
    // Verileri geri yükle
    $_SESSION = $sessionData;
    
    // Session fingerprint oluştur
    $_SESSION['fingerprint'] = generateSessionFingerprint();
}

/**
 * Session fingerprint oluştur
 */
function generateSessionFingerprint() {
    return hash('sha256', 
        ($_SERVER['HTTP_USER_AGENT'] ?? '') . 
        ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '')
    );
}

/**
 * Session fingerprint doğrula
 */
function validateSessionFingerprint() {
    if (!isset($_SESSION['fingerprint'])) {
        return true; // İlk defa, henüz ayarlanmamış
    }
    
    return hash_equals($_SESSION['fingerprint'], generateSessionFingerprint());
}

/**
 * Güvenli rastgele token oluştur
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}
