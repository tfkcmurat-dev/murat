<?php
/**
 * Public Quote View Controller
 * Müşterilerin tekliflerini canlı siteden görüntülemesi için
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Quote.php';

class QuoteViewController {
    private $quoteModel;
    
    public function __construct() {
        $this->quoteModel = new Quote();
    }
    
    /**
     * Teklif görüntüleme
     */
    public function view($quoteNumber) {
        $quote = $this->quoteModel->findByQuoteNumber($quoteNumber);
        
        if (!$quote) {
            // Teklif bulunamadı - 404 sayfası
            http_response_code(404);
            $pageTitle = 'Teklif Bulunamadı';
            $noIndex = true; // robots: noindex
            require_once APP_PATH . '/views/layouts/header.php';
            view('quote/not-found', []);
            require_once APP_PATH . '/views/layouts/footer.php';
            return;
        }
        
        // Teklif durumu kontrolü - sadece gönderilmiş/onaylanmış/reddedilmiş teklifler gösterilsin
        // draft teklifler gizli kalır
        if (!in_array($quote['status'], ['sent', 'approved', 'rejected'])) {
            http_response_code(404);
            $pageTitle = 'Teklif Bulunamadı';
            $noIndex = true;
            require_once APP_PATH . '/views/layouts/header.php';
            view('quote/not-found', []);
            require_once APP_PATH . '/views/layouts/footer.php';
            return;
        }
        
        // Flash mesaj varsa al
        $flashMessage = null;
        $flashType = null;
        if (isset($_SESSION['quote_flash'])) {
            $flashMessage = $_SESSION['quote_flash']['message'];
            $flashType = $_SESSION['quote_flash']['type'];
            unset($_SESSION['quote_flash']);
        }
        
        $pageTitle = 'Teklif ' . $quote['quote_number'];
        $noIndex = true; // robots: noindex - teklifler index almasın
        
        require_once APP_PATH . '/views/layouts/header.php';
        view('quote/view', [
            'quote' => $quote,
            'flashMessage' => $flashMessage,
            'flashType' => $flashType
        ]);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Müşteri yanıtını işle
     */
    public function respond($quoteNumber) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . url('teklif/' . $quoteNumber));
            exit;
        }
        
        $response = $_POST['response'] ?? '';
        $message = trim($_POST['message'] ?? '');
        
        $result = $this->quoteModel->saveCustomerResponse($quoteNumber, $response, $message);
        
        // Flash mesaj ayarla
        $_SESSION['quote_flash'] = [
            'message' => $result['message'],
            'type' => $result['success'] ? 'success' : 'error'
        ];
        
        header('Location: ' . url('teklif/' . $quoteNumber));
        exit;
    }
}
