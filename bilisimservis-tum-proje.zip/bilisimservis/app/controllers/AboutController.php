<?php
/**
 * About Controller
 * Hakkımızda sayfası
 */

require_once APP_PATH . '/config/config.php';

class AboutController {
    
    public function index() {
        $pageTitle = 'Hakkımızda';
        require_once APP_PATH . '/views/layouts/header.php';
        view('about/index', []);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
}
