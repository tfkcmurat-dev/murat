<?php
/**
 * Contact Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';
require_once APP_PATH . '/models/ContactSubmission.php';
require_once APP_PATH . '/services/MailService.php';

class ContactController {
    
    private $themeModel;
    private $submissionModel;
    private $mailService;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
        $this->submissionModel = new ContactSubmission();
        $this->mailService = new MailService();
    }
    
    public function index() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token kontrolü
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(url('iletisim'));
            }
            
            $name = sanitizeInput($_POST['name'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            $subject = sanitizeInput($_POST['subject'] ?? '');
            $message = sanitizeInput($_POST['message'] ?? '');
            
            // Validasyon
            if (empty($name) || empty($email) || empty($message)) {
                setFlash('error', 'Tüm alanlar gereklidir.');
                redirect(url('iletisim'));
            }
            
            if (!validateEmail($email)) {
                setFlash('error', 'Geçerli bir e-posta adresi giriniz.');
                redirect(url('iletisim'));
            }
            
            // Form kaydını veritabanına ekle
            $submissionData = [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'subject' => $subject,
                'message' => $message,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ];
            
            $submissionId = $this->submissionModel->create($submissionData);
            
            // Admin'e bildirim maili gönder
            $adminEmail = getThemeSetting('contact_email', '');
            if ($adminEmail && $this->mailService->isEnabled()) {
                $this->mailService->sendWithTemplate('contact_notification', $adminEmail, [
                    'name' => $name,
                    'email' => $email,
                    'subject' => $subject ?: 'Belirtilmedi',
                    'message' => nl2br($message),
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Bilinmiyor'
                ]);
            }
            
            // Müşteriye onay maili gönder
            if ($this->mailService->isEnabled()) {
                $this->mailService->sendWithTemplate('contact_confirmation', $email, [
                    'name' => $name,
                    'email' => $email,
                    'subject' => $subject ?: 'Belirtilmedi',
                    'message' => nl2br($message)
                ], $name);
            }
            
            if ($submissionId) {
                setFlash('success', 'Mesajınız başarıyla gönderildi. En kısa sürede size dönüş yapacağız.');
            } else {
                setFlash('error', 'Mesaj gönderilirken bir hata oluştu. Lütfen tekrar deneyin.');
            }
            
            redirect(url('iletisim'));
        }
        
        // Sosyal medya linkleri
        $socialLinks = [
            'facebook' => $this->themeModel->get('social_facebook_url') ?? '',
            'instagram' => $this->themeModel->get('social_instagram_url') ?? '',
            'twitter' => $this->themeModel->get('social_twitter_url') ?? '',
            'whatsapp' => $this->themeModel->get('social_whatsapp_url') ?? '',
            'youtube' => $this->themeModel->get('social_youtube_url') ?? '',
            'linkedin' => $this->themeModel->get('social_linkedin_url') ?? '',
        ];
        
        $pageTitle = 'İletişim';
        require_once APP_PATH . '/views/layouts/header.php';
        view('contact/index', [
            'socialLinks' => $socialLinks
        ]);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
}
