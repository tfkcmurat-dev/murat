<?php
/**
 * Mail Service - PHPMailer Wrapper
 * SMTP yapılandırması ve mail gönderim işlemleri
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once APP_PATH . '/models/Database.php';

class MailService {
    private $db;
    private $mailer;
    private $config = [];
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->loadConfig();
    }
    
    /**
     * SMTP yapılandırmasını theme_settings'den yükle
     */
    private function loadConfig() {
        $settings = [
            'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password',
            'smtp_encryption', 'smtp_from_email', 'smtp_from_name', 'mail_enabled'
        ];
        
        foreach ($settings as $key) {
            $result = $this->db->fetch(
                "SELECT setting_value FROM theme_settings WHERE setting_key = ?",
                [$key]
            );
            $this->config[$key] = $result ? $result['setting_value'] : '';
        }
    }
    
    /**
     * SMTP yapılandırmasını al
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * Mail gönderimi aktif mi kontrol et
     */
    public function isEnabled() {
        return $this->config['mail_enabled'] == '1';
    }
    
    /**
     * PHPMailer instance oluştur ve yapılandır
     */
    private function initMailer() {
        $this->mailer = new PHPMailer(true);
        
        // SMTP ayarları
        $this->mailer->isSMTP();
        $this->mailer->Host = $this->config['smtp_host'];
        $this->mailer->Port = (int) $this->config['smtp_port'];
        $this->mailer->SMTPAuth = true;
        $this->mailer->Username = $this->config['smtp_username'];
        $this->mailer->Password = $this->config['smtp_password'];
        
        // Şifreleme
        if ($this->config['smtp_encryption'] === 'tls') {
            $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($this->config['smtp_encryption'] === 'ssl') {
            $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        }
        
        // Gönderen bilgileri
        $this->mailer->setFrom(
            $this->config['smtp_from_email'],
            $this->config['smtp_from_name']
        );
        
        // Karakter seti
        $this->mailer->CharSet = 'UTF-8';
        $this->mailer->isHTML(true);
    }
    
    /**
     * Basit mail gönder
     * 
     * @param string $to Alıcı e-posta
     * @param string $subject Konu
     * @param string $body HTML içerik
     * @param string|null $toName Alıcı adı
     * @param string|null $templateSlug Log için şablon slug'ı
     * @return array ['success' => bool, 'message' => string]
     */
    public function send($to, $subject, $body, $toName = null, $templateSlug = null) {
        // Mail gönderimi kapalıysa
        if (!$this->isEnabled()) {
            return [
                'success' => false,
                'message' => 'Mail gönderimi devre dışı. SMTP ayarlarından aktif edin.'
            ];
        }
        
        $logData = [
            'template_slug' => $templateSlug,
            'recipient_email' => $to,
            'recipient_name' => $toName,
            'subject' => $subject,
            'body' => $body,
            'status' => 'pending'
        ];
        
        try {
            $this->initMailer();
            
            $this->mailer->addAddress($to, $toName ?? '');
            $this->mailer->Subject = $subject;
            $this->mailer->Body = $body;
            $this->mailer->AltBody = strip_tags($body);
            
            $this->mailer->send();
            
            // Başarılı log
            $logData['status'] = 'sent';
            $logData['sent_at'] = date('Y-m-d H:i:s');
            $this->logEmail($logData);
            
            return [
                'success' => true,
                'message' => 'E-posta başarıyla gönderildi.'
            ];
            
        } catch (Exception $e) {
            // Hata log
            $logData['status'] = 'failed';
            $logData['error_message'] = $this->mailer->ErrorInfo;
            $this->logEmail($logData);
            
            return [
                'success' => false,
                'message' => 'E-posta gönderilemedi: ' . $this->mailer->ErrorInfo
            ];
        }
    }
    
    /**
     * Şablon ile mail gönder
     * 
     * @param string $templateSlug Şablon slug'ı
     * @param string $to Alıcı e-posta
     * @param array $variables Şablonda kullanılacak değişkenler
     * @param string|null $toName Alıcı adı
     * @return array ['success' => bool, 'message' => string]
     */
    public function sendWithTemplate($templateSlug, $to, array $variables = [], $toName = null) {
        // Şablonu bul
        $template = $this->db->fetch(
            "SELECT * FROM email_templates WHERE slug = ? AND is_active = 1",
            [$templateSlug]
        );
        
        if (!$template) {
            return [
                'success' => false,
                'message' => 'E-posta şablonu bulunamadı: ' . $templateSlug
            ];
        }
        
        // Varsayılan değişkenler
        $defaults = [
            'site_name' => getThemeSetting('site_name', 'Bilişim Servis'),
            'site_url' => url(''),
            'contact_phone' => getThemeSetting('contact_phone', ''),
            'contact_email' => getThemeSetting('contact_email', ''),
            'date' => date('d.m.Y H:i'),
            'year' => date('Y')
        ];
        
        $variables = array_merge($defaults, $variables);
        
        // Şablon değişkenlerini değiştir
        $subject = $this->parseTemplate($template['subject'], $variables);
        $body = $this->parseTemplate($template['body'], $variables);
        
        return $this->send($to, $subject, $body, $toName, $templateSlug);
    }
    
    /**
     * Şablondaki değişkenleri değiştir
     * 
     * @param string $template Şablon metni
     * @param array $variables Değişkenler
     * @return string İşlenmiş metin
     */
    public function parseTemplate($template, array $variables) {
        foreach ($variables as $key => $value) {
            $template = str_replace('{' . $key . '}', $value, $template);
        }
        return $template;
    }
    
    /**
     * Mail log kaydı oluştur
     * 
     * @param array $data Log verileri
     * @return int|false Insert ID veya false
     */
    public function logEmail(array $data) {
        return $this->db->insert('email_logs', [
            'template_slug' => $data['template_slug'] ?? null,
            'recipient_email' => $data['recipient_email'],
            'recipient_name' => $data['recipient_name'] ?? null,
            'subject' => $data['subject'],
            'body' => $data['body'] ?? null,
            'status' => $data['status'] ?? 'pending',
            'error_message' => $data['error_message'] ?? null,
            'sent_at' => $data['sent_at'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * SMTP bağlantı testi
     * 
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection() {
        try {
            $this->initMailer();
            
            // Debug modunu açıp bağlantı testi yap
            $this->mailer->SMTPDebug = SMTP::DEBUG_CONNECTION;
            
            // Çıktıyı yakala
            ob_start();
            $result = $this->mailer->smtpConnect();
            $debug = ob_get_clean();
            
            if ($result) {
                $this->mailer->smtpClose();
                return [
                    'success' => true,
                    'message' => 'SMTP bağlantısı başarılı!'
                ];
            }
            
            return [
                'success' => false,
                'message' => 'SMTP bağlantısı kurulamadı.'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Bağlantı hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Teklif e-postası gönder
     * 
     * @param array $quote Teklif verisi
     * @return array ['success' => bool, 'message' => string]
     */
    public function sendQuoteEmail($quote) {
        // Müşteri e-postası kontrolü
        $customerEmail = $quote['email'] ?? null;
        if (empty($customerEmail)) {
            return [
                'success' => false,
                'message' => 'Müşterinin e-posta adresi bulunamadı.'
            ];
        }
        
        // Teklif kalemlerini HTML formatında hazırla
        $quoteItemsHtml = $this->formatQuoteItems($quote['items'] ?? []);
        
        // Müşteri notu bölümü
        $customerNoteSection = '';
        if (!empty($quote['customer_note'])) {
            $customerNoteSection = '
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-top: 30px;">
                <tr>
                    <td style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 20px;">
                        <h4 style="margin: 0 0 12px; color: #00D4FF; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">📌 Notlar ve Koşullar</h4>
                        <p style="margin: 0; color: rgba(255,255,255,0.7); font-size: 14px; line-height: 1.8; white-space: pre-wrap;">' . nl2br(htmlspecialchars($quote['customer_note'])) . '</p>
                    </td>
                </tr>
            </table>';
        }
        
        // Değişkenler
        $variables = [
            'customer_name' => $quote['company_name'] ?? 'Değerli Müşterimiz',
            'quote_number' => $quote['quote_number'] ?? '',
            'quote_subject' => $quote['subject'] ?? 'Fiyat Teklifi',
            'quote_items' => $quoteItemsHtml,
            'grand_total' => formatMoney($quote['grand_total'] ?? 0),
            'valid_until' => !empty($quote['valid_until']) 
                ? date('d.m.Y', strtotime($quote['valid_until'])) 
                : date('d.m.Y', strtotime('+30 days')),
            'quote_link' => url('teklif/' . $quote['quote_number']),
            'customer_note_section' => $customerNoteSection,
            'contact_phone_raw' => preg_replace('/[^0-9]/', '', getThemeSetting('contact_phone', ''))
        ];
        
        return $this->sendWithTemplate(
            'quote_sent',
            $customerEmail,
            $variables,
            $quote['company_name'] ?? null
        );
    }
    
    /**
     * Teklif kalemlerini HTML formatına çevir
     * 
     * @param array $items Teklif kalemleri
     * @return string HTML formatında kalemler
     */
    private function formatQuoteItems($items) {
        if (empty($items)) {
            return '<p style="color: rgba(255,255,255,0.5);">Teklif kalemi bulunamadı.</p>';
        }
        
        $html = '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;">';
        
        // Header
        $html .= '
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
            <td style="padding: 12px 0; color: rgba(255,255,255,0.5); font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Hizmet/Ürün</td>
            <td style="padding: 12px 0; color: rgba(255,255,255,0.5); font-size: 12px; text-align: center;">Miktar</td>
            <td style="padding: 12px 0; color: rgba(255,255,255,0.5); font-size: 12px; text-align: right;">Fiyat</td>
            <td style="padding: 12px 0; color: rgba(255,255,255,0.5); font-size: 12px; text-align: right;">Toplam</td>
        </tr>';
        
        // Items
        foreach ($items as $item) {
            $html .= '
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="padding: 15px 0; padding-right: 10px;">
                    <span style="color: #ffffff; font-weight: 600;">' . htmlspecialchars($item['item_name']) . '</span>';
            
            if (!empty($item['description'])) {
                $html .= '<br><span style="color: rgba(255,255,255,0.5); font-size: 13px;">' . htmlspecialchars($item['description']) . '</span>';
            }
            
            $html .= '
                </td>
                <td style="padding: 15px 0; text-align: center; color: rgba(255,255,255,0.7);">' . number_format($item['quantity'], 0, ',', '.') . '</td>
                <td style="padding: 15px 0; text-align: right; color: rgba(255,255,255,0.7);">' . formatMoney($item['unit_price']) . '</td>
                <td style="padding: 15px 0; text-align: right; color: #00D4FF; font-weight: 600;">' . formatMoney($item['total']) . '</td>
            </tr>';
        }
        
        $html .= '</table>';
        
        return $html;
    }
    
    /**
     * Test maili gönder
     * 
     * @param string $to Test alıcısı
     * @return array ['success' => bool, 'message' => string]
     */
    public function sendTestEmail($to) {
        $subject = 'Test E-postası - ' . getThemeSetting('site_name', 'Bilişim Servis');
        $body = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 500px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #0066FF, #00D4FF); color: white; padding: 20px; text-align: center; border-radius: 8px; }
                .content { padding: 20px; background: #f9f9f9; margin-top: 10px; border-radius: 8px; }
                .success { color: #10B981; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Test E-postası</h2>
                </div>
                <div class="content">
                    <p class="success">✓ SMTP yapılandırması başarılı!</p>
                    <p>Bu e-posta, mail ayarlarınızın doğru çalıştığını doğrulamak için gönderilmiştir.</p>
                    <p><strong>Gönderim Zamanı:</strong> ' . date('d.m.Y H:i:s') . '</p>
                    <p><strong>Site:</strong> ' . getThemeSetting('site_name', 'Bilişim Servis') . '</p>
                </div>
            </div>
        </body>
        </html>';
        
        // Mail gönderimi kapalı olsa bile test için gönder
        $originalEnabled = $this->config['mail_enabled'];
        $this->config['mail_enabled'] = '1';
        
        $result = $this->send($to, $subject, $body, null, 'test_email');
        
        $this->config['mail_enabled'] = $originalEnabled;
        
        return $result;
    }
}
