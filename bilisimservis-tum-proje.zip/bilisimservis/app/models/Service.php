<?php
/**
 * Service Model
 */

class Service {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm hizmetleri getir
     */
    public function getAll($activeOnly = false) {
        $sql = "SELECT * FROM services";
        if ($activeOnly) {
            $sql .= " WHERE is_active = 1";
        }
        $sql .= " ORDER BY name ASC";
        
        return $this->db->fetchAll($sql);
    }
    
    /**
     * Hizmet getir
     */
    public function findById($id) {
        return $this->db->fetch("SELECT * FROM services WHERE id = ?", [$id]);
    }
    
    /**
     * Hizmet oluştur
     */
    public function create($data) {
        return $this->db->insert('services', $data);
    }
    
    /**
     * Hizmet güncelle
     */
    public function update($id, $data) {
        return $this->db->update('services', $data, 'id = ?', [$id]);
    }
    
    /**
     * Hizmet sil (soft delete - aktif/pasif yap)
     */
    public function delete($id) {
        return $this->db->update('services', ['is_active' => 0], 'id = ?', [$id]);
    }
    
    /**
     * Hizmet aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        $service = $this->findById($id);
        if ($service) {
            $newStatus = $service['is_active'] ? 0 : 1;
            return $this->db->update('services', ['is_active' => $newStatus], 'id = ?', [$id]);
        }
        return false;
    }
    
    /**
     * Hizmet sayısı
     */
    public function count($activeOnly = false) {
        $sql = "SELECT COUNT(*) as count FROM services";
        if ($activeOnly) {
            $sql .= " WHERE is_active = 1";
        }
        $result = $this->db->fetch($sql);
        return $result['count'];
    }
}
