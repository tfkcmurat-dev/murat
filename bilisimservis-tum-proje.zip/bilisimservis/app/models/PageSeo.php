<?php
/**
 * Page SEO Model
 * Sayfa bazlı SEO ayarlarını yönetir
 */

require_once APP_PATH . '/models/Database.php';

class PageSeo {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm sayfa SEO kayıtlarını getir
     */
    public function getAll() {
        return $this->db->fetchAll(
            "SELECT * FROM page_seo ORDER BY page_slug ASC"
        );
    }
    
    /**
     * Aktif SEO kayıtlarını getir
     */
    public function getActive() {
        return $this->db->fetchAll(
            "SELECT * FROM page_seo WHERE is_active = 1 ORDER BY page_slug ASC"
        );
    }
    
    /**
     * ID ile SEO kaydı bul
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT * FROM page_seo WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Slug ile SEO kaydı bul
     */
    public function findBySlug($slug) {
        return $this->db->fetch(
            "SELECT * FROM page_seo WHERE page_slug = ? AND is_active = 1",
            [$slug]
        );
    }
    
    /**
     * Yeni SEO kaydı oluştur
     */
    public function create(array $data) {
        return $this->db->insert('page_seo', [
            'page_slug' => $data['page_slug'],
            'meta_title' => $data['meta_title'] ?? null,
            'meta_description' => $data['meta_description'] ?? null,
            'meta_keywords' => $data['meta_keywords'] ?? null,
            'og_title' => $data['og_title'] ?? null,
            'og_description' => $data['og_description'] ?? null,
            'og_image' => $data['og_image'] ?? null,
            'canonical_url' => $data['canonical_url'] ?? null,
            'robots' => $data['robots'] ?? 'index, follow',
            'schema_type' => $data['schema_type'] ?? null,
            'custom_schema' => $data['custom_schema'] ?? null,
            'is_active' => $data['is_active'] ?? 1
        ]);
    }
    
    /**
     * SEO kaydını güncelle
     */
    public function update($id, array $data) {
        $updateData = [];
        
        $fields = [
            'meta_title', 'meta_description', 'meta_keywords',
            'og_title', 'og_description', 'og_image',
            'canonical_url', 'robots', 'schema_type', 'custom_schema', 'is_active'
        ];
        
        foreach ($fields as $field) {
            if (array_key_exists($field, $data)) {
                $updateData[$field] = $data[$field];
            }
        }
        
        if (empty($updateData)) {
            return false;
        }
        
        return $this->db->update('page_seo', $updateData, 'id = ?', [$id]);
    }
    
    /**
     * Slug ile SEO kaydını güncelle (upsert)
     */
    public function updateBySlug($slug, array $data) {
        $existing = $this->db->fetch(
            "SELECT id FROM page_seo WHERE page_slug = ?",
            [$slug]
        );
        
        if ($existing) {
            return $this->update($existing['id'], $data);
        } else {
            $data['page_slug'] = $slug;
            return $this->create($data);
        }
    }
    
    /**
     * SEO kaydını sil
     */
    public function delete($id) {
        return $this->db->delete('page_seo', 'id = ?', [$id]);
    }
    
    /**
     * Slug kontrolü
     */
    public function slugExists($slug, $excludeId = null) {
        $sql = "SELECT id FROM page_seo WHERE page_slug = ?";
        $params = [$slug];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        return $this->db->fetch($sql, $params) !== false;
    }
    
    /**
     * Sayfa için SEO meta taglarını hazırla
     */
    public function getMetaTags($slug, $defaults = []) {
        $seo = $this->findBySlug($slug);
        
        $siteName = getThemeSetting('site_name', 'Bilişim Servis');
        $siteUrl = url('');
        
        // Varsayılanlar
        $meta = [
            'title' => $defaults['title'] ?? $siteName,
            'description' => $defaults['description'] ?? getThemeSetting('site_description', ''),
            'keywords' => $defaults['keywords'] ?? '',
            'og_title' => $defaults['title'] ?? $siteName,
            'og_description' => $defaults['description'] ?? getThemeSetting('site_description', ''),
            'og_image' => $defaults['og_image'] ?? getThemeSetting('og_image', ''),
            'og_url' => $defaults['url'] ?? $siteUrl,
            'canonical' => $defaults['canonical'] ?? null,
            'robots' => 'index, follow',
            'schema' => null
        ];
        
        // SEO kaydı varsa üzerine yaz
        if ($seo) {
            if (!empty($seo['meta_title'])) {
                $meta['title'] = $seo['meta_title'];
            }
            if (!empty($seo['meta_description'])) {
                $meta['description'] = $seo['meta_description'];
            }
            if (!empty($seo['meta_keywords'])) {
                $meta['keywords'] = $seo['meta_keywords'];
            }
            if (!empty($seo['og_title'])) {
                $meta['og_title'] = $seo['og_title'];
            }
            if (!empty($seo['og_description'])) {
                $meta['og_description'] = $seo['og_description'];
            }
            if (!empty($seo['og_image'])) {
                $meta['og_image'] = $seo['og_image'];
            }
            if (!empty($seo['canonical_url'])) {
                $meta['canonical'] = $seo['canonical_url'];
            }
            if (!empty($seo['robots'])) {
                $meta['robots'] = $seo['robots'];
            }
            if (!empty($seo['custom_schema'])) {
                $meta['schema'] = $seo['custom_schema'];
            }
        }
        
        return $meta;
    }
    
    /**
     * Meta tagları HTML olarak render et
     */
    public function renderMetaTags($slug, $defaults = []) {
        $meta = $this->getMetaTags($slug, $defaults);
        $siteName = getThemeSetting('site_name', 'Bilişim Servis');
        
        $html = '';
        
        // Title
        $html .= '<title>' . htmlspecialchars($meta['title']) . '</title>' . "\n";
        
        // Meta Description
        if (!empty($meta['description'])) {
            $html .= '<meta name="description" content="' . htmlspecialchars($meta['description']) . '">' . "\n";
        }
        
        // Meta Keywords
        if (!empty($meta['keywords'])) {
            $html .= '<meta name="keywords" content="' . htmlspecialchars($meta['keywords']) . '">' . "\n";
        }
        
        // Robots
        $html .= '<meta name="robots" content="' . htmlspecialchars($meta['robots']) . '">' . "\n";
        
        // Canonical
        if (!empty($meta['canonical'])) {
            $html .= '<link rel="canonical" href="' . htmlspecialchars($meta['canonical']) . '">' . "\n";
        }
        
        // Open Graph
        $html .= '<meta property="og:type" content="website">' . "\n";
        $html .= '<meta property="og:site_name" content="' . htmlspecialchars($siteName) . '">' . "\n";
        $html .= '<meta property="og:title" content="' . htmlspecialchars($meta['og_title']) . '">' . "\n";
        
        if (!empty($meta['og_description'])) {
            $html .= '<meta property="og:description" content="' . htmlspecialchars($meta['og_description']) . '">' . "\n";
        }
        
        if (!empty($meta['og_url'])) {
            $html .= '<meta property="og:url" content="' . htmlspecialchars($meta['og_url']) . '">' . "\n";
        }
        
        if (!empty($meta['og_image'])) {
            $html .= '<meta property="og:image" content="' . htmlspecialchars($meta['og_image']) . '">' . "\n";
        }
        
        // Twitter Card
        $html .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
        $html .= '<meta name="twitter:title" content="' . htmlspecialchars($meta['og_title']) . '">' . "\n";
        
        if (!empty($meta['og_description'])) {
            $html .= '<meta name="twitter:description" content="' . htmlspecialchars($meta['og_description']) . '">' . "\n";
        }
        
        if (!empty($meta['og_image'])) {
            $html .= '<meta name="twitter:image" content="' . htmlspecialchars($meta['og_image']) . '">' . "\n";
        }
        
        // Custom Schema
        if (!empty($meta['schema'])) {
            $html .= '<script type="application/ld+json">' . "\n";
            $html .= $meta['schema'] . "\n";
            $html .= '</script>' . "\n";
        }
        
        return $html;
    }
}
