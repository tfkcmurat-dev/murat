<?php
/**
 * Veritabanı Bağlantı Sınıfı
 * PDO kullanarak güvenli veritabanı işlemleri
 */

class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Production'da log'a yazılmalı
            error_log("Veritabanı bağlantı hatası: " . $e->getMessage());
            throw new Exception("Veritabanı bağlantısı kurulamadı. Lütfen veritabanı ayarlarını kontrol edin.");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Query çalıştırma
     */
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Veritabanı hatası: " . $e->getMessage() . " | SQL: " . $sql);
            // Geliştirme ortamında detaylı hata göster
            if (defined('DEBUG') && DEBUG) {
                throw new Exception("Veritabanı hatası: " . $e->getMessage());
            }
            throw new Exception("Veritabanı işlemi başarısız: " . $e->getMessage());
        }
    }
    
    /**
     * Tek satır getirme
     */
    public function fetch($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * Tüm satırları getirme
     */
    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Insert işlemi
     */
    public function insert($table, $data) {
        $fields = array_keys($data);
        $values = array_values($data);
        $placeholders = implode(', ', array_fill(0, count($fields), '?'));
        $fieldsList = '`' . implode('`, `', $fields) . '`';
        
        $sql = "INSERT INTO `{$table}` ({$fieldsList}) VALUES ({$placeholders})";
        $this->query($sql, $values);
        
        return $this->connection->lastInsertId();
    }
    
    /**
     * Update işlemi
     */
    public function update($table, $data, $where, $whereParams = []) {
        $setParts = [];
        $params = [];
        $index = 0;
        
        // SET kısmı için positional parameters kullan
        foreach ($data as $field => $value) {
            $setParts[] = "`{$field}` = ?";
            $params[] = $value;
        }
        $setClause = implode(', ', $setParts);
        
        // WHERE parametrelerini ekle
        $params = array_merge($params, $whereParams);
        
        $sql = "UPDATE `{$table}` SET {$setClause} WHERE {$where}";
        
        return $this->query($sql, $params);
    }
    
    /**
     * Delete işlemi
     */
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM `{$table}` WHERE {$where}";
        return $this->query($sql, $params);
    }
    
    /**
     * Son eklenen ID'yi getir
     */
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
    
    /**
     * Transaction başlat
     */
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    /**
     * Transaction commit
     */
    public function commit() {
        return $this->connection->commit();
    }
    
    /**
     * Transaction rollback
     */
    public function rollBack() {
        return $this->connection->rollBack();
    }
}
