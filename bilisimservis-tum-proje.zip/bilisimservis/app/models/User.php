<?php
/**
 * User Model
 */

class User {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Kullanıcı girişi
     */
    public function login($username, $password) {
        $ip = getClientIp();
        
        // Brute force kontrolü
        if (!checkLoginAttempts($ip)) {
            return ['error' => 'too_many_attempts'];
        }
        
        $user = $this->db->fetch(
            "SELECT * FROM users WHERE username = ? OR email = ?",
            [$username, $username]
        );
        
        // Kullanıcı kilitli mi kontrol et
        if ($user && !empty($user['locked_until'])) {
            if (strtotime($user['locked_until']) > time()) {
                logLoginAttempt($ip, $username, false);
                return ['error' => 'account_locked'];
            }
        }
        
        if ($user && verifyPassword($password, $user['password'])) {
            // Başarılı giriş
            logLoginAttempt($ip, $username, true);
            logSecurityEvent('login', $user['id'], 'Successful login');
            
            // Session güvenliğini yenile
            regenerateSession();
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['login_time'] = time();
            
            // Son giriş bilgilerini güncelle
            try {
                $this->db->update('users', [
                    'last_login' => date('Y-m-d H:i:s'),
                    'last_login_ip' => $ip,
                    'failed_login_count' => 0,
                    'locked_until' => null
                ], 'id = ?', [$user['id']]);
            } catch (Exception $e) {
                // Sessizce geç - sütunlar yoksa
            }
            
            return true;
        }
        
        // Başarısız giriş
        logLoginAttempt($ip, $username, false);
        
        // Başarısız deneme sayısını artır
        if ($user) {
            try {
                $failedCount = ($user['failed_login_count'] ?? 0) + 1;
                $lockUntil = null;
                
                // 5 başarısız denemeden sonra hesabı kilitle
                if ($failedCount >= 5) {
                    $lockUntil = date('Y-m-d H:i:s', strtotime('+15 minutes'));
                    logSecurityEvent('account_locked', $user['id'], "Account locked after {$failedCount} failed attempts");
                }
                
                $this->db->update('users', [
                    'failed_login_count' => $failedCount,
                    'locked_until' => $lockUntil
                ], 'id = ?', [$user['id']]);
            } catch (Exception $e) {
                // Sessizce geç
            }
        }
        
        return false;
    }
    
    /**
     * Kullanıcı çıkışı
     */
    public function logout() {
        $userId = $_SESSION['user_id'] ?? null;
        
        if ($userId) {
            logSecurityEvent('logout', $userId, 'User logged out');
        }
        
        // Session'ı tamamen temizle
        $_SESSION = [];
        
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        session_destroy();
        session_start();
        regenerateSession();
    }
    
    /**
     * Şifre değiştir
     */
    public function changePassword($userId, $currentPassword, $newPassword) {
        $user = $this->findById($userId);
        
        if (!$user) {
            return ['success' => false, 'error' => 'Kullanıcı bulunamadı.'];
        }
        
        // Mevcut şifre kontrolü
        if (!verifyPassword($currentPassword, $user['password'])) {
            return ['success' => false, 'error' => 'Mevcut şifre hatalı.'];
        }
        
        // Yeni şifre güçlülük kontrolü
        $passwordErrors = validatePasswordStrength($newPassword);
        if (!empty($passwordErrors)) {
            return ['success' => false, 'errors' => $passwordErrors];
        }
        
        // Yeni şifre eski ile aynı olmamalı
        if (verifyPassword($newPassword, $user['password'])) {
            return ['success' => false, 'error' => 'Yeni şifre eski şifre ile aynı olamaz.'];
        }
        
        // Şifreyi güncelle
        try {
            $this->db->update('users', [
                'password' => hashPassword($newPassword),
                'password_changed_at' => date('Y-m-d H:i:s'),
                'failed_login_count' => 0,
                'locked_until' => null
            ], 'id = ?', [$userId]);
            
            logSecurityEvent('password_change', $userId, 'Password changed successfully');
            
            return ['success' => true];
        } catch (Exception $e) {
            return ['success' => false, 'error' => 'Şifre değiştirilirken bir hata oluştu.'];
        }
    }
    
    /**
     * Kullanıcı bilgilerini getir
     */
    public function findById($id) {
        return $this->db->fetch("SELECT * FROM users WHERE id = ?", [$id]);
    }
    
    /**
     * Tüm kullanıcıları getir
     */
    public function getAll() {
        return $this->db->fetchAll("SELECT id, username, email, full_name, created_at FROM users ORDER BY id DESC");
    }
    
    /**
     * Kullanıcı oluştur
     */
    public function create($data) {
        $data['password'] = hashPassword($data['password']);
        return $this->db->insert('users', $data);
    }
    
    /**
     * Kullanıcı güncelle
     */
    public function update($id, $data) {
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = hashPassword($data['password']);
        } else {
            unset($data['password']);
        }
        return $this->db->update('users', $data, 'id = ?', [$id]);
    }
    
    /**
     * Kullanıcı sil
     */
    public function delete($id) {
        return $this->db->delete('users', 'id = ?', [$id]);
    }
}
