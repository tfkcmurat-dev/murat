<?php
/**
 * Email Log Model
 * E-posta gönderim loglarını yönetir
 */

require_once APP_PATH . '/models/Database.php';

class EmailLog {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm logları getir (filtrelenebilir)
     */
    public function getAll($filters = []) {
        $where = [];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['template_slug'])) {
            $where[] = "template_slug = ?";
            $params[] = $filters['template_slug'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(recipient_email LIKE ? OR subject LIKE ?)";
            $params[] = '%' . $filters['search'] . '%';
            $params[] = '%' . $filters['search'] . '%';
        }
        
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $limit = '';
        if (!empty($filters['limit'])) {
            $offset = $filters['offset'] ?? 0;
            $limit = "LIMIT {$offset}, {$filters['limit']}";
        }
        
        return $this->db->fetchAll(
            "SELECT * FROM email_logs {$whereClause} ORDER BY created_at DESC {$limit}",
            $params
        );
    }
    
    /**
     * Toplam kayıt sayısı
     */
    public function getCount($filters = []) {
        $where = [];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['template_slug'])) {
            $where[] = "template_slug = ?";
            $params[] = $filters['template_slug'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $result = $this->db->fetch(
            "SELECT COUNT(*) as total FROM email_logs {$whereClause}",
            $params
        );
        
        return $result['total'] ?? 0;
    }
    
    /**
     * ID ile log bul
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT * FROM email_logs WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Log oluştur
     */
    public function create(array $data) {
        return $this->db->insert('email_logs', [
            'template_slug' => $data['template_slug'] ?? null,
            'recipient_email' => $data['recipient_email'],
            'recipient_name' => $data['recipient_name'] ?? null,
            'subject' => $data['subject'],
            'body' => $data['body'] ?? null,
            'status' => $data['status'] ?? 'pending',
            'error_message' => $data['error_message'] ?? null,
            'sent_at' => $data['sent_at'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Log sil
     */
    public function delete($id) {
        return $this->db->delete('email_logs', 'id = ?', [$id]);
    }
    
    /**
     * Toplu sil
     */
    public function deleteMultiple(array $ids) {
        if (empty($ids)) return false;
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        return $this->db->query(
            "DELETE FROM email_logs WHERE id IN ({$placeholders})",
            $ids
        );
    }
    
    /**
     * Eski logları temizle (gün bazında)
     */
    public function cleanOldLogs($daysOld = 30) {
        return $this->db->query(
            "DELETE FROM email_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$daysOld]
        );
    }
    
    /**
     * İstatistikler
     */
    public function getStats() {
        $stats = [
            'total' => 0,
            'sent' => 0,
            'failed' => 0,
            'pending' => 0,
            'today' => 0,
            'this_week' => 0,
            'this_month' => 0
        ];
        
        // Durum bazında sayılar
        $statusCounts = $this->db->fetchAll(
            "SELECT status, COUNT(*) as count FROM email_logs GROUP BY status"
        );
        
        foreach ($statusCounts as $row) {
            $stats[$row['status']] = (int) $row['count'];
            $stats['total'] += (int) $row['count'];
        }
        
        // Bugün
        $today = $this->db->fetch(
            "SELECT COUNT(*) as count FROM email_logs WHERE DATE(created_at) = CURDATE()"
        );
        $stats['today'] = (int) ($today['count'] ?? 0);
        
        // Bu hafta
        $thisWeek = $this->db->fetch(
            "SELECT COUNT(*) as count FROM email_logs WHERE YEARWEEK(created_at) = YEARWEEK(NOW())"
        );
        $stats['this_week'] = (int) ($thisWeek['count'] ?? 0);
        
        // Bu ay
        $thisMonth = $this->db->fetch(
            "SELECT COUNT(*) as count FROM email_logs WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())"
        );
        $stats['this_month'] = (int) ($thisMonth['count'] ?? 0);
        
        return $stats;
    }
    
    /**
     * Son logları getir
     */
    public function getRecent($limit = 10) {
        return $this->db->fetchAll(
            "SELECT * FROM email_logs ORDER BY created_at DESC LIMIT ?",
            [$limit]
        );
    }
}
