<?php
/**
 * Quote Note Template Model
 * Teklif not şablonlarını yönetir
 */

require_once APP_PATH . '/models/Database.php';

class QuoteNoteTemplate {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm şablonları getir
     */
    public function getAll() {
        return $this->db->fetchAll(
            "SELECT * FROM quote_note_templates ORDER BY sort_order ASC, title ASC"
        );
    }
    
    /**
     * Aktif şablonları getir
     */
    public function getActive() {
        return $this->db->fetchAll(
            "SELECT * FROM quote_note_templates WHERE is_active = 1 ORDER BY sort_order ASC, title ASC"
        );
    }
    
    /**
     * ID ile şablon bul
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT * FROM quote_note_templates WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Yeni şablon oluştur
     */
    public function create(array $data) {
        return $this->db->insert('quote_note_templates', [
            'title' => $data['title'],
            'content' => $data['content'],
            'is_active' => $data['is_active'] ?? 1,
            'sort_order' => $data['sort_order'] ?? 0,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Şablon güncelle
     */
    public function update($id, array $data) {
        return $this->db->update('quote_note_templates', [
            'title' => $data['title'],
            'content' => $data['content'],
            'is_active' => $data['is_active'] ?? 1,
            'sort_order' => $data['sort_order'] ?? 0,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = ?', [$id]);
    }
    
    /**
     * Şablon sil
     */
    public function delete($id) {
        return $this->db->delete('quote_note_templates', 'id = ?', [$id]);
    }
    
    /**
     * Aktif/Pasif durumunu değiştir
     */
    public function toggleStatus($id) {
        return $this->db->query(
            "UPDATE quote_note_templates SET is_active = NOT is_active, updated_at = NOW() WHERE id = ?",
            [$id]
        );
    }
}
