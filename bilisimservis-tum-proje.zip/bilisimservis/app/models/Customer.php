<?php
/**
 * Customer Model
 */

class Customer {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm müşterileri getir
     */
    public function getAll($activeOnly = false) {
        $sql = "SELECT * FROM customers";
        if ($activeOnly) {
            $sql .= " WHERE is_active = 1";
        }
        $sql .= " ORDER BY company_name ASC";
        
        return $this->db->fetchAll($sql);
    }
    
    /**
     * Müşteri getir
     */
    public function findById($id) {
        return $this->db->fetch("SELECT * FROM customers WHERE id = ?", [$id]);
    }
    
    /**
     * Müşteri oluştur
     */
    public function create($data) {
        return $this->db->insert('customers', $data);
    }
    
    /**
     * Müşteri güncelle
     */
    public function update($id, $data) {
        return $this->db->update('customers', $data, 'id = ?', [$id]);
    }
    
    /**
     * Müşteri sil (soft delete - aktif/pasif yap)
     */
    public function delete($id) {
        return $this->db->update('customers', ['is_active' => 0], 'id = ?', [$id]);
    }
    
    /**
     * Müşteri sayısı
     */
    public function count($activeOnly = false) {
        $sql = "SELECT COUNT(*) as count FROM customers";
        if ($activeOnly) {
            $sql .= " WHERE is_active = 1";
        }
        $result = $this->db->fetch($sql);
        return $result['count'];
    }
}
