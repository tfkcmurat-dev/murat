<?php
/**
 * Reference Model
 */

class Reference {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm aktif referansları getir (sıralı)
     */
    public function getAllActive() {
        return $this->db->fetchAll(
            "SELECT * FROM `references` WHERE is_active = 1 ORDER BY sort_order ASC, id ASC"
        );
    }
    
    /**
     * Tüm referansları getir
     */
    public function getAll() {
        return $this->db->fetchAll(
            "SELECT * FROM `references` ORDER BY sort_order ASC, id ASC"
        );
    }
    
    /**
     * ID'ye göre referans getir
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT * FROM `references` WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Yeni referans ekle
     */
    public function create($data) {
        return $this->db->insert('references', $data);
    }
    
    /**
     * Referans güncelle
     */
    public function update($id, $data) {
        return $this->db->update('references', $data, 'id = ?', [$id]);
    }
    
    /**
     * Referans sil
     */
    public function delete($id) {
        return $this->db->delete('references', 'id = ?', [$id]);
    }
    
    /**
     * Referans aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        $reference = $this->findById($id);
        if ($reference) {
            $newStatus = $reference['is_active'] ? 0 : 1;
            return $this->db->update('references', ['is_active' => $newStatus], 'id = ?', [$id]);
        }
        return false;
    }
}
