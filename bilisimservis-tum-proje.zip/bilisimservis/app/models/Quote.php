<?php
/**
 * Quote Model
 */

class Quote {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm teklifleri getir
     */
    public function getAll($status = null) {
        $sql = "SELECT q.*, c.company_name, c.email as customer_email 
                FROM quotes q 
                LEFT JOIN customers c ON q.customer_id = c.id";
        
        $params = [];
        if ($status) {
            $sql .= " WHERE q.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY q.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    /**
     * Teklif getir (kalemleriyle birlikte)
     */
    public function findById($id) {
        $quote = $this->db->fetch(
            "SELECT 
                q.id,
                q.quote_number,
                q.customer_id,
                q.subject,
                q.status,
                q.subtotal,
                q.tax_total,
                q.discount_total,
                q.grand_total,
                q.notes,
                q.customer_note,
                q.valid_until,
                q.customer_response,
                q.customer_response_message,
                q.customer_response_date,
                q.created_at,
                q.updated_at,
                c.company_name,
                c.email,
                c.phone,
                c.province,
                c.district,
                c.address,
                c.tax_number
             FROM quotes q 
             LEFT JOIN customers c ON q.customer_id = c.id 
             WHERE q.id = ?",
            [$id]
        );
        
        if ($quote) {
            $quote['items'] = $this->getItems($id);
        }
        
        return $quote;
    }
    
    /**
     * Teklif kalemlerini getir
     */
    public function getItems($quoteId) {
        return $this->db->fetchAll(
            "SELECT qi.*, s.name as service_name 
             FROM quote_items qi 
             LEFT JOIN services s ON qi.service_id = s.id 
             WHERE qi.quote_id = ? 
             ORDER BY qi.sort_order ASC",
            [$quoteId]
        );
    }
    
    /**
     * Teklif oluştur
     */
    public function create($data, $items = []) {
        $this->db->beginTransaction();
        
        try {
            // Teklif numarası oluştur
            if (empty($data['quote_number'])) {
                $data['quote_number'] = generateQuoteNumber();
            }
            
            // Toplamları hesapla
            $totals = $this->calculateTotals($items);
            $data = array_merge($data, $totals);
            
            $quoteId = $this->db->insert('quotes', $data);
            
            // Kalemleri ekle
            foreach ($items as $index => $item) {
                $item['quote_id'] = $quoteId;
                $item['sort_order'] = $index;
                $this->db->insert('quote_items', $item);
            }
            
            // Geçmiş kaydı
            $this->addHistory($quoteId, 'created', null, $data['status']);
            
            $this->db->commit();
            return $quoteId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
    
    /**
     * Teklif güncelle
     */
    public function update($id, $data, $items = []) {
        $oldQuote = $this->findById($id);
        $oldStatus = $oldQuote['status'];
        
        $this->db->beginTransaction();
        
        try {
            // Toplamları hesapla
            $totals = $this->calculateTotals($items);
            $data = array_merge($data, $totals);
            
            // Teklifi güncelle
            $this->db->update('quotes', $data, 'id = ?', [$id]);
            
            // Eski kalemleri sil
            $this->db->delete('quote_items', 'quote_id = ?', [$id]);
            
            // Yeni kalemleri ekle
            foreach ($items as $index => $item) {
                $item['quote_id'] = $id;
                $item['sort_order'] = $index;
                $this->db->insert('quote_items', $item);
            }
            
            // Durum değiştiyse geçmiş kaydı
            if (isset($data['status']) && $data['status'] != $oldStatus) {
                $this->addHistory($id, 'status_changed', $oldStatus, $data['status']);
            } else {
                $this->addHistory($id, 'updated', null, null);
            }
            
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
    
    /**
     * Teklif toplamlarını hesapla
     */
    private function calculateTotals($items) {
        $subtotal = 0;
        $taxTotal = 0;
        $discountTotal = 0;
        
        foreach ($items as $item) {
            $quantity = floatval($item['quantity'] ?? 1);
            $unitPrice = floatval($item['unit_price'] ?? 0);
            $discount = floatval($item['discount'] ?? 0);
            $discountType = $item['discount_type'] ?? 'fixed';
            $taxRate = floatval($item['tax_rate'] ?? 18);
            
            // İndirim hesapla
            $itemGross = $quantity * $unitPrice;
            if ($discountType === 'percentage') {
                $actualDiscount = $itemGross * ($discount / 100);
            } else {
                $actualDiscount = $discount;
            }
            
            $itemSubtotal = $itemGross - $actualDiscount;
            $itemTax = $itemSubtotal * ($taxRate / 100);
            
            $subtotal += $itemSubtotal;
            $taxTotal += $itemTax;
            $discountTotal += $actualDiscount;
        }
        
        $grandTotal = $subtotal + $taxTotal;
        
        return [
            'subtotal' => round($subtotal, 2),
            'tax_total' => round($taxTotal, 2),
            'discount_total' => round($discountTotal, 2),
            'grand_total' => round($grandTotal, 2)
        ];
    }
    
    /**
     * Teklif numarasına göre bul
     */
    public function findByQuoteNumber($quoteNumber) {
        $quote = $this->db->fetch(
            "SELECT 
                q.id,
                q.quote_number,
                q.customer_id,
                q.subject,
                q.status,
                q.subtotal,
                q.tax_total,
                q.discount_total,
                q.grand_total,
                q.notes,
                q.customer_note,
                q.valid_until,
                q.customer_response,
                q.customer_response_message,
                q.customer_response_date,
                q.created_at,
                q.updated_at,
                c.company_name,
                c.email,
                c.phone,
                c.province,
                c.district,
                c.address,
                c.tax_number
             FROM quotes q 
             LEFT JOIN customers c ON q.customer_id = c.id 
             WHERE q.quote_number = ?",
            [$quoteNumber]
        );
        
        if ($quote) {
            $quote['items'] = $this->getItems($quote['id']);
        }
        
        return $quote;
    }
    
    /**
     * Teklif geçmişi ekle
     */
    public function addHistory($quoteId, $action, $oldStatus = null, $newStatus = null, $notes = null) {
        $userId = $_SESSION['user_id'] ?? null;
        
        return $this->db->insert('quote_history', [
            'quote_id' => $quoteId,
            'action' => $action,
            'old_status' => $oldStatus,
            'new_status' => $newStatus,
            'notes' => $notes,
            'user_id' => $userId
        ]);
    }
    
    /**
     * Teklif geçmişini getir
     */
    public function getHistory($quoteId) {
        return $this->db->fetchAll(
            "SELECT h.*, u.username, u.full_name 
             FROM quote_history h 
             LEFT JOIN users u ON h.user_id = u.id 
             WHERE h.quote_id = ? 
             ORDER BY h.created_at DESC",
            [$quoteId]
        );
    }
    
    /**
     * Teklif durumunu güncelle
     */
    public function updateStatus($id, $status, $notes = null) {
        $quote = $this->findById($id);
        if (!$quote) {
            return false;
        }
        
        $this->db->update('quotes', ['status' => $status], 'id = ?', [$id]);
        $this->addHistory($id, 'status_changed', $quote['status'], $status, $notes);
        
        return true;
    }
    
    /**
     * Teklif sayısı
     */
    public function count($status = null) {
        $sql = "SELECT COUNT(*) as count FROM quotes";
        $params = [];
        if ($status) {
            $sql .= " WHERE status = ?";
            $params[] = $status;
        }
        $result = $this->db->fetch($sql, $params);
        return $result['count'];
    }
    
    /**
     * Müşteri yanıtını kaydet
     */
    public function saveCustomerResponse($quoteNumber, $response, $message = null) {
        $quote = $this->findByQuoteNumber($quoteNumber);
        if (!$quote) {
            return ['success' => false, 'message' => 'Teklif bulunamadı.'];
        }
        
        // Sadece gönderilmiş teklifler için yanıt kabul et
        if (!in_array($quote['status'], ['sent', 'approved', 'rejected'])) {
            return ['success' => false, 'message' => 'Bu teklif yanıt için uygun değil.'];
        }
        
        // Geçerli yanıt kontrolü
        $validResponses = ['approved', 'rejected', 'revision_requested'];
        if (!in_array($response, $validResponses)) {
            return ['success' => false, 'message' => 'Geçersiz yanıt.'];
        }
        
        // Revize isteğinde mesaj zorunlu
        if ($response === 'revision_requested' && empty(trim($message))) {
            return ['success' => false, 'message' => 'Revize talebinde mesaj zorunludur.'];
        }
        
        // Yanıtı kaydet
        $this->db->query(
            "UPDATE quotes SET 
                customer_response = ?, 
                customer_response_message = ?, 
                customer_response_date = NOW()
            WHERE quote_number = ?",
            [$response, $message, $quoteNumber]
        );
        
        // Durumu da güncelle (onay/red için)
        if ($response === 'approved') {
            $this->updateStatus($quote['id'], 'approved', 'Müşteri tarafından onaylandı.');
        } elseif ($response === 'rejected') {
            $this->updateStatus($quote['id'], 'rejected', 'Müşteri tarafından reddedildi.');
        }
        // revision_requested için status değişmez, sadece bildirim yapılır
        
        // Geçmişe ekle
        $this->addHistory($quote['id'], 'customer_response', null, $response, $message);
        
        return ['success' => true, 'message' => 'Yanıtınız kaydedildi.'];
    }
}
