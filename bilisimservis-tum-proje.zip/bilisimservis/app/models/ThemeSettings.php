<?php
/**
 * ThemeSettings Model
 */

class ThemeSettings {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm ayarları getir
     */
    public function getAll() {
        return $this->db->fetchAll("SELECT * FROM theme_settings ORDER BY group_name, setting_key");
    }
    
    /**
     * Grup bazlı ayarları getir
     */
    public function getByGroup($group) {
        return $this->db->fetchAll(
            "SELECT * FROM theme_settings WHERE group_name = ? ORDER BY setting_key",
            [$group]
        );
    }
    
    /**
     * Tek bir ayarı getir
     */
    public function getByKey($key) {
        return $this->db->fetch(
            "SELECT * FROM theme_settings WHERE setting_key = ?",
            [$key]
        );
    }
    
    /**
     * Tek bir ayarın değerini getir
     */
    public function get($key, $default = null) {
        $setting = $this->getByKey($key);
        return $setting ? $setting['setting_value'] : $default;
    }
    
    /**
     * Ayar kaydet/güncelle
     */
    public function save($key, $value, $type = 'text', $group = 'general', $description = null) {
        $existing = $this->getByKey($key);
        
        if ($existing) {
            return $this->db->update('theme_settings', [
                'setting_value' => $value,
                'updated_at' => date('Y-m-d H:i:s')
            ], 'setting_key = ?', [$key]);
        } else {
            return $this->db->insert('theme_settings', [
                'setting_key' => $key,
                'setting_value' => $value,
                'setting_type' => $type,
                'group_name' => $group,
                'description' => $description
            ]);
        }
    }
    
    /**
     * Toplu ayar kaydetme
     */
    public function saveBatch($settings) {
        foreach ($settings as $key => $value) {
            $this->save($key, $value);
        }
    }
}
