<?php
/**
 * Contact Submission Model
 * İletişim formu kayıtlarını yönetir
 */

require_once APP_PATH . '/models/Database.php';

class ContactSubmission {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm form kayıtlarını getir (filtrelenebilir)
     */
    public function getAll($filters = []) {
        $where = [];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = "cs.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(cs.created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(cs.created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(cs.name LIKE ? OR cs.email LIKE ? OR cs.message LIKE ?)";
            $params[] = '%' . $filters['search'] . '%';
            $params[] = '%' . $filters['search'] . '%';
            $params[] = '%' . $filters['search'] . '%';
        }
        
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $limit = '';
        if (!empty($filters['limit'])) {
            $offset = $filters['offset'] ?? 0;
            $limit = "LIMIT {$offset}, {$filters['limit']}";
        }
        
        return $this->db->fetchAll(
            "SELECT cs.*, 
                    c.company_name as customer_company,
                    q.quote_number
             FROM contact_submissions cs
             LEFT JOIN customers c ON cs.customer_id = c.id
             LEFT JOIN quotes q ON cs.quote_id = q.id
             {$whereClause}
             ORDER BY cs.created_at DESC {$limit}",
            $params
        );
    }
    
    /**
     * Toplam kayıt sayısı
     */
    public function getCount($filters = []) {
        $where = [];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $result = $this->db->fetch(
            "SELECT COUNT(*) as total FROM contact_submissions {$whereClause}",
            $params
        );
        
        return $result['total'] ?? 0;
    }
    
    /**
     * Durum bazında sayılar
     */
    public function getCountByStatus() {
        $results = $this->db->fetchAll(
            "SELECT status, COUNT(*) as count FROM contact_submissions GROUP BY status"
        );
        
        $counts = [
            'new' => 0,
            'read' => 0,
            'replied' => 0,
            'converted' => 0,
            'total' => 0
        ];
        
        foreach ($results as $row) {
            $counts[$row['status']] = (int) $row['count'];
            $counts['total'] += (int) $row['count'];
        }
        
        return $counts;
    }
    
    /**
     * ID ile kayıt bul
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT cs.*, 
                    c.company_name as customer_company,
                    q.quote_number
             FROM contact_submissions cs
             LEFT JOIN customers c ON cs.customer_id = c.id
             LEFT JOIN quotes q ON cs.quote_id = q.id
             WHERE cs.id = ?",
            [$id]
        );
    }
    
    /**
     * Yeni kayıt oluştur
     */
    public function create(array $data) {
        return $this->db->insert('contact_submissions', [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'] ?? null,
            'subject' => $data['subject'] ?? null,
            'message' => $data['message'],
            'ip_address' => $data['ip_address'] ?? null,
            'user_agent' => $data['user_agent'] ?? null,
            'status' => 'new',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Durumu güncelle
     */
    public function updateStatus($id, $status) {
        // Doğrudan SQL ile güncelle (updated_at otomatik)
        return $this->db->query(
            "UPDATE contact_submissions SET status = ? WHERE id = ?",
            [$status, $id]
        );
    }
    
    /**
     * Not ekle
     */
    public function updateNotes($id, $notes) {
        return $this->db->query(
            "UPDATE contact_submissions SET notes = ? WHERE id = ?",
            [$notes, $id]
        );
    }
    
    /**
     * Kayıt sil
     */
    public function delete($id) {
        return $this->db->delete('contact_submissions', 'id = ?', [$id]);
    }
    
    /**
     * Müşteriye dönüştür
     */
    public function convertToCustomer($id) {
        $submission = $this->findById($id);
        if (!$submission) {
            return ['success' => false, 'message' => 'Kayıt bulunamadı.'];
        }
        
        // Zaten dönüştürülmüş mü kontrol et
        if ($submission['customer_id']) {
            return ['success' => false, 'message' => 'Bu kayıt zaten bir müşteriye dönüştürülmüş.'];
        }
        
        require_once APP_PATH . '/models/Customer.php';
        $customerModel = new Customer();
        
        // E-posta ile mevcut müşteri var mı kontrol et
        $existingCustomer = $this->db->fetch(
            "SELECT * FROM customers WHERE email = ?",
            [$submission['email']]
        );
        
        if ($existingCustomer) {
            // Mevcut müşteriye bağla
            $this->db->query(
                "UPDATE contact_submissions SET customer_id = ?, status = 'converted' WHERE id = ?",
                [$existingCustomer['id'], $id]
            );
            
            return [
                'success' => true,
                'message' => 'Mevcut müşteriye bağlandı.',
                'customer_id' => $existingCustomer['id'],
                'is_new' => false
            ];
        }
        
        // İsmi parçala (ad soyad)
        $nameParts = explode(' ', $submission['name'], 2);
        $firstName = $nameParts[0];
        $lastName = $nameParts[1] ?? '';
        
        // Yeni müşteri oluştur
        $customerId = $customerModel->create([
            'company_name' => $submission['name'], // Şirket adı olarak isim kullan
            'contact_name' => $submission['name'],
            'email' => $submission['email'],
            'phone' => $submission['phone'] ?? '',
            'address' => '',
            'province' => '',
            'district' => '',
            'tax_office' => '',
            'tax_number' => '',
            'notes' => 'İletişim formundan oluşturuldu. Orijinal mesaj: ' . $submission['message']
        ]);
        
        if ($customerId) {
            $this->db->query(
                "UPDATE contact_submissions SET customer_id = ?, status = 'converted' WHERE id = ?",
                [$customerId, $id]
            );
            
            return [
                'success' => true,
                'message' => 'Yeni müşteri oluşturuldu.',
                'customer_id' => $customerId,
                'is_new' => true
            ];
        }
        
        return ['success' => false, 'message' => 'Müşteri oluşturulurken hata oluştu.'];
    }
    
    /**
     * Teklif bağla
     */
    public function linkQuote($id, $quoteId) {
        return $this->db->query(
            "UPDATE contact_submissions SET quote_id = ?, status = 'converted' WHERE id = ?",
            [$quoteId, $id]
        );
    }
    
    /**
     * Yeni (okunmamış) kayıt sayısı
     */
    public function getNewCount() {
        $result = $this->db->fetch(
            "SELECT COUNT(*) as count FROM contact_submissions WHERE status = 'new'"
        );
        return $result['count'] ?? 0;
    }
    
    /**
     * Son kayıtları getir
     */
    public function getRecent($limit = 5) {
        return $this->db->fetchAll(
            "SELECT * FROM contact_submissions ORDER BY created_at DESC LIMIT ?",
            [$limit]
        );
    }
}
