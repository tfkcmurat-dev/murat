<?php
/**
 * Email Template Model
 * E-posta şablonlarını yönetir
 */

require_once APP_PATH . '/models/Database.php';

class EmailTemplate {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm şablonları getir
     */
    public function getAll() {
        return $this->db->fetchAll(
            "SELECT * FROM email_templates ORDER BY name ASC"
        );
    }
    
    /**
     * Aktif şablonları getir
     */
    public function getActive() {
        return $this->db->fetchAll(
            "SELECT * FROM email_templates WHERE is_active = 1 ORDER BY name ASC"
        );
    }
    
    /**
     * ID ile şablon bul
     */
    public function findById($id) {
        return $this->db->fetch(
            "SELECT * FROM email_templates WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Slug ile şablon bul
     */
    public function findBySlug($slug) {
        return $this->db->fetch(
            "SELECT * FROM email_templates WHERE slug = ?",
            [$slug]
        );
    }
    
    /**
     * Yeni şablon oluştur
     */
    public function create(array $data) {
        return $this->db->insert('email_templates', [
            'slug' => $data['slug'],
            'name' => $data['name'],
            'subject' => $data['subject'],
            'body' => $data['body'],
            'variables' => $data['variables'] ?? null,
            'is_active' => $data['is_active'] ?? 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Şablon güncelle
     */
    public function update($id, array $data) {
        $updateData = [
            'name' => $data['name'],
            'subject' => $data['subject'],
            'body' => $data['body'],
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if (isset($data['variables'])) {
            $updateData['variables'] = $data['variables'];
        }
        
        if (isset($data['is_active'])) {
            $updateData['is_active'] = $data['is_active'];
        }
        
        return $this->db->update('email_templates', $updateData, 'id = ?', [$id]);
    }
    
    /**
     * Şablon sil
     */
    public function delete($id) {
        return $this->db->delete('email_templates', 'id = ?', [$id]);
    }
    
    /**
     * Aktif/Pasif durumunu değiştir
     */
    public function toggleStatus($id) {
        return $this->db->query(
            "UPDATE email_templates SET is_active = NOT is_active, updated_at = NOW() WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Şablondaki değişkenleri çıkar
     */
    public function extractVariables($body) {
        preg_match_all('/\{([a-zA-Z_]+)\}/', $body, $matches);
        return array_unique($matches[1]);
    }
    
    /**
     * Şablonu önizle (örnek değerlerle)
     */
    public function preview($templateId, array $sampleValues = []) {
        $template = $this->findById($templateId);
        if (!$template) {
            return null;
        }
        
        $defaults = [
            'name' => 'Örnek İsim',
            'email' => 'ornek@email.com',
            'subject' => 'Örnek Konu',
            'message' => 'Bu bir örnek mesajdır.',
            'date' => date('d.m.Y H:i'),
            'site_name' => getThemeSetting('site_name', 'Bilişim Servis'),
            'contact_phone' => getThemeSetting('contact_phone', '0554 863 48 70'),
            'contact_email' => getThemeSetting('contact_email', 'info@bilisimservis.com'),
            'ip_address' => '192.168.1.1',
            'customer_name' => 'Örnek Müşteri',
            'quote_number' => 'TKL-2024-0001',
            'quote_subject' => 'Örnek Teklif',
            'quote_items' => '<div>Örnek hizmet kalemi</div>',
            'grand_total' => '1.500,00 ₺',
            'valid_until' => date('d.m.Y', strtotime('+30 days')),
            'quote_pdf_link' => '#'
        ];
        
        $values = array_merge($defaults, $sampleValues);
        
        $subject = $template['subject'];
        $body = $template['body'];
        
        foreach ($values as $key => $value) {
            $subject = str_replace('{' . $key . '}', $value, $subject);
            $body = str_replace('{' . $key . '}', $value, $body);
        }
        
        return [
            'subject' => $subject,
            'body' => $body
        ];
    }
}
