<?php
/**
 * Genel Yapılandırma Dosyası
 */

// Ortam ayarı: 'development' veya 'production'
define('APP_ENV', 'production');

// Hata raporlama
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', dirname(__DIR__, 2) . '/logs/error.log');
}

// Zaman dilimi
date_default_timezone_set('Europe/Istanbul');

// Karakter kodlaması
mb_internal_encoding('UTF-8');

// Proje kök dizini
// config.php app/config/ klasöründe olduğu için:
// __DIR__ = app/config, dirname(__DIR__, 1) = app, dirname(__DIR__, 2) = root
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__, 2));
}
define('APP_PATH', ROOT_PATH . DIRECTORY_SEPARATOR . 'app');
define('ADMIN_PATH', ROOT_PATH . DIRECTORY_SEPARATOR . 'admin');
define('PUBLIC_PATH', ROOT_PATH . DIRECTORY_SEPARATOR . 'public');

// URL yapılandırması
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_url = $protocol . $host;

// Admin URL'i
$admin_url = $base_url . '/admin';

// Site URL'i
$site_url = $base_url;

define('BASE_URL', $base_url);
define('SITE_URL', $site_url);
define('ADMIN_URL', $admin_url);

// Veritabanı yapılandırması
define('DB_HOST', 'localhost');
define('DB_NAME', 'YOUR_DATABASE_NAME');
define('DB_USER', 'YOUR_DATABASE_USER');
define('DB_PASS', 'YOUR_DATABASE_PASSWORD');
define('DB_CHARSET', 'utf8mb4');

// Session ayarları
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
// HTTPS kullanılıyorsa cookie_secure aktif
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
ini_set('session.cookie_secure', $isHttps ? 1 : 0);
session_start();

// Güvenlik ayarları
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_LIFETIME', 3600); // 1 saat

// Dosya yükleme ayarları
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// Composer autoloader
if (file_exists(ROOT_PATH . '/vendor/autoload.php')) {
    require_once ROOT_PATH . '/vendor/autoload.php';
}

// Helper dosyalarını yükle
require_once APP_PATH . '/helpers/functions.php';
require_once APP_PATH . '/helpers/security.php';
require_once APP_PATH . '/helpers/seo.php';

// Veritabanı bağlantısını yükle
require_once APP_PATH . '/models/Database.php';
