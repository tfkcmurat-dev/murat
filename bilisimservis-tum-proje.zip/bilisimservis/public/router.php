<?php
/**
 * PHP Built-in Server Router
 * Tüm istekleri doğru dosyalara yönlendirir
 */

$requestUri = $_SERVER['REQUEST_URI'];
$requestPath = parse_url($requestUri, PHP_URL_PATH);

// Query string'i kaldır
$requestPath = strtok($requestPath, '?');

// Admin paneli istekleri
if (strpos($requestPath, '/admin/') === 0) {
    $adminFile = __DIR__ . '/../admin' . substr($requestPath, 6);
    
    // Statik dosyalar için (CSS, JS, images)
    $extension = strtolower(pathinfo($adminFile, PATHINFO_EXTENSION));
    $staticMimeTypes = [
        'css' => 'text/css',
        'js' => 'application/javascript',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'webp' => 'image/webp',
        'ico' => 'image/x-icon',
        'woff' => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf' => 'font/ttf'
    ];
    
    if (isset($staticMimeTypes[$extension]) && file_exists($adminFile)) {
        header('Content-Type: ' . $staticMimeTypes[$extension]);
        readfile($adminFile);
        return true;
    }
    
    // Eğer dosya yoksa ve .php uzantısı yoksa ekle
    if (!file_exists($adminFile) && !file_exists($adminFile . '.php')) {
        $adminFile = $adminFile . '.php';
    }
    
    if (file_exists($adminFile)) {
        require_once $adminFile;
        return true;
    }
}

// Public klasöründeki dosyalar (CSS, JS, images, etc.)
$publicFile = __DIR__ . $requestPath;

if (file_exists($publicFile) && is_file($publicFile)) {
    // Statik dosyalar için doğru content-type ayarla
    $extension = strtolower(pathinfo($publicFile, PATHINFO_EXTENSION));
    $mimeTypes = [
        'css' => 'text/css',
        'js' => 'application/javascript',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'webp' => 'image/webp',
        'ico' => 'image/x-icon'
    ];
    
    if (isset($mimeTypes[$extension])) {
        header('Content-Type: ' . $mimeTypes[$extension]);
    }
    
    return false; // PHP built-in server dosyayı kendisi serve edecek
}

// Sitemap.xml
if ($requestPath === '/sitemap.xml') {
    require_once __DIR__ . '/sitemap.php';
    return true;
}

// Robots.txt
if ($requestPath === '/robots.txt') {
    require_once __DIR__ . '/robots.php';
    return true;
}

// Frontend routing - index.php'ye yönlendir
if ($requestPath === '/' || $requestPath === '') {
    require_once __DIR__ . '/index.php';
    return true;
}

// Multipage routing
$routes = [
    '/hizmetler' => 'services.php',
    '/hakkimizda' => 'about.php',
    '/iletisim' => 'contact.php',
];

// Hizmet detay sayfası: /hizmet/[slug]
if (preg_match('#^/hizmet/([a-z0-9-]+)$#', $requestPath, $matches)) {
    $_GET['slug'] = $matches[1];
    require_once __DIR__ . '/service-detail.php';
    return true;
}

// Teklif görüntüleme sayfası: /teklif/[quote_number]
if (preg_match('#^/teklif/([A-Za-z0-9-]+)$#', $requestPath, $matches)) {
    $_GET['quote_number'] = $matches[1];
    require_once __DIR__ . '/quote-view.php';
    return true;
}

// Teklif yanıt: /teklif/[quote_number]/yanit
if (preg_match('#^/teklif/([A-Za-z0-9-]+)/yanit$#', $requestPath, $matches)) {
    $_GET['quote_number'] = $matches[1];
    require_once __DIR__ . '/quote-respond.php';
    return true;
}

// Diğer route'lar
if (isset($routes[$requestPath])) {
    require_once __DIR__ . '/' . $routes[$requestPath];
    return true;
}

// Diğer frontend istekleri
if (file_exists(__DIR__ . $requestPath . '.php')) {
    require_once __DIR__ . $requestPath . '.php';
    return true;
}

// 404 - index.php'ye yönlendir
require_once __DIR__ . '/index.php';
return true;
