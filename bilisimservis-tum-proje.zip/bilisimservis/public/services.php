<?php
/**
 * Hizmetler Sayfası
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/ServiceController.php';

$controller = new ServiceController();
$controller->index();
