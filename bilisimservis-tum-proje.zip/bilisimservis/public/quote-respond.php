<?php
/**
 * Quote Response Entry Point
 * Müşteri teklif yanıtı işleme
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/QuoteViewController.php';

$quoteNumber = $_GET['quote_number'] ?? '';

if (empty($quoteNumber)) {
    header('Location: ' . url('/'));
    exit;
}

$controller = new QuoteViewController();
$controller->respond($quoteNumber);
