<?php
/**
 * İletişim Formu İşleme
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/ContactController.php';

$controller = new ContactController();
$controller->index();
