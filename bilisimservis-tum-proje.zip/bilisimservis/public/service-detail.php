<?php
/**
 * Hizmet Detay Sayfası
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/ServiceDetailController.php';

$slug = $_GET['slug'] ?? '';
$controller = new ServiceDetailController();
$controller->show($slug);
