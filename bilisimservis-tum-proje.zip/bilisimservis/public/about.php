<?php
/**
 * Hakkımızda Sayfası
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/AboutController.php';

$controller = new AboutController();
$controller->index();
