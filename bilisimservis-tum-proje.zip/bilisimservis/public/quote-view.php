<?php
/**
 * Public Quote View Entry Point
 * Teklif görüntüleme sayfası
 */

require_once __DIR__ . '/../app/config/config.php';
require_once APP_PATH . '/controllers/QuoteViewController.php';

$quoteNumber = $_GET['quote_number'] ?? '';

if (empty($quoteNumber)) {
    header('Location: ' . url('/'));
    exit;
}

$controller = new QuoteViewController();
$controller->view($quoteNumber);
