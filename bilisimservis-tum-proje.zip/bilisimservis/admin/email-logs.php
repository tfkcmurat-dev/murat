<?php
/**
 * Email Logs Entry Point
 * E-posta Log Kayıtları
 */

require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/EmailLogController.php';

$controller = new EmailLogController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'view':
        if ($id) {
            $controller->view($id);
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        }
        redirect(adminUrl('email-logs.php'));
        break;
    case 'delete-multiple':
        $controller->deleteMultiple();
        break;
    case 'clean':
        $controller->cleanOld();
        break;
    default:
        $controller->index();
        break;
}
