<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/ContactPageController.php';

$controller = new ContactPageController();
$controller->index();
