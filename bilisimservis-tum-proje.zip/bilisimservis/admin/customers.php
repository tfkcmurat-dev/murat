<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/CustomerController.php';

$controller = new CustomerController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'create':
        $controller->create();
        break;
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('customers.php'));
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        } else {
            redirect(adminUrl('customers.php'));
        }
        break;
    default:
        $controller->index();
        break;
}
