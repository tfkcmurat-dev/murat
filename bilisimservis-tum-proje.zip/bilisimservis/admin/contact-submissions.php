<?php
/**
 * Contact Submissions Entry Point
 * İletişim Form Kayıtları
 */

require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/ContactSubmissionController.php';

$controller = new ContactSubmissionController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'view':
        if ($id) {
            $controller->view($id);
        } else {
            redirect(adminUrl('contact-submissions.php'));
        }
        break;
    case 'update-status':
        if ($id) {
            $controller->updateStatus($id);
        }
        break;
    case 'convert-customer':
        if ($id) {
            $controller->convertToCustomer($id);
        }
        break;
    case 'create-quote':
        if ($id) {
            $controller->createQuote($id);
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        }
        redirect(adminUrl('contact-submissions.php'));
        break;
    default:
        $controller->index();
        break;
}
