<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/HomepageController.php';

$controller = new HomepageController();
$controller->index();
