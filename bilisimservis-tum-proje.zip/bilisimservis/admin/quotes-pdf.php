<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/QuotePdfController.php';

// Önbelleği devre dışı bırak
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$quoteId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($quoteId <= 0) {
    die('Geçerli bir teklif ID belirtilmedi.');
}

$controller = new QuotePdfController();
$controller->generate($quoteId);
