<?php
/**
 * Mail Settings Entry Point
 * SMTP Ayarları
 */

require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/MailSettingsController.php';

$controller = new MailSettingsController();
$controller->index();
