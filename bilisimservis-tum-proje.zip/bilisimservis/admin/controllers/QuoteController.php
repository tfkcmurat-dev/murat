<?php
/**
 * Quote Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Quote.php';
require_once APP_PATH . '/models/Customer.php';
require_once APP_PATH . '/models/Service.php';
require_once APP_PATH . '/models/QuoteNoteTemplate.php';
require_once APP_PATH . '/services/MailService.php';

class QuoteController {
    private $quoteModel;
    private $customerModel;
    private $serviceModel;
    private $noteTemplateModel;
    private $mailService;
    
    public function __construct() {
        $this->quoteModel = new Quote();
        $this->customerModel = new Customer();
        $this->serviceModel = new Service();
        $this->noteTemplateModel = new QuoteNoteTemplate();
        $this->mailService = new MailService();
    }
    
    /**
     * Teklif listesi
     */
    public function index() {
        requireAuth();
        
        $status = $_GET['status'] ?? null;
        $quotes = $this->quoteModel->getAll($status);
        
        $pageTitle = 'Teklifler';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quotes/index', ['quotes' => $quotes, 'currentStatus' => $status]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Teklif görüntüleme
     */
    public function view($id) {
        requireAuth();
        
        $quote = $this->quoteModel->findById($id);
        if (!$quote) {
            setFlash('error', 'Teklif bulunamadı.');
            redirect(adminUrl('quotes.php'));
        }
        
        $history = $this->quoteModel->getHistory($id);
        
        $pageTitle = 'Teklif Detayı';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quotes/view', ['quote' => $quote, 'history' => $history]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni teklif oluşturma
     */
    public function create() {
        requireAuth();
        
        $customers = $this->customerModel->getAll(true);
        $services = $this->serviceModel->getAll(true);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('quotes.php?action=create'));
            }
            
            $customerId = intval($_POST['customer_id'] ?? 0);
            if (!$customerId) {
                setFlash('error', 'Müşteri seçimi gereklidir.');
                redirect(adminUrl('quotes.php?action=create'));
            }
            
            // Teklif verileri
            $quoteData = [
                'customer_id' => $customerId,
                'subject' => sanitizeInput($_POST['subject'] ?? ''),
                'status' => sanitizeInput($_POST['status'] ?? 'draft'),
                'notes' => sanitizeInput($_POST['notes'] ?? ''),
                'customer_note' => sanitizeInput($_POST['customer_note'] ?? ''),
                'valid_until' => !empty($_POST['valid_until']) ? $_POST['valid_until'] : null
            ];
            
            // Teklif kalemleri
            $items = [];
            if (isset($_POST['items']) && is_array($_POST['items'])) {
                foreach ($_POST['items'] as $item) {
                    if (!empty($item['item_name']) && !empty($item['unit_price'])) {
                        $discountType = $item['discount_type'] ?? 'fixed';
                        $discount = floatval($item['discount'] ?? 0);
                        $quantity = floatval($item['quantity'] ?? 1);
                        $unitPrice = floatval($item['unit_price']);
                        $taxRate = floatval($item['tax_rate'] ?? 18);
                        
                        // İndirim hesapla
                        $itemGross = $quantity * $unitPrice;
                        if ($discountType === 'percentage') {
                            $actualDiscount = $itemGross * ($discount / 100);
                        } else {
                            $actualDiscount = $discount;
                        }
                        
                        $subtotal = $itemGross - $actualDiscount;
                        $taxAmount = $subtotal * ($taxRate / 100);
                        $total = $subtotal + $taxAmount;
                        
                        $items[] = [
                            'service_id' => !empty($item['service_id']) ? intval($item['service_id']) : null,
                            'item_name' => sanitizeInput($item['item_name']),
                            'description' => sanitizeInput($item['description'] ?? ''),
                            'quantity' => $quantity,
                            'unit_price' => $unitPrice,
                            'tax_rate' => $taxRate,
                            'discount' => $discount,
                            'discount_type' => $discountType,
                            'subtotal' => round($subtotal, 2),
                            'tax_amount' => round($taxAmount, 2),
                            'total' => round($total, 2)
                        ];
                    }
                }
            }
            
            if (empty($items)) {
                setFlash('error', 'En az bir teklif kalemi eklenmelidir.');
                redirect(adminUrl('quotes.php?action=create'));
            }
            
            try {
                $quoteId = $this->quoteModel->create($quoteData, $items);
                setFlash('success', 'Teklif başarıyla oluşturuldu.');
                redirect(adminUrl('quotes.php?action=view&id=' . $quoteId));
            } catch (Exception $e) {
                setFlash('error', 'Teklif oluşturulurken bir hata oluştu: ' . $e->getMessage());
                redirect(adminUrl('quotes.php?action=create'));
            }
        }
        
        $noteTemplates = $this->noteTemplateModel->getActive();
        
        $pageTitle = 'Yeni Teklif Oluştur';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quotes/create', ['customers' => $customers, 'services' => $services, 'noteTemplates' => $noteTemplates]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Teklif düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $quote = $this->quoteModel->findById($id);
        if (!$quote) {
            setFlash('error', 'Teklif bulunamadı.');
            redirect(adminUrl('quotes.php'));
        }
        
        $customers = $this->customerModel->getAll(true);
        $services = $this->serviceModel->getAll(true);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('quotes.php?action=edit&id=' . $id));
            }
            
            $customerId = intval($_POST['customer_id'] ?? 0);
            if (!$customerId) {
                setFlash('error', 'Müşteri seçimi gereklidir.');
                redirect(adminUrl('quotes.php?action=edit&id=' . $id));
            }
            
            // Teklif verileri
            $quoteData = [
                'customer_id' => $customerId,
                'subject' => sanitizeInput($_POST['subject'] ?? ''),
                'status' => sanitizeInput($_POST['status'] ?? 'draft'),
                'notes' => sanitizeInput($_POST['notes'] ?? ''),
                'customer_note' => sanitizeInput($_POST['customer_note'] ?? ''),
                'valid_until' => !empty($_POST['valid_until']) ? $_POST['valid_until'] : null,
                // Teklif düzenlendiğinde müşteri yanıtını sıfırla (tekrar yanıt verebilsin)
                'customer_response' => 'pending',
                'customer_response_message' => null,
                'customer_response_date' => null
            ];
            
            // Teklif kalemleri
            $items = [];
            if (isset($_POST['items']) && is_array($_POST['items'])) {
                foreach ($_POST['items'] as $item) {
                    if (!empty($item['item_name']) && !empty($item['unit_price'])) {
                        $discountType = $item['discount_type'] ?? 'fixed';
                        $discount = floatval($item['discount'] ?? 0);
                        $quantity = floatval($item['quantity'] ?? 1);
                        $unitPrice = floatval($item['unit_price']);
                        $taxRate = floatval($item['tax_rate'] ?? 18);
                        
                        // İndirim hesapla
                        $itemGross = $quantity * $unitPrice;
                        if ($discountType === 'percentage') {
                            $actualDiscount = $itemGross * ($discount / 100);
                        } else {
                            $actualDiscount = $discount;
                        }
                        
                        $subtotal = $itemGross - $actualDiscount;
                        $taxAmount = $subtotal * ($taxRate / 100);
                        $total = $subtotal + $taxAmount;
                        
                        $items[] = [
                            'service_id' => !empty($item['service_id']) ? intval($item['service_id']) : null,
                            'item_name' => sanitizeInput($item['item_name']),
                            'description' => sanitizeInput($item['description'] ?? ''),
                            'quantity' => $quantity,
                            'unit_price' => $unitPrice,
                            'tax_rate' => $taxRate,
                            'discount' => $discount,
                            'discount_type' => $discountType,
                            'subtotal' => round($subtotal, 2),
                            'tax_amount' => round($taxAmount, 2),
                            'total' => round($total, 2)
                        ];
                    }
                }
            }
            
            if (empty($items)) {
                setFlash('error', 'En az bir teklif kalemi eklenmelidir.');
                redirect(adminUrl('quotes.php?action=edit&id=' . $id));
            }
            
            try {
                $this->quoteModel->update($id, $quoteData, $items);
                setFlash('success', 'Teklif başarıyla güncellendi.');
                redirect(adminUrl('quotes.php?action=view&id=' . $id));
            } catch (Exception $e) {
                setFlash('error', 'Teklif güncellenirken bir hata oluştu: ' . $e->getMessage());
                redirect(adminUrl('quotes.php?action=edit&id=' . $id));
            }
        }
        
        $noteTemplates = $this->noteTemplateModel->getActive();
        
        $pageTitle = 'Teklif Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quotes/edit', [
            'quote' => $quote,
            'customers' => $customers,
            'services' => $services,
            'noteTemplates' => $noteTemplates
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Teklif durumunu güncelle
     */
    public function updateStatus($id) {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('quotes.php'));
            }
            
            $status = sanitizeInput($_POST['status'] ?? '');
            $notes = sanitizeInput($_POST['notes'] ?? '');
            $sendEmail = isset($_POST['send_email']) && $_POST['send_email'] == '1';
            
            if (in_array($status, ['draft', 'sent', 'approved', 'rejected'])) {
                $this->quoteModel->updateStatus($id, $status, $notes);
                
                // Durum "Gönderildi" ise ve e-posta gönderimi istendiyse
                if ($status === 'sent' && $sendEmail) {
                    $quote = $this->quoteModel->findById($id);
                    if ($quote) {
                        $result = $this->mailService->sendQuoteEmail($quote);
                        if ($result['success']) {
                            setFlash('success', 'Teklif durumu güncellendi ve müşteriye e-posta gönderildi.');
                        } else {
                            setFlash('warning', 'Teklif durumu güncellendi ancak e-posta gönderilemedi: ' . $result['message']);
                        }
                    } else {
                        setFlash('success', 'Teklif durumu güncellendi.');
                    }
                } else {
                    setFlash('success', 'Teklif durumu güncellendi.');
                }
            }
        }
        
        redirect(adminUrl('quotes.php?action=view&id=' . $id));
    }
    
    /**
     * Teklif e-postasını tekrar gönder
     */
    public function resendEmail($id) {
        requireAuth();
        
        $quote = $this->quoteModel->findById($id);
        if (!$quote) {
            setFlash('error', 'Teklif bulunamadı.');
            redirect(adminUrl('quotes.php'));
        }
        
        $result = $this->mailService->sendQuoteEmail($quote);
        
        if ($result['success']) {
            setFlash('success', 'Teklif e-postası müşteriye tekrar gönderildi.');
        } else {
            setFlash('error', 'E-posta gönderilemedi: ' . $result['message']);
        }
        
        redirect(adminUrl('quotes.php?action=view&id=' . $id));
    }
}
