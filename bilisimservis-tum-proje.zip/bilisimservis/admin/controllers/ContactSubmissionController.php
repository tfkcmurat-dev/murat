<?php
/**
 * Contact Submission Controller
 * İletişim formu kayıtlarını yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ContactSubmission.php';

class ContactSubmissionController {
    private $submissionModel;
    
    public function __construct() {
        $this->submissionModel = new ContactSubmission();
    }
    
    /**
     * Form kayıtları listesi
     */
    public function index() {
        requireAuth();
        
        // Filtreler
        $filters = [
            'status' => $_GET['status'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
            'search' => $_GET['search'] ?? '',
            'limit' => 25,
            'offset' => (($_GET['page'] ?? 1) - 1) * 25
        ];
        
        $submissions = $this->submissionModel->getAll($filters);
        $totalCount = $this->submissionModel->getCount($filters);
        $statusCounts = $this->submissionModel->getCountByStatus();
        
        $pageTitle = 'Form Kayıtları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('contact-submissions/index', [
            'submissions' => $submissions,
            'filters' => $filters,
            'totalCount' => $totalCount,
            'statusCounts' => $statusCounts,
            'currentPage' => $_GET['page'] ?? 1,
            'totalPages' => ceil($totalCount / 25)
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Form detay sayfası
     */
    public function view($id) {
        requireAuth();
        
        $submission = $this->submissionModel->findById($id);
        
        if (!$submission) {
            setFlash('error', 'Kayıt bulunamadı.');
            redirect(adminUrl('contact-submissions.php'));
        }
        
        // Okunmamışsa okundu olarak işaretle
        if ($submission['status'] === 'new') {
            $this->submissionModel->updateStatus($id, 'read');
            $submission['status'] = 'read';
        }
        
        // Not güncelleme
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['notes'])) {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('contact-submissions.php?action=view&id=' . $id));
            }
            
            $this->submissionModel->updateNotes($id, sanitizeInput($_POST['notes']));
            setFlash('success', 'Not kaydedildi.');
            redirect(adminUrl('contact-submissions.php?action=view&id=' . $id));
        }
        
        $pageTitle = 'Form Detayı';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('contact-submissions/view', [
            'submission' => $submission
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Durum güncelle (AJAX)
     */
    public function updateStatus($id) {
        requireAuth();
        
        header('Content-Type: application/json');
        
        if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Güvenlik hatası.']);
            exit;
        }
        
        $status = sanitizeInput($_POST['status'] ?? '');
        $validStatuses = ['new', 'read', 'replied', 'converted'];
        
        if (!in_array($status, $validStatuses)) {
            echo json_encode(['success' => false, 'message' => 'Geçersiz durum.']);
            exit;
        }
        
        if ($this->submissionModel->updateStatus($id, $status)) {
            echo json_encode(['success' => true, 'message' => 'Durum güncellendi.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Güncelleme başarısız.']);
        }
        exit;
    }
    
    /**
     * Müşteriye dönüştür
     */
    public function convertToCustomer($id) {
        requireAuth();
        
        $result = $this->submissionModel->convertToCustomer($id);
        
        if ($result['success']) {
            setFlash('success', $result['message']);
            
            // Müşteri detayına yönlendir
            redirect(adminUrl('customers.php?action=edit&id=' . $result['customer_id']));
        } else {
            setFlash('error', $result['message']);
            redirect(adminUrl('contact-submissions.php?action=view&id=' . $id));
        }
    }
    
    /**
     * Teklif oluştur
     */
    public function createQuote($id) {
        requireAuth();
        
        $submission = $this->submissionModel->findById($id);
        
        if (!$submission) {
            setFlash('error', 'Kayıt bulunamadı.');
            redirect(adminUrl('contact-submissions.php'));
        }
        
        // Eğer müşteriye dönüştürülmemişse önce dönüştür
        if (!$submission['customer_id']) {
            $result = $this->submissionModel->convertToCustomer($id);
            if (!$result['success']) {
                setFlash('error', $result['message']);
                redirect(adminUrl('contact-submissions.php?action=view&id=' . $id));
            }
            $customerId = $result['customer_id'];
        } else {
            $customerId = $submission['customer_id'];
        }
        
        // Teklif oluşturma sayfasına yönlendir (müşteri seçili olarak)
        setFlash('info', 'Form kaydından teklif oluşturuluyor. Lütfen teklif detaylarını doldurun.');
        redirect(adminUrl('quotes.php?action=create&customer_id=' . $customerId . '&submission_id=' . $id));
    }
    
    /**
     * Kayıt sil
     */
    public function delete($id) {
        requireAuth();
        
        if ($this->submissionModel->delete($id)) {
            setFlash('success', 'Kayıt silindi.');
        } else {
            setFlash('error', 'Silme işlemi başarısız.');
        }
    }
}
