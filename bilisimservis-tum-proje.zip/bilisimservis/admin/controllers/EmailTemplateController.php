<?php
/**
 * Email Template Controller
 * E-posta şablonlarını yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/EmailTemplate.php';

class EmailTemplateController {
    private $templateModel;
    
    public function __construct() {
        $this->templateModel = new EmailTemplate();
    }
    
    /**
     * Şablon listesi
     */
    public function index() {
        requireAuth();
        
        $templates = $this->templateModel->getAll();
        
        $pageTitle = 'E-Mail Şablonları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('email-templates/index', [
            'templates' => $templates
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Şablon düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $template = $this->templateModel->findById($id);
        
        if (!$template) {
            setFlash('error', 'Şablon bulunamadı.');
            redirect(adminUrl('email-templates.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('email-templates.php?action=edit&id=' . $id));
            }
            
            $data = [
                'name' => sanitizeInput($_POST['name'] ?? ''),
                'subject' => sanitizeInput($_POST['subject'] ?? ''),
                'body' => $_POST['body'] ?? '', // HTML içerik, sanitize etme
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            // Değişkenleri body'den çıkar
            $variables = $this->templateModel->extractVariables($data['body']);
            $data['variables'] = json_encode($variables);
            
            if ($this->templateModel->update($id, $data)) {
                setFlash('success', 'Şablon başarıyla güncellendi.');
            } else {
                setFlash('error', 'Şablon güncellenirken hata oluştu.');
            }
            
            redirect(adminUrl('email-templates.php'));
        }
        
        // Mevcut değişkenleri çıkar
        $variables = $this->templateModel->extractVariables($template['body']);
        
        $pageTitle = 'Şablon Düzenle: ' . $template['name'];
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('email-templates/edit', [
            'template' => $template,
            'variables' => $variables
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Aktif/Pasif durumunu değiştir
     */
    public function toggle($id) {
        requireAuth();
        
        if ($this->templateModel->toggleStatus($id)) {
            setFlash('success', 'Şablon durumu güncellendi.');
        } else {
            setFlash('error', 'Durum güncellenirken hata oluştu.');
        }
    }
    
    /**
     * Şablon önizleme (AJAX)
     */
    public function preview($id) {
        requireAuth();
        
        header('Content-Type: application/json');
        
        $preview = $this->templateModel->preview($id);
        
        if ($preview) {
            echo json_encode([
                'success' => true,
                'subject' => $preview['subject'],
                'body' => $preview['body']
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Şablon bulunamadı.'
            ]);
        }
        exit;
    }
}
