<?php
/**
 * Reference Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Reference.php';

class ReferenceController {
    private $referenceModel;
    
    public function __construct() {
        $this->referenceModel = new Reference();
    }
    
    /**
     * Referans listesi
     */
    public function index() {
        requireAuth();
        
        $references = $this->referenceModel->getAll();
        
        $pageTitle = 'Referanslar';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('references/index', ['references' => $references]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni referans ekleme formu
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('references.php?action=create'));
            }
            
            $logoUrl = '';
            
            // Dosya yükleme - SIFIRDAN YAZILDI
            if (isset($_FILES['logo_file']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK && !empty($_FILES['logo_file']['tmp_name'])) {
                // Klasör yolu
                $uploadDir = PUBLIC_PATH . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'references' . DIRECTORY_SEPARATOR;
                
                // Klasör yoksa oluştur
                if (!file_exists($uploadDir)) {
                    if (!mkdir($uploadDir, 0777, true)) {
                        setFlash('error', 'Klasör oluşturulamadı.');
                        redirect(adminUrl('references.php?action=create'));
                    }
                }
                
                // Dosya adı oluştur
                $originalName = $_FILES['logo_file']['name'];
                $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                $baseName = pathinfo($originalName, PATHINFO_FILENAME);
                $baseName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $baseName);
                $baseName = preg_replace('/_+/', '_', $baseName);
                $baseName = trim($baseName, '_');
                $fileName = $baseName . '_' . time() . '.' . $extension;
                $fullPath = $uploadDir . $fileName;
                
                // Dosyayı yükle
                if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $fullPath)) {
                    // Dosyanın gerçekten yüklendiğini kontrol et
                    if (file_exists($fullPath) && filesize($fullPath) > 0) {
                        $logoUrl = BASE_URL . '/assets/images/references/' . $fileName;
                    } else {
                        setFlash('error', 'Dosya yüklendi ancak doğrulanamadı.');
                        redirect(adminUrl('references.php?action=create'));
                    }
                } else {
                    setFlash('error', 'Dosya yüklenemedi. Lütfen tekrar deneyin.');
                    redirect(adminUrl('references.php?action=create'));
                }
            } elseif (!empty($_POST['logo_url'])) {
                // URL ile logo ekleme
                $logoUrl = sanitizeInput($_POST['logo_url']);
            }
            
            $data = [
                'name' => sanitizeInput($_POST['name'] ?? ''),
                'logo_url' => $logoUrl,
                'link' => sanitizeInput($_POST['link'] ?? ''),
                'sort_order' => intval($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['name'])) {
                setFlash('error', 'Firma adı gereklidir.');
                redirect(adminUrl('references.php?action=create'));
            }
            
            $this->referenceModel->create($data);
            setFlash('success', 'Referans başarıyla eklendi.');
            redirect(adminUrl('references.php'));
        }
        
        $pageTitle = 'Yeni Referans Ekle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('references/create');
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Referans düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $reference = $this->referenceModel->findById($id);
        if (!$reference) {
            setFlash('error', 'Referans bulunamadı.');
            redirect(adminUrl('references.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('references.php?action=edit&id=' . $id));
            }
            
            $logoUrl = $reference['logo_url'] ?? '';
            
            // Dosya yükleme - SIFIRDAN YAZILDI
            if (isset($_FILES['logo_file']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK && !empty($_FILES['logo_file']['tmp_name'])) {
                // Klasör yolu
                $uploadDir = PUBLIC_PATH . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'references' . DIRECTORY_SEPARATOR;
                
                // Klasör yoksa oluştur
                if (!file_exists($uploadDir)) {
                    if (!mkdir($uploadDir, 0777, true)) {
                        setFlash('error', 'Klasör oluşturulamadı.');
                        redirect(adminUrl('references.php?action=edit&id=' . $id));
                    }
                }
                
                // Eski dosyayı sil
                if (!empty($reference['logo_url']) && strpos($reference['logo_url'], '/assets/images/references/') !== false) {
                    $oldFileName = basename($reference['logo_url']);
                    $oldFilePath = $uploadDir . $oldFileName;
                    if (file_exists($oldFilePath)) {
                        @unlink($oldFilePath);
                    }
                }
                
                // Dosya adı oluştur
                $originalName = $_FILES['logo_file']['name'];
                $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                $baseName = pathinfo($originalName, PATHINFO_FILENAME);
                $baseName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $baseName);
                $baseName = preg_replace('/_+/', '_', $baseName);
                $baseName = trim($baseName, '_');
                $fileName = $baseName . '_' . time() . '.' . $extension;
                $fullPath = $uploadDir . $fileName;
                
                // Dosyayı yükle
                if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $fullPath)) {
                    // Dosyanın gerçekten yüklendiğini kontrol et
                    if (file_exists($fullPath) && filesize($fullPath) > 0) {
                        $logoUrl = BASE_URL . '/assets/images/references/' . $fileName;
                    } else {
                        setFlash('error', 'Dosya yüklendi ancak doğrulanamadı.');
                        redirect(adminUrl('references.php?action=edit&id=' . $id));
                    }
                } else {
                    setFlash('error', 'Dosya yüklenemedi. Lütfen tekrar deneyin.');
                    redirect(adminUrl('references.php?action=edit&id=' . $id));
                }
            } elseif (!empty($_POST['logo_url'])) {
                // URL ile logo ekleme
                $logoUrl = sanitizeInput($_POST['logo_url']);
            }
            
            $data = [
                'name' => sanitizeInput($_POST['name'] ?? ''),
                'logo_url' => $logoUrl,
                'link' => sanitizeInput($_POST['link'] ?? ''),
                'sort_order' => intval($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['name'])) {
                setFlash('error', 'Firma adı gereklidir.');
                redirect(adminUrl('references.php?action=edit&id=' . $id));
            }
            
            $this->referenceModel->update($id, $data);
            setFlash('success', 'Referans başarıyla güncellendi.');
            redirect(adminUrl('references.php'));
        }
        
        $pageTitle = 'Referans Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('references/edit', ['reference' => $reference]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Referans silme
     */
    public function delete($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('references.php'));
        }
        
        $this->referenceModel->delete($id);
        setFlash('success', 'Referans başarıyla silindi.');
        redirect(adminUrl('references.php'));
    }
    
    /**
     * Referans aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('references.php'));
        }
        
        $this->referenceModel->toggleActive($id);
        setFlash('success', 'Referans durumu güncellendi.');
        redirect(adminUrl('references.php'));
    }
}
