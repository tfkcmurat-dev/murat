<?php
/**
 * Auth Controller
 * Admin paneli giriş/çıkış işlemleri
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/User.php';

class AuthController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new User();
    }
    
    /**
     * Giriş sayfası
     */
    public function login() {
        // Zaten giriş yapılmışsa dashboard'a yönlendir
        if (isLoggedIn()) {
            redirect(adminUrl('dashboard.php'));
        }
        
        $error = null;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token kontrolü
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                $error = 'Güvenlik hatası. Lütfen tekrar deneyin.';
            } else {
                $username = sanitizeInput($_POST['username'] ?? '');
                $password = $_POST['password'] ?? '';
                
                if (empty($username) || empty($password)) {
                    $error = 'Kullanıcı adı ve şifre gereklidir.';
                } else {
                    $result = $this->userModel->login($username, $password);
                    
                    if ($result === true) {
                        redirect(adminUrl('dashboard.php'));
                    } elseif (is_array($result) && isset($result['error'])) {
                        switch ($result['error']) {
                            case 'too_many_attempts':
                                $error = 'Çok fazla başarısız deneme. Lütfen 15 dakika sonra tekrar deneyin.';
                                break;
                            case 'account_locked':
                                $error = 'Hesabınız geçici olarak kilitlendi. Lütfen 15 dakika sonra tekrar deneyin.';
                                break;
                            default:
                                $error = 'Bir hata oluştu.';
                        }
                    } else {
                        $error = 'Kullanıcı adı veya şifre hatalı.';
                    }
                }
            }
        }
        
        adminView('auth/login', ['error' => $error]);
    }
    
    /**
     * Çıkış işlemi
     */
    public function logout() {
        $this->userModel->logout();
        redirect(adminUrl('login.php'));
    }
    
    /**
     * Şifre değiştirme sayfası
     */
    public function changePassword() {
        requireAuth();
        
        $error = null;
        $success = null;
        $errors = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                $error = 'Güvenlik hatası. Lütfen tekrar deneyin.';
            } else {
                $currentPassword = $_POST['current_password'] ?? '';
                $newPassword = $_POST['new_password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                
                if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                    $error = 'Tüm alanları doldurun.';
                } elseif ($newPassword !== $confirmPassword) {
                    $error = 'Yeni şifreler eşleşmiyor.';
                } else {
                    $result = $this->userModel->changePassword(
                        $_SESSION['user_id'],
                        $currentPassword,
                        $newPassword
                    );
                    
                    if ($result['success']) {
                        $success = 'Şifreniz başarıyla değiştirildi.';
                    } else {
                        if (isset($result['errors'])) {
                            $errors = $result['errors'];
                        } else {
                            $error = $result['error'];
                        }
                    }
                }
            }
        }
        
        $pageTitle = 'Şifre Değiştir';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('auth/change-password', [
            'error' => $error,
            'errors' => $errors,
            'success' => $success
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
}
