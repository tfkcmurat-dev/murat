<?php
/**
 * Dashboard Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Customer.php';
require_once APP_PATH . '/models/Service.php';
require_once APP_PATH . '/models/Quote.php';

class DashboardController {
    
    public function index() {
        requireAuth();
        
        $customerModel = new Customer();
        $serviceModel = new Service();
        $quoteModel = new Quote();
        
        $stats = [
            'customers' => $customerModel->count(true),
            'services' => $serviceModel->count(true),
            'quotes_total' => $quoteModel->count(),
            'quotes_draft' => $quoteModel->count('draft'),
            'quotes_sent' => $quoteModel->count('sent'),
            'quotes_approved' => $quoteModel->count('approved'),
            'quotes_rejected' => $quoteModel->count('rejected'),
        ];
        
        // Son teklifler
        $recentQuotes = $quoteModel->getAll();
        $recentQuotes = array_slice($recentQuotes, 0, 5);
        
        $pageTitle = 'Dashboard';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('dashboard/index', [
            'stats' => $stats,
            'recentQuotes' => $recentQuotes
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
}
