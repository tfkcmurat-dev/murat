<?php
/**
 * About Page Content Controller
 * Hakkımızda sayfası içeriklerini yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class AboutPageController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('about-page.php'));
            }
            
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'Hakkımızda sayfası içerikleri başarıyla kaydedildi.');
            redirect(adminUrl('about-page.php'));
        }
        
        $settings = $this->getAboutSettings();
        
        $pageTitle = 'Hakkımızda Sayfası Yönetimi';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('about-page/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    private function getAboutSettings() {
        return [
            // Hero Section
            'about_hero_badge' => $this->themeModel->get('about_hero_badge') ?? 'Hakkımızda',
            'about_hero_title' => $this->themeModel->get('about_hero_title') ?? 'Teknoloji Tutkunuzu Keşfedin',
            'about_hero_highlight' => $this->themeModel->get('about_hero_highlight') ?? 'Hikayemiz',
            'about_hero_subtitle' => $this->themeModel->get('about_hero_subtitle') ?? '10+ yıllık tecrübemizle teknoloji dünyasında güvenilir çözüm ortağınız olmaya devam ediyoruz.',
            
            // Hero Stats
            'about_stat1_number' => $this->themeModel->get('about_stat1_number') ?? '2014',
            'about_stat1_label' => $this->themeModel->get('about_stat1_label') ?? 'Kuruluş',
            'about_stat2_number' => $this->themeModel->get('about_stat2_number') ?? '10+',
            'about_stat2_label' => $this->themeModel->get('about_stat2_label') ?? 'Yıl Tecrübe',
            'about_stat3_number' => $this->themeModel->get('about_stat3_number') ?? '500+',
            'about_stat3_label' => $this->themeModel->get('about_stat3_label') ?? 'Mutlu Müşteri',
            
            // Story Section
            'about_story_badge' => $this->themeModel->get('about_story_badge') ?? 'Hikayemiz',
            'about_story_title' => $this->themeModel->get('about_story_title') ?? 'Tutkuyla Başladık, Güvenle Büyüdük',
            'about_story_content' => $this->themeModel->get('about_story_content') ?? 'Bilişim Servis, 2014 yılında küçük bir teknoloji atölyesi olarak kuruldu. Teknolojiye olan tutkumuz ve müşteri memnuniyeti odaklı yaklaşımımız sayesinde bugün sektörün güvenilen markalarından biri haline geldik.',
            
            // Timeline
            'about_timeline1_year' => $this->themeModel->get('about_timeline1_year') ?? '2014',
            'about_timeline1_title' => $this->themeModel->get('about_timeline1_title') ?? 'Kuruluş',
            'about_timeline1_desc' => $this->themeModel->get('about_timeline1_desc') ?? 'Küçük bir atölye olarak yolculuğumuza başladık.',
            'about_timeline2_year' => $this->themeModel->get('about_timeline2_year') ?? '2017',
            'about_timeline2_title' => $this->themeModel->get('about_timeline2_title') ?? 'Büyüme',
            'about_timeline2_desc' => $this->themeModel->get('about_timeline2_desc') ?? 'Ekibimizi genişleterek daha fazla müşteriye ulaştık.',
            'about_timeline3_year' => $this->themeModel->get('about_timeline3_year') ?? '2020',
            'about_timeline3_title' => $this->themeModel->get('about_timeline3_title') ?? 'Kurumsal',
            'about_timeline3_desc' => $this->themeModel->get('about_timeline3_desc') ?? 'Kurumsal müşterilere hizmet vermeye başladık.',
            'about_timeline4_year' => $this->themeModel->get('about_timeline4_year') ?? '2024',
            'about_timeline4_title' => $this->themeModel->get('about_timeline4_title') ?? 'Bugün',
            'about_timeline4_desc' => $this->themeModel->get('about_timeline4_desc') ?? 'Sektörün güvenilen markalarından biri olduk.',
            
            // Stats Section
            'about_stats_stat1_number' => $this->themeModel->get('about_stats_stat1_number') ?? '10',
            'about_stats_stat1_suffix' => $this->themeModel->get('about_stats_stat1_suffix') ?? '+',
            'about_stats_stat1_label' => $this->themeModel->get('about_stats_stat1_label') ?? 'Yıllık Deneyim',
            'about_stats_stat2_number' => $this->themeModel->get('about_stats_stat2_number') ?? '500',
            'about_stats_stat2_suffix' => $this->themeModel->get('about_stats_stat2_suffix') ?? '+',
            'about_stats_stat2_label' => $this->themeModel->get('about_stats_stat2_label') ?? 'Mutlu Müşteri',
            'about_stats_stat3_number' => $this->themeModel->get('about_stats_stat3_number') ?? '1000',
            'about_stats_stat3_suffix' => $this->themeModel->get('about_stats_stat3_suffix') ?? '+',
            'about_stats_stat3_label' => $this->themeModel->get('about_stats_stat3_label') ?? 'Tamamlanan Proje',
            'about_stats_stat4_number' => $this->themeModel->get('about_stats_stat4_number') ?? '98',
            'about_stats_stat4_suffix' => $this->themeModel->get('about_stats_stat4_suffix') ?? '%',
            'about_stats_stat4_label' => $this->themeModel->get('about_stats_stat4_label') ?? 'Memnuniyet Oranı',
            
            // Values Section
            'about_values_badge' => $this->themeModel->get('about_values_badge') ?? 'Değerlerimiz',
            'about_values_title' => $this->themeModel->get('about_values_title') ?? 'Bizi Farklı Kılan Değerler',
            'about_value1_title' => $this->themeModel->get('about_value1_title') ?? 'Güvenilirlik',
            'about_value1_desc' => $this->themeModel->get('about_value1_desc') ?? 'Müşterilerimize her zaman dürüst ve şeffaf hizmet sunuyoruz.',
            'about_value2_title' => $this->themeModel->get('about_value2_title') ?? 'Kalite',
            'about_value2_desc' => $this->themeModel->get('about_value2_desc') ?? 'En yüksek kalite standartlarında hizmet veriyoruz.',
            'about_value3_title' => $this->themeModel->get('about_value3_title') ?? 'Hız',
            'about_value3_desc' => $this->themeModel->get('about_value3_desc') ?? 'Zamanın değerini biliyoruz, hızlı çözümler sunuyoruz.',
            'about_value4_title' => $this->themeModel->get('about_value4_title') ?? 'Destek',
            'about_value4_desc' => $this->themeModel->get('about_value4_desc') ?? '7/24 müşteri desteği ile yanınızdayız.',
            
            // CTA Section
            'about_cta_title' => $this->themeModel->get('about_cta_title') ?? 'Bizimle Çalışmak İster Misiniz?',
            'about_cta_subtitle' => $this->themeModel->get('about_cta_subtitle') ?? 'Profesyonel teknik servis hizmetlerimizden yararlanmak için hemen iletişime geçin.',
            'about_cta_button' => $this->themeModel->get('about_cta_button') ?? 'İletişime Geçin',
        ];
    }
}
