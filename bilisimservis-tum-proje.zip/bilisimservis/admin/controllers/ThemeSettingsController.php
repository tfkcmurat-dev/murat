<?php
/**
 * Theme Settings Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class ThemeSettingsController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    /**
     * Tema ayarları listesi ve düzenleme
     */
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token kontrolü
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('theme-settings.php'));
            }
            
            // Favicon dosya yükleme kontrolü
            if (isset($_FILES['favicon_file']) && $_FILES['favicon_file']['error'] === UPLOAD_ERR_OK) {
                // Favicon için özel validasyon (ICO dosyaları dahil)
                $isValidFavicon = false;
                if ($_FILES['favicon_file']['size'] <= MAX_UPLOAD_SIZE) {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mimeType = finfo_file($finfo, $_FILES['favicon_file']['tmp_name']);
                    finfo_close($finfo);
                    
                    $allowedFaviconTypes = array_merge(ALLOWED_IMAGE_TYPES, ['image/x-icon', 'image/vnd.microsoft.icon', 'image/x-ico', 'application/octet-stream']);
                    $extension = strtolower(pathinfo($_FILES['favicon_file']['name'], PATHINFO_EXTENSION));
                    
                    if (in_array($mimeType, $allowedFaviconTypes) || $extension === 'ico') {
                        $isValidFavicon = true;
                    }
                }
                
                if ($isValidFavicon) {
                    $uploadDir = PUBLIC_PATH . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR;
                    
                    // Klasör yoksa oluştur
                    if (!is_dir($uploadDir)) {
                        if (!mkdir($uploadDir, 0755, true)) {
                            setFlash('error', 'Klasör oluşturulamadı: ' . $uploadDir);
                            redirect(adminUrl('theme-settings.php'));
                        }
                    }
                    
                    // Klasör yazılabilir mi kontrol et
                    if (!is_writable($uploadDir)) {
                        setFlash('error', 'Klasör yazılabilir değil. Lütfen izinleri kontrol edin: ' . $uploadDir);
                        redirect(adminUrl('theme-settings.php'));
                    }
                    
                    // Eski favicon'u sil (varsa)
                    $existingFavicon = $this->themeModel->get('favicon');
                    if (!empty($existingFavicon)) {
                        $oldFilePath = PUBLIC_PATH . str_replace(BASE_URL, '', parse_url($existingFavicon, PHP_URL_PATH));
                        if (file_exists($oldFilePath)) {
                            @unlink($oldFilePath);
                        }
                    }
                    
                    // Dosya uzantısını kontrol et ve uygun şekilde kaydet
                    $extension = strtolower(pathinfo($_FILES['favicon_file']['name'], PATHINFO_EXTENSION));
                    $fileName = 'favicon.' . ($extension === 'ico' ? 'ico' : $extension);
                    $uploadPath = $uploadDir . $fileName;
                    
                    // Eğer favicon dosyası varsa önce sil
                    $existingFiles = ['favicon.ico', 'favicon.png', 'favicon.jpg', 'favicon.jpeg', 'favicon.gif', 'favicon.webp'];
                    foreach ($existingFiles as $existingFile) {
                        $existingPath = $uploadDir . $existingFile;
                        if (file_exists($existingPath) && $existingFile !== $fileName) {
                            @unlink($existingPath);
                        }
                    }
                    
                    if (move_uploaded_file($_FILES['favicon_file']['tmp_name'], $uploadPath)) {
                        $faviconUrl = BASE_URL . '/assets/images/' . $fileName;
                        $this->themeModel->save('favicon', $faviconUrl, 'text', 'general', 'Favicon');
                    } else {
                        $errorMsg = 'Favicon yüklenirken bir hata oluştu. ';
                        $errorMsg .= 'Kaynak: ' . $_FILES['favicon_file']['tmp_name'] . ' ';
                        $errorMsg .= 'Hedef: ' . $uploadPath;
                        setFlash('error', $errorMsg);
                        redirect(adminUrl('theme-settings.php'));
                    }
                } else {
                    $errorCode = $_FILES['favicon_file']['error'] ?? 'Bilinmeyen';
                    $errorMsg = 'Geçersiz favicon formatı veya dosya boyutu çok büyük. ';
                    $errorMsg .= 'Hata kodu: ' . $errorCode;
                    setFlash('error', $errorMsg);
                    redirect(adminUrl('theme-settings.php'));
                }
            }
            
            // Ayarları kaydet
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'Ayarlar başarıyla kaydedildi.');
            redirect(adminUrl('theme-settings.php'));
        }
        
        // Gruplara göre ayarları getir
        $groups = [
            'general' => 'Genel Ayarlar',
            'homepage' => 'Anasayfa',
            'contact' => 'İletişim',
            'footer' => 'Footer',
            'seo' => 'SEO ve Schema',
            'code' => 'Code Injection'
        ];
        
        $settings = [];
        foreach ($groups as $groupKey => $groupName) {
            $settings[$groupKey] = $this->themeModel->getByGroup($groupKey);
        }
        
        $pageTitle = 'Tema Ayarları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('theme-settings/index', [
            'groups' => $groups,
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
}
