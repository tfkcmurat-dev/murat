<?php
/**
 * Quote Note Template Controller
 * Teklif not şablonlarını yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/QuoteNoteTemplate.php';

class QuoteNoteTemplateController {
    private $templateModel;
    
    public function __construct() {
        $this->templateModel = new QuoteNoteTemplate();
    }
    
    /**
     * Şablon listesi
     */
    public function index() {
        requireAuth();
        
        $templates = $this->templateModel->getAll();
        
        $pageTitle = 'Teklif Not Şablonları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quote-note-templates/index', [
            'templates' => $templates
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni şablon oluştur
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('quote-note-templates.php?action=create'));
            }
            
            $data = [
                'title' => sanitizeInput($_POST['title'] ?? ''),
                'content' => sanitizeInput($_POST['content'] ?? ''),
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
                'sort_order' => (int) ($_POST['sort_order'] ?? 0)
            ];
            
            if (empty($data['title']) || empty($data['content'])) {
                setFlash('error', 'Başlık ve içerik zorunludur.');
                redirect(adminUrl('quote-note-templates.php?action=create'));
            }
            
            if ($this->templateModel->create($data)) {
                setFlash('success', 'Şablon başarıyla oluşturuldu.');
                redirect(adminUrl('quote-note-templates.php'));
            } else {
                setFlash('error', 'Şablon oluşturulurken hata oluştu.');
                redirect(adminUrl('quote-note-templates.php?action=create'));
            }
        }
        
        $pageTitle = 'Yeni Not Şablonu';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quote-note-templates/form', [
            'template' => null
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Şablon düzenle
     */
    public function edit($id) {
        requireAuth();
        
        $template = $this->templateModel->findById($id);
        
        if (!$template) {
            setFlash('error', 'Şablon bulunamadı.');
            redirect(adminUrl('quote-note-templates.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('quote-note-templates.php?action=edit&id=' . $id));
            }
            
            $data = [
                'title' => sanitizeInput($_POST['title'] ?? ''),
                'content' => sanitizeInput($_POST['content'] ?? ''),
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
                'sort_order' => (int) ($_POST['sort_order'] ?? 0)
            ];
            
            if (empty($data['title']) || empty($data['content'])) {
                setFlash('error', 'Başlık ve içerik zorunludur.');
                redirect(adminUrl('quote-note-templates.php?action=edit&id=' . $id));
            }
            
            if ($this->templateModel->update($id, $data)) {
                setFlash('success', 'Şablon başarıyla güncellendi.');
                redirect(adminUrl('quote-note-templates.php'));
            } else {
                setFlash('error', 'Şablon güncellenirken hata oluştu.');
                redirect(adminUrl('quote-note-templates.php?action=edit&id=' . $id));
            }
        }
        
        $pageTitle = 'Şablon Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('quote-note-templates/form', [
            'template' => $template
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Şablon sil
     */
    public function delete($id) {
        requireAuth();
        
        if ($this->templateModel->delete($id)) {
            setFlash('success', 'Şablon silindi.');
        } else {
            setFlash('error', 'Şablon silinirken hata oluştu.');
        }
    }
    
    /**
     * Aktif/Pasif toggle
     */
    public function toggle($id) {
        requireAuth();
        
        if ($this->templateModel->toggleStatus($id)) {
            setFlash('success', 'Şablon durumu güncellendi.');
        } else {
            setFlash('error', 'Durum güncellenirken hata oluştu.');
        }
    }
    
    /**
     * Şablon içeriğini getir (AJAX)
     */
    public function get($id) {
        requireAuth();
        
        header('Content-Type: application/json');
        
        $template = $this->templateModel->findById($id);
        
        if ($template) {
            echo json_encode([
                'success' => true,
                'template' => $template
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Şablon bulunamadı.'
            ]);
        }
        exit;
    }
}
