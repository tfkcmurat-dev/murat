<?php
/**
 * Services Page Content Controller
 * Hizmetler sayfası içeriklerini yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class ServicesPageController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('services-page.php'));
            }
            
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'Hizmetler sayfası içerikleri başarıyla kaydedildi.');
            redirect(adminUrl('services-page.php'));
        }
        
        $settings = $this->getServicesSettings();
        
        $pageTitle = 'Hizmetler Sayfası Yönetimi';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('services-page/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    private function getServicesSettings() {
        return [
            // Hero Section
            'svc_hero_badge' => $this->themeModel->get('svc_hero_badge') ?? 'Profesyonel Teknik Servis',
            'svc_hero_title_line1' => $this->themeModel->get('svc_hero_title_line1') ?? 'Tüm Teknoloji',
            'svc_hero_title_highlight' => $this->themeModel->get('svc_hero_title_highlight') ?? 'HİZMETLERİMİZ',
            'svc_hero_title_line3' => $this->themeModel->get('svc_hero_title_line3') ?? 'Tek Çatı Altında',
            'svc_hero_subtitle' => $this->themeModel->get('svc_hero_subtitle') ?? 'Bilgisayar, telefon, tablet ve yazıcı tamirinden yazılım kurulumuna kadar tüm teknik servis ihtiyaçlarınız için profesyonel çözümler sunuyoruz.',
            
            // Hero Stats
            'svc_stat1_label' => $this->themeModel->get('svc_stat1_label') ?? 'Hizmet',
            'svc_stat2_number' => $this->themeModel->get('svc_stat2_number') ?? '%100',
            'svc_stat2_label' => $this->themeModel->get('svc_stat2_label') ?? 'Memnuniyet',
            'svc_stat3_number' => $this->themeModel->get('svc_stat3_number') ?? '24/7',
            'svc_stat3_label' => $this->themeModel->get('svc_stat3_label') ?? 'Destek',
            
            // Filter Section
            'svc_filter_label' => $this->themeModel->get('svc_filter_label') ?? 'Kategoriler:',
            'svc_filter_all' => $this->themeModel->get('svc_filter_all') ?? 'Tümü',
            'svc_filter_computer' => $this->themeModel->get('svc_filter_computer') ?? 'Bilgisayar',
            'svc_filter_mobile' => $this->themeModel->get('svc_filter_mobile') ?? 'Telefon & Tablet',
            'svc_filter_printer' => $this->themeModel->get('svc_filter_printer') ?? 'Yazıcı',
            'svc_filter_software' => $this->themeModel->get('svc_filter_software') ?? 'Yazılım',
            
            // Process Section
            'svc_process_badge' => $this->themeModel->get('svc_process_badge') ?? 'Süreç',
            'svc_process_title' => $this->themeModel->get('svc_process_title') ?? 'Nasıl Çalışıyoruz?',
            'svc_process_subtitle' => $this->themeModel->get('svc_process_subtitle') ?? 'Basit ve hızlı süreçlerimizle size en iyi hizmeti sunuyoruz.',
            'svc_process1_title' => $this->themeModel->get('svc_process1_title') ?? 'İletişime Geçin',
            'svc_process1_desc' => $this->themeModel->get('svc_process1_desc') ?? 'Bize ulaşın ve sorununuzu anlatın. Ücretsiz teşhis için randevu alın.',
            'svc_process2_title' => $this->themeModel->get('svc_process2_title') ?? 'Teşhis',
            'svc_process2_desc' => $this->themeModel->get('svc_process2_desc') ?? 'Uzman ekibimiz cihazınızı inceler ve sorunu tespit eder.',
            'svc_process3_title' => $this->themeModel->get('svc_process3_title') ?? 'Onay & Tamir',
            'svc_process3_desc' => $this->themeModel->get('svc_process3_desc') ?? 'Onayınızın ardından profesyonel tamir işlemi başlar.',
            'svc_process4_title' => $this->themeModel->get('svc_process4_title') ?? 'Teslimat',
            'svc_process4_desc' => $this->themeModel->get('svc_process4_desc') ?? 'Tamir tamamlandıktan sonra cihazınız size teslim edilir.',
            
            // CTA Section
            'svc_cta_title' => $this->themeModel->get('svc_cta_title') ?? 'Cihazınızla İlgili Sorun mu Yaşıyorsunuz?',
            'svc_cta_subtitle' => $this->themeModel->get('svc_cta_subtitle') ?? 'Hemen bizimle iletişime geçin, ücretsiz teşhis ve uygun fiyatlı çözümler sunalım.',
            'svc_cta_button1' => $this->themeModel->get('svc_cta_button1') ?? 'Ücretsiz Teşhis İste',
            'svc_cta_button2' => $this->themeModel->get('svc_cta_button2') ?? 'Hemen Ara',
        ];
    }
}
