<?php
/**
 * Mail Settings Controller
 * SMTP yapılandırma ayarları
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';
require_once APP_PATH . '/services/MailService.php';

class MailSettingsController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    public function index() {
        requireAuth();
        
        $action = $_GET['action'] ?? '';
        
        // Test mail gönderimi
        if ($action === 'test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->sendTestMail();
            return;
        }
        
        // Bağlantı testi
        if ($action === 'test-connection' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->testConnection();
            return;
        }
        
        // Ayarları kaydet
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('mail-settings.php'));
            }
            
            $settings = $_POST['settings'] ?? [];
            
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value, 'text', 'mail');
            }
            
            setFlash('success', 'Mail ayarları başarıyla kaydedildi.');
            redirect(adminUrl('mail-settings.php'));
        }
        
        $settings = $this->getMailSettings();
        
        $pageTitle = 'SMTP Ayarları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('mail-settings/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    private function getMailSettings() {
        return [
            'smtp_host' => $this->themeModel->get('smtp_host') ?? 'smtp.gmail.com',
            'smtp_port' => $this->themeModel->get('smtp_port') ?? '587',
            'smtp_username' => $this->themeModel->get('smtp_username') ?? '',
            'smtp_password' => $this->themeModel->get('smtp_password') ?? '',
            'smtp_encryption' => $this->themeModel->get('smtp_encryption') ?? 'tls',
            'smtp_from_email' => $this->themeModel->get('smtp_from_email') ?? '',
            'smtp_from_name' => $this->themeModel->get('smtp_from_name') ?? '',
            'mail_enabled' => $this->themeModel->get('mail_enabled') ?? '0'
        ];
    }
    
    private function sendTestMail() {
        header('Content-Type: application/json');
        
        if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Güvenlik hatası.']);
            exit;
        }
        
        $testEmail = sanitizeInput($_POST['test_email'] ?? '');
        
        if (!validateEmail($testEmail)) {
            echo json_encode(['success' => false, 'message' => 'Geçerli bir e-posta adresi girin.']);
            exit;
        }
        
        $mailService = new MailService();
        $result = $mailService->sendTestEmail($testEmail);
        
        echo json_encode($result);
        exit;
    }
    
    private function testConnection() {
        header('Content-Type: application/json');
        
        if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Güvenlik hatası.']);
            exit;
        }
        
        $mailService = new MailService();
        $result = $mailService->testConnection();
        
        echo json_encode($result);
        exit;
    }
}
