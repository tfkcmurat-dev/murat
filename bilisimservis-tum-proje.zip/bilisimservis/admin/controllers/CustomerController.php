<?php
/**
 * Customer Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Customer.php';

class CustomerController {
    private $customerModel;
    
    public function __construct() {
        $this->customerModel = new Customer();
    }
    
    /**
     * Müşteri listesi
     */
    public function index() {
        requireAuth();
        
        $customers = $this->customerModel->getAll();
        
        $pageTitle = 'Müşteriler';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('customers/index', ['customers' => $customers]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni müşteri ekleme formu
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('customers.php?action=create'));
            }
            
            $data = [
                'company_name' => sanitizeInput($_POST['company_name'] ?? ''),
                'province' => sanitizeInput($_POST['province'] ?? ''),
                'district' => sanitizeInput($_POST['district'] ?? ''),
                'address' => sanitizeInput($_POST['address'] ?? ''),
                'phone' => sanitizeInput($_POST['phone'] ?? ''),
                'email' => sanitizeInput($_POST['email'] ?? ''),
                'tax_number' => sanitizeInput($_POST['tax_number'] ?? ''),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['company_name'])) {
                setFlash('error', 'Firma adı gereklidir.');
                redirect(adminUrl('customers.php?action=create'));
            }
            
            $this->customerModel->create($data);
            setFlash('success', 'Müşteri başarıyla eklendi.');
            redirect(adminUrl('customers.php'));
        }
        
        $pageTitle = 'Yeni Müşteri Ekle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('customers/create');
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Müşteri düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $customer = $this->customerModel->findById($id);
        if (!$customer) {
            setFlash('error', 'Müşteri bulunamadı.');
            redirect(adminUrl('customers.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('customers.php?action=edit&id=' . $id));
            }
            
            $data = [
                'company_name' => sanitizeInput($_POST['company_name'] ?? ''),
                'province' => sanitizeInput($_POST['province'] ?? ''),
                'district' => sanitizeInput($_POST['district'] ?? ''),
                'address' => sanitizeInput($_POST['address'] ?? ''),
                'phone' => sanitizeInput($_POST['phone'] ?? ''),
                'email' => sanitizeInput($_POST['email'] ?? ''),
                'tax_number' => sanitizeInput($_POST['tax_number'] ?? ''),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['company_name'])) {
                setFlash('error', 'Firma adı gereklidir.');
                redirect(adminUrl('customers.php?action=edit&id=' . $id));
            }
            
            $this->customerModel->update($id, $data);
            setFlash('success', 'Müşteri başarıyla güncellendi.');
            redirect(adminUrl('customers.php'));
        }
        
        $pageTitle = 'Müşteri Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('customers/edit', ['customer' => $customer]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Müşteri silme
     */
    public function delete($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('customers.php'));
        }
        
        $this->customerModel->delete($id);
        setFlash('success', 'Müşteri başarıyla silindi.');
        redirect(adminUrl('customers.php'));
    }
}
