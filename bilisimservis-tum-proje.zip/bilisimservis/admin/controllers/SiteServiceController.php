<?php
/**
 * Site Service Controller
 * Sitede gösterilecek hizmetler için
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/SiteService.php';

class SiteServiceController {
    private $siteServiceModel;
    
    public function __construct() {
        $this->siteServiceModel = new SiteService();
    }
    
    /**
     * Site hizmet listesi
     */
    public function index() {
        requireAuth();
        
        $services = $this->siteServiceModel->getAll();
        
        $pageTitle = 'Site Hizmetleri';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('site-services/index', ['services' => $services]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni site hizmeti ekleme formu
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('site-services.php?action=create'));
            }
            
            $name = sanitizeInput($_POST['name'] ?? '');
            if (empty($name)) {
                setFlash('error', 'Hizmet adı gereklidir.');
                redirect(adminUrl('site-services.php?action=create'));
            }
            
            // Slug oluştur
            $slug = !empty($_POST['slug']) ? sanitizeInput($_POST['slug']) : $this->siteServiceModel->generateSlug($name);
            
            // Features array'i JSON'a çevir
            $features = [];
            if (!empty($_POST['features'])) {
                $featuresArray = explode("\n", $_POST['features']);
                $features = array_map('trim', array_filter($featuresArray));
            }
            
            $data = [
                'name' => $name,
                'slug' => $slug,
                'subtitle' => sanitizeInput($_POST['subtitle'] ?? ''),
                'description' => sanitizeInput($_POST['description'] ?? ''),
                'icon' => sanitizeInput($_POST['icon'] ?? 'settings'),
                'image' => sanitizeInput($_POST['image'] ?? ''),
                'features' => !empty($features) ? json_encode($features, JSON_UNESCAPED_UNICODE) : null,
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            $this->siteServiceModel->create($data);
            setFlash('success', 'Site hizmeti başarıyla eklendi.');
            redirect(adminUrl('site-services.php'));
        }
        
        $pageTitle = 'Yeni Site Hizmeti Ekle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('site-services/create');
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Site hizmeti düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $service = $this->siteServiceModel->findById($id);
        if (!$service) {
            setFlash('error', 'Site hizmeti bulunamadı.');
            redirect(adminUrl('site-services.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('site-services.php?action=edit&id=' . $id));
            }
            
            $name = sanitizeInput($_POST['name'] ?? '');
            if (empty($name)) {
                setFlash('error', 'Hizmet adı gereklidir.');
                redirect(adminUrl('site-services.php?action=edit&id=' . $id));
            }
            
            // Slug oluştur veya mevcut slug'ı kullan
            $slug = !empty($_POST['slug']) ? sanitizeInput($_POST['slug']) : $this->siteServiceModel->generateSlug($name);
            
            // Features array'i JSON'a çevir
            $features = [];
            if (!empty($_POST['features'])) {
                $featuresArray = explode("\n", $_POST['features']);
                $features = array_map('trim', array_filter($featuresArray));
            }
            
            // FAQ array'i JSON'a çevir (question|answer formatı)
            $faq = [];
            if (!empty($_POST['faq'])) {
                $faqLines = explode("\n", $_POST['faq']);
                foreach ($faqLines as $line) {
                    $line = trim($line);
                    if (empty($line)) continue;
                    
                    // Format: Soru | Cevap veya Soru: Cevap
                    if (strpos($line, '|') !== false) {
                        list($question, $answer) = explode('|', $line, 2);
                    } elseif (strpos($line, ':') !== false) {
                        list($question, $answer) = explode(':', $line, 2);
                    } else {
                        continue; // Geçersiz format
                    }
                    
                    $question = trim($question);
                    $answer = trim($answer);
                    
                    if (!empty($question) && !empty($answer)) {
                        $faq[] = [
                            'question' => $question,
                            'answer' => $answer
                        ];
                    }
                }
            }
            
            $data = [
                'name' => $name,
                'slug' => $slug,
                'subtitle' => sanitizeInput($_POST['subtitle'] ?? ''),
                'description' => sanitizeInput($_POST['description'] ?? ''),
                'icon' => sanitizeInput($_POST['icon'] ?? 'settings'),
                'image' => sanitizeInput($_POST['image'] ?? ''),
                'features' => !empty($features) ? json_encode($features, JSON_UNESCAPED_UNICODE) : null,
                'faq' => !empty($faq) ? json_encode($faq, JSON_UNESCAPED_UNICODE) : null,
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            $this->siteServiceModel->update($id, $data);
            setFlash('success', 'Site hizmeti başarıyla güncellendi.');
            redirect(adminUrl('site-services.php'));
        }
        
        $pageTitle = 'Site Hizmeti Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('site-services/edit', ['service' => $service]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Site hizmeti silme
     */
    public function delete($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('site-services.php'));
        }
        
        $this->siteServiceModel->delete($id);
        setFlash('success', 'Site hizmeti başarıyla silindi.');
        redirect(adminUrl('site-services.php'));
    }
    
    /**
     * Site hizmeti aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('site-services.php'));
        }
        
        $this->siteServiceModel->toggleActive($id);
        setFlash('success', 'Site hizmeti durumu güncellendi.');
        redirect(adminUrl('site-services.php'));
    }
}
