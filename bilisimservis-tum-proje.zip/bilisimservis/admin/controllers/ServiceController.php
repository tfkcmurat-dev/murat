<?php
/**
 * Service Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Service.php';

class ServiceController {
    private $serviceModel;
    
    public function __construct() {
        $this->serviceModel = new Service();
    }
    
    /**
     * Hizmet listesi
     */
    public function index() {
        requireAuth();
        
        $services = $this->serviceModel->getAll();
        
        $pageTitle = 'Hizmetler';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('services/index', ['services' => $services]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni hizmet ekleme formu
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('services.php?action=create'));
            }
            
            $data = [
                'name' => sanitizeInput($_POST['name'] ?? ''),
                'description' => sanitizeInput($_POST['description'] ?? ''),
                'default_price' => floatval($_POST['default_price'] ?? 0),
                'tax_rate' => floatval($_POST['tax_rate'] ?? 18),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['name'])) {
                setFlash('error', 'Hizmet adı gereklidir.');
                redirect(adminUrl('services.php?action=create'));
            }
            
            $this->serviceModel->create($data);
            setFlash('success', 'Hizmet başarıyla eklendi.');
            redirect(adminUrl('services.php'));
        }
        
        $pageTitle = 'Yeni Hizmet Ekle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('services/create');
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Hizmet düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $service = $this->serviceModel->findById($id);
        if (!$service) {
            setFlash('error', 'Hizmet bulunamadı.');
            redirect(adminUrl('services.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('services.php?action=edit&id=' . $id));
            }
            
            $data = [
                'name' => sanitizeInput($_POST['name'] ?? ''),
                'description' => sanitizeInput($_POST['description'] ?? ''),
                'default_price' => floatval($_POST['default_price'] ?? 0),
                'tax_rate' => floatval($_POST['tax_rate'] ?? 18),
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            if (empty($data['name'])) {
                setFlash('error', 'Hizmet adı gereklidir.');
                redirect(adminUrl('services.php?action=edit&id=' . $id));
            }
            
            $this->serviceModel->update($id, $data);
            setFlash('success', 'Hizmet başarıyla güncellendi.');
            redirect(adminUrl('services.php'));
        }
        
        $pageTitle = 'Hizmet Düzenle';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('services/edit', ['service' => $service]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Hizmet silme
     */
    public function delete($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('services.php'));
        }
        
        $this->serviceModel->delete($id);
        setFlash('success', 'Hizmet başarıyla silindi.');
        redirect(adminUrl('services.php'));
    }
    
    /**
     * Hizmet aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        requireAuth();
        
        if (!validateCsrfToken($_GET['token'] ?? '')) {
            setFlash('error', 'Güvenlik hatası.');
            redirect(adminUrl('services.php'));
        }
        
        $this->serviceModel->toggleActive($id);
        setFlash('success', 'Hizmet durumu güncellendi.');
        redirect(adminUrl('services.php'));
    }
}
