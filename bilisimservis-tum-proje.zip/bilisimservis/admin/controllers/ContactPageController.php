<?php
/**
 * Contact Page Content Controller
 * İletişim sayfası içeriklerini yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class ContactPageController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('contact-page.php'));
            }
            
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'İletişim sayfası içerikleri başarıyla kaydedildi.');
            redirect(adminUrl('contact-page.php'));
        }
        
        $settings = $this->getContactSettings();
        
        $pageTitle = 'İletişim Sayfası Yönetimi';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('contact-page/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    private function getContactSettings() {
        return [
            // Hero Section
            'contact_hero_badge' => $this->themeModel->get('contact_hero_badge') ?? 'İletişim',
            'contact_hero_title' => $this->themeModel->get('contact_hero_title') ?? 'Bizimle İletişime Geçin',
            'contact_hero_highlight' => $this->themeModel->get('contact_hero_highlight') ?? 'İLETİŞİM',
            'contact_hero_subtitle' => $this->themeModel->get('contact_hero_subtitle') ?? 'Sorularınız, önerileriniz veya teknik destek talepleriniz için bize ulaşın. En kısa sürede size dönüş yapacağız.',
            
            // Contact Info
            'contact_phone_label' => $this->themeModel->get('contact_phone_label') ?? 'TELEFON',
            'contact_email_label' => $this->themeModel->get('contact_email_label') ?? 'E-POSTA',
            'contact_hours_label' => $this->themeModel->get('contact_hours_label') ?? 'ÇALIŞMA SAATLERİ',
            'contact_hours_value' => $this->themeModel->get('contact_hours_value') ?? 'Pazartesi - Cuma: 09:00 - 18:00',
            
            // Form Section
            'contact_form_title' => $this->themeModel->get('contact_form_title') ?? 'Mesaj Gönderin',
            'contact_form_subtitle' => $this->themeModel->get('contact_form_subtitle') ?? 'Formu doldurun, size en kısa sürede dönüş yapalım.',
            'contact_form_name_label' => $this->themeModel->get('contact_form_name_label') ?? 'Adınız Soyadınız',
            'contact_form_name_placeholder' => $this->themeModel->get('contact_form_name_placeholder') ?? 'Adınızı girin',
            'contact_form_email_label' => $this->themeModel->get('contact_form_email_label') ?? 'E-posta Adresiniz',
            'contact_form_email_placeholder' => $this->themeModel->get('contact_form_email_placeholder') ?? 'E-posta adresinizi girin',
            'contact_form_subject_label' => $this->themeModel->get('contact_form_subject_label') ?? 'Konu',
            'contact_form_message_label' => $this->themeModel->get('contact_form_message_label') ?? 'Mesajınız',
            'contact_form_message_placeholder' => $this->themeModel->get('contact_form_message_placeholder') ?? 'Mesajınızı yazın...',
            'contact_form_button' => $this->themeModel->get('contact_form_button') ?? 'Mesajı Gönder',
            
            // Subject Options
            'contact_subject_general' => $this->themeModel->get('contact_subject_general') ?? 'Genel Bilgi',
            'contact_subject_support' => $this->themeModel->get('contact_subject_support') ?? 'Teknik Destek',
            'contact_subject_quote' => $this->themeModel->get('contact_subject_quote') ?? 'Fiyat Teklifi',
            'contact_subject_complaint' => $this->themeModel->get('contact_subject_complaint') ?? 'Şikayet',
            'contact_subject_other' => $this->themeModel->get('contact_subject_other') ?? 'Diğer',
            
            // Map Section
            'contact_map_badge' => $this->themeModel->get('contact_map_badge') ?? 'Konum',
            'contact_map_title' => $this->themeModel->get('contact_map_title') ?? 'Bizi Ziyaret Edin',
            'contact_map_address_title' => $this->themeModel->get('contact_map_address_title') ?? 'Adresimiz',
            
            // Social Section
            'contact_social_title' => $this->themeModel->get('contact_social_title') ?? 'Sosyal Medyada Bizi Takip Edin',
            
            // Social Media Links
            'social_facebook_url' => $this->themeModel->get('social_facebook_url') ?? '',
            'social_instagram_url' => $this->themeModel->get('social_instagram_url') ?? '',
            'social_twitter_url' => $this->themeModel->get('social_twitter_url') ?? '',
            'social_whatsapp_url' => $this->themeModel->get('social_whatsapp_url') ?? '',
            'social_youtube_url' => $this->themeModel->get('social_youtube_url') ?? '',
            'social_linkedin_url' => $this->themeModel->get('social_linkedin_url') ?? '',
        ];
    }
}
