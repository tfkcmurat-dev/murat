<?php
/**
 * Homepage Content Controller
 * Anasayfa içeriklerini yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class HomepageController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    /**
     * Anasayfa içerik yönetimi
     */
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token kontrolü
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('homepage.php'));
            }
            
            // Ayarları kaydet
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'Anasayfa içerikleri başarıyla kaydedildi.');
            redirect(adminUrl('homepage.php'));
        }
        
        // Anasayfa ayarlarını getir
        $settings = $this->getHomepageSettings();
        
        $pageTitle = 'Anasayfa Yönetimi';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('homepage/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Anasayfa ayarlarını getir
     */
    private function getHomepageSettings() {
        return [
            // Hero Section
            'hero_badge_text' => $this->themeModel->get('hero_badge_text') ?? 'Profesyonel Teknik Servis',
            'hero_title_line1' => $this->themeModel->get('hero_title_line1') ?? 'Kurumsal Teknoloji',
            'hero_title_line3' => $this->themeModel->get('hero_title_line3') ?? 'Çözüm Ortağınız',
            'hero_subtitle' => $this->themeModel->get('hero_subtitle') ?? 'Kurumsal ve bireysel müşterilerimize 10+ yıllık deneyimimizle profesyonel teknik servis hizmeti sunuyoruz.',
            'hero_rotating_texts' => $this->themeModel->get('hero_rotating_texts') ?? "BİLGİSAYAR TAMİRİ\nTELEFON TAMİRİ\nTABLET TAMİRİ\nYAZICI TAMİRİ\nFORMAT\nYAZILIM KURULUMU\nPARÇA DEĞİŞİMİ\nKURUMSAL & BİREYSEL TEKNİK SERVİS",
            
            // Hero Stats
            'hero_stat1_number' => $this->themeModel->get('hero_stat1_number') ?? '10+',
            'hero_stat1_label' => $this->themeModel->get('hero_stat1_label') ?? 'Yıl Deneyim',
            'hero_stat2_number' => $this->themeModel->get('hero_stat2_number') ?? '500+',
            'hero_stat2_label' => $this->themeModel->get('hero_stat2_label') ?? 'Mutlu Müşteri',
            'hero_stat3_number' => $this->themeModel->get('hero_stat3_number') ?? '24/7',
            'hero_stat3_label' => $this->themeModel->get('hero_stat3_label') ?? 'Destek',
            
            // Services Section
            'services_badge' => $this->themeModel->get('services_badge') ?? 'Hizmetlerimiz',
            'services_title' => $this->themeModel->get('services_title') ?? 'Sunduğumuz Profesyonel Hizmetler',
            'services_subtitle' => $this->themeModel->get('services_subtitle') ?? 'Tüm teknik servis ihtiyaçlarınız için profesyonel çözümler sunuyoruz',
            
            // Why Choose Us Section
            'why_badge' => $this->themeModel->get('why_badge') ?? 'Neden Bizi Seçmelisiniz',
            'why_title' => $this->themeModel->get('why_title') ?? 'Fark Yaratan Hizmet Anlayışımız',
            'why_subtitle' => $this->themeModel->get('why_subtitle') ?? 'Profesyonel hizmet anlayışımız ve müşteri memnuniyeti odaklı yaklaşımımızla sektörde öne çıkıyoruz.',
            
            // Feature 1
            'feature1_title' => $this->themeModel->get('feature1_title') ?? 'Hızlı Tamir Süreci',
            'feature1_desc' => $this->themeModel->get('feature1_desc') ?? 'Sorunlarınıza hızlıca müdahale ediyor, en kısa sürede çözüm sunuyoruz.',
            'feature1_highlight_num' => $this->themeModel->get('feature1_highlight_num') ?? '2-4',
            'feature1_highlight_text' => $this->themeModel->get('feature1_highlight_text') ?? 'Saat İçinde',
            
            // Feature 2
            'feature2_title' => $this->themeModel->get('feature2_title') ?? 'Ücretsiz Teşhis',
            'feature2_desc' => $this->themeModel->get('feature2_desc') ?? 'Tüm cihazlarınız için ücretsiz teşhis hizmeti sunuyoruz.',
            'feature2_highlight_num' => $this->themeModel->get('feature2_highlight_num') ?? '%100',
            'feature2_highlight_text' => $this->themeModel->get('feature2_highlight_text') ?? 'Ücretsiz',
            
            // Feature 3
            'feature3_title' => $this->themeModel->get('feature3_title') ?? 'Hızlı Teslimat',
            'feature3_desc' => $this->themeModel->get('feature3_desc') ?? 'Tamir işlemlerinizi hızlıca tamamlayıp size teslim ediyoruz.',
            'feature3_highlight_num' => $this->themeModel->get('feature3_highlight_num') ?? '24',
            'feature3_highlight_text' => $this->themeModel->get('feature3_highlight_text') ?? 'Saat Teslimat',
            
            // Feature 4
            'feature4_title' => $this->themeModel->get('feature4_title') ?? 'Garanti',
            'feature4_desc' => $this->themeModel->get('feature4_desc') ?? 'Tüm tamir işlemlerimizde garanti sunuyoruz.',
            'feature4_highlight_num' => $this->themeModel->get('feature4_highlight_num') ?? '6',
            'feature4_highlight_text' => $this->themeModel->get('feature4_highlight_text') ?? 'Ay Garanti',
            
            // Stats Section
            'stats_badge' => $this->themeModel->get('stats_badge') ?? 'Rakamlarla Biz',
            'stats_title' => $this->themeModel->get('stats_title') ?? 'Tecrübemizle Fark Yaratıyoruz',
            'stat1_number' => $this->themeModel->get('stat1_number') ?? '10',
            'stat1_label' => $this->themeModel->get('stat1_label') ?? 'Yıllık Tecrübe',
            'stat2_number' => $this->themeModel->get('stat2_number') ?? '500',
            'stat2_label' => $this->themeModel->get('stat2_label') ?? 'Mutlu Müşteri',
            'stat3_number' => $this->themeModel->get('stat3_number') ?? '1000',
            'stat3_label' => $this->themeModel->get('stat3_label') ?? 'Tamamlanan Proje',
            'stat4_number' => $this->themeModel->get('stat4_number') ?? '24',
            'stat4_label' => $this->themeModel->get('stat4_label') ?? 'Kesintisiz Destek',
            
            // Process Section
            'process_badge' => $this->themeModel->get('process_badge') ?? 'Süreç',
            'process_title' => $this->themeModel->get('process_title') ?? 'Nasıl Çalışıyoruz?',
            'process_subtitle' => $this->themeModel->get('process_subtitle') ?? 'Basit ve hızlı süreçlerimizle size en iyi hizmeti sunuyoruz.',
            'process1_title' => $this->themeModel->get('process1_title') ?? 'İletişime Geçin',
            'process1_desc' => $this->themeModel->get('process1_desc') ?? 'Bize ulaşın ve sorununuzu anlatın. Ücretsiz teşhis için randevu alın.',
            'process2_title' => $this->themeModel->get('process2_title') ?? 'Teşhis',
            'process2_desc' => $this->themeModel->get('process2_desc') ?? 'Uzman ekibimiz cihazınızı inceler ve sorunu tespit eder.',
            'process3_title' => $this->themeModel->get('process3_title') ?? 'Onay & Tamir',
            'process3_desc' => $this->themeModel->get('process3_desc') ?? 'Onayınızın ardından profesyonel tamir işlemi başlar.',
            'process4_title' => $this->themeModel->get('process4_title') ?? 'Teslimat',
            'process4_desc' => $this->themeModel->get('process4_desc') ?? 'Tamir tamamlandıktan sonra cihazınız size teslim edilir.',
            
            // CTA Section
            'cta_badge' => $this->themeModel->get('cta_badge') ?? 'Hemen Başlayın',
            'cta_title' => $this->themeModel->get('cta_title') ?? 'İşinize Geri Dönmenize Yardımcı Olacağız',
            'cta_subtitle' => $this->themeModel->get('cta_subtitle') ?? 'Teknoloji sorunlarınız için profesyonel çözümler sunuyoruz. Hızlı, güvenilir ve uygun fiyatlı hizmetlerimizle yanınızdayız.',
            'cta_button1_text' => $this->themeModel->get('cta_button1_text') ?? 'Ücretsiz Teşhis İste',
            'cta_button2_text' => $this->themeModel->get('cta_button2_text') ?? 'Hemen Ara',
            
            // Partners Section
            'partners_badge' => $this->themeModel->get('partners_badge') ?? 'Referanslarımız',
            'partners_title' => $this->themeModel->get('partners_title') ?? 'Bize Güvenen Firmalar',
            'partners_subtitle' => $this->themeModel->get('partners_subtitle') ?? 'Kurumsal ve bireysel müşterilerimizle güvene dayalı iş ortaklıkları kuruyoruz.',
        ];
    }
}
