<?php
/**
 * SEO Controller
 * Sayfa bazlı SEO ayarlarını yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/PageSeo.php';

class SeoController {
    private $seoModel;
    
    public function __construct() {
        $this->seoModel = new PageSeo();
    }
    
    /**
     * SEO listesi
     */
    public function index() {
        requireAuth();
        
        $pages = $this->seoModel->getAll();
        
        $pageTitle = 'SEO Ayarları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('seo/index', ['pages' => $pages]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * SEO düzenleme
     */
    public function edit($id) {
        requireAuth();
        
        $seo = $this->seoModel->findById($id);
        if (!$seo) {
            setFlash('error', 'SEO kaydı bulunamadı.');
            redirect(adminUrl('seo.php'));
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('seo.php?action=edit&id=' . $id));
            }
            
            $data = [
                'meta_title' => sanitizeInput($_POST['meta_title'] ?? ''),
                'meta_description' => sanitizeInput($_POST['meta_description'] ?? ''),
                'meta_keywords' => sanitizeInput($_POST['meta_keywords'] ?? ''),
                'og_title' => sanitizeInput($_POST['og_title'] ?? ''),
                'og_description' => sanitizeInput($_POST['og_description'] ?? ''),
                'og_image' => sanitizeInput($_POST['og_image'] ?? ''),
                'canonical_url' => sanitizeInput($_POST['canonical_url'] ?? ''),
                'robots' => sanitizeInput($_POST['robots'] ?? 'index, follow'),
                'custom_schema' => $_POST['custom_schema'] ?? '',
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            try {
                $this->seoModel->update($id, $data);
                setFlash('success', 'SEO ayarları güncellendi.');
                redirect(adminUrl('seo.php'));
            } catch (Exception $e) {
                setFlash('error', 'Güncelleme hatası: ' . $e->getMessage());
                redirect(adminUrl('seo.php?action=edit&id=' . $id));
            }
        }
        
        $pageTitle = 'SEO Düzenle: ' . $seo['page_slug'];
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('seo/edit', ['seo' => $seo]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Yeni SEO kaydı
     */
    public function create() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('seo.php?action=create'));
            }
            
            $slug = sanitizeInput($_POST['page_slug'] ?? '');
            
            if (empty($slug)) {
                setFlash('error', 'Sayfa slug gereklidir.');
                redirect(adminUrl('seo.php?action=create'));
            }
            
            if ($this->seoModel->slugExists($slug)) {
                setFlash('error', 'Bu sayfa için SEO kaydı zaten mevcut.');
                redirect(adminUrl('seo.php?action=create'));
            }
            
            $data = [
                'page_slug' => $slug,
                'meta_title' => sanitizeInput($_POST['meta_title'] ?? ''),
                'meta_description' => sanitizeInput($_POST['meta_description'] ?? ''),
                'meta_keywords' => sanitizeInput($_POST['meta_keywords'] ?? ''),
                'og_title' => sanitizeInput($_POST['og_title'] ?? ''),
                'og_description' => sanitizeInput($_POST['og_description'] ?? ''),
                'og_image' => sanitizeInput($_POST['og_image'] ?? ''),
                'canonical_url' => sanitizeInput($_POST['canonical_url'] ?? ''),
                'robots' => sanitizeInput($_POST['robots'] ?? 'index, follow'),
                'custom_schema' => $_POST['custom_schema'] ?? '',
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ];
            
            try {
                $this->seoModel->create($data);
                setFlash('success', 'SEO kaydı oluşturuldu.');
                redirect(adminUrl('seo.php'));
            } catch (Exception $e) {
                setFlash('error', 'Oluşturma hatası: ' . $e->getMessage());
                redirect(adminUrl('seo.php?action=create'));
            }
        }
        
        $pageTitle = 'Yeni SEO Kaydı';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('seo/create', []);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * SEO kaydını sil
     */
    public function delete($id) {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('seo.php'));
            }
            
            $this->seoModel->delete($id);
            setFlash('success', 'SEO kaydı silindi.');
        }
        
        redirect(adminUrl('seo.php'));
    }
    
    /**
     * Genel SEO ayarları
     */
    public function settings() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası.');
                redirect(adminUrl('seo.php?action=settings'));
            }
            
            $settings = [
                'google_analytics_id' => $_POST['google_analytics_id'] ?? '',
                'google_search_console' => $_POST['google_search_console'] ?? '',
                'sitemap_enabled' => isset($_POST['sitemap_enabled']) ? '1' : '0',
                'sitemap_include_services' => isset($_POST['sitemap_include_services']) ? '1' : '0',
                'sitemap_include_blog' => isset($_POST['sitemap_include_blog']) ? '1' : '0',
                'sitemap_changefreq' => $_POST['sitemap_changefreq'] ?? 'weekly'
            ];
            
            foreach ($settings as $key => $value) {
                setThemeSetting($key, $value);
            }
            
            setFlash('success', 'SEO ayarları güncellendi.');
            redirect(adminUrl('seo.php?action=settings'));
        }
        
        $pageTitle = 'Genel SEO Ayarları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('seo/settings', []);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
}
