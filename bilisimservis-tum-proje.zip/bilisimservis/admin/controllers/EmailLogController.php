<?php
/**
 * Email Log Controller
 * E-posta gönderim loglarını yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/EmailLog.php';

class EmailLogController {
    private $logModel;
    
    public function __construct() {
        $this->logModel = new EmailLog();
    }
    
    /**
     * Log listesi
     */
    public function index() {
        requireAuth();
        
        // Filtreler
        $filters = [
            'status' => $_GET['status'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
            'search' => $_GET['search'] ?? '',
            'limit' => 50,
            'offset' => (($_GET['page'] ?? 1) - 1) * 50
        ];
        
        $logs = $this->logModel->getAll($filters);
        $totalCount = $this->logModel->getCount($filters);
        $stats = $this->logModel->getStats();
        
        $pageTitle = 'E-Mail Log Kayıtları';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('email-logs/index', [
            'logs' => $logs,
            'filters' => $filters,
            'totalCount' => $totalCount,
            'stats' => $stats,
            'currentPage' => $_GET['page'] ?? 1,
            'totalPages' => ceil($totalCount / 50)
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Log detayı (AJAX)
     */
    public function view($id) {
        requireAuth();
        
        header('Content-Type: application/json');
        
        $log = $this->logModel->findById($id);
        
        if ($log) {
            echo json_encode([
                'success' => true,
                'log' => $log
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Log kaydı bulunamadı.'
            ]);
        }
        exit;
    }
    
    /**
     * Tek log sil
     */
    public function delete($id) {
        requireAuth();
        
        if ($this->logModel->delete($id)) {
            setFlash('success', 'Log kaydı silindi.');
        } else {
            setFlash('error', 'Log kaydı silinirken hata oluştu.');
        }
    }
    
    /**
     * Toplu sil
     */
    public function deleteMultiple() {
        requireAuth();
        
        header('Content-Type: application/json');
        
        if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Güvenlik hatası.']);
            exit;
        }
        
        $ids = $_POST['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['success' => false, 'message' => 'Seçili kayıt yok.']);
            exit;
        }
        
        if ($this->logModel->deleteMultiple($ids)) {
            echo json_encode(['success' => true, 'message' => count($ids) . ' kayıt silindi.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Silme işlemi başarısız.']);
        }
        exit;
    }
    
    /**
     * Eski logları temizle
     */
    public function cleanOld() {
        requireAuth();
        
        $days = (int) ($_GET['days'] ?? 30);
        
        if ($this->logModel->cleanOldLogs($days)) {
            setFlash('success', $days . ' günden eski log kayıtları temizlendi.');
        } else {
            setFlash('error', 'Temizleme işlemi başarısız.');
        }
        
        redirect(adminUrl('email-logs.php'));
    }
}
