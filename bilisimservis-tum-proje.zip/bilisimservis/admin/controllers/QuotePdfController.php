<?php
/**
 * Quote PDF Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/Quote.php';

// Composer autoloader kontrolü
if (!class_exists('Dompdf\Dompdf')) {
    die('DomPDF kütüphanesi yüklenmemiş. Lütfen "composer install" komutunu çalıştırın.');
}

use Dompdf\Dompdf;
use Dompdf\Options;

class QuotePdfController {
    private $quoteModel;
    
    public function __construct() {
        $this->quoteModel = new Quote();
    }
    
    /**
     * Teklif PDF'i oluştur ve göster
     */
    public function generate($quoteId) {
        requireAuth();
        
        // ID'yi integer'a çevir
        $quoteId = intval($quoteId);
        
        if ($quoteId <= 0) {
            die('Geçersiz teklif ID.');
        }
        
        $quote = $this->quoteModel->findById($quoteId);
        if (!$quote) {
            die('Teklif bulunamadı. ID: ' . $quoteId);
        }
        
        // Önbellek kontrolü - PDF'in her seferinde yeniden oluşturulmasını sağla
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Cache-Control: post-check=0, pre-check=0', false);
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // PDF seçenekleri
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans');
        
        $dompdf = new Dompdf($options);
        
        // HTML içeriği oluştur
        $html = $this->generateHtml($quote);
        
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        
        // PDF'i indir (Attachment=1 direkt indirir, =0 tarayıcıda açar)
        $dompdf->stream(
            'teklif-' . $quote['quote_number'] . '.pdf',
            ['Attachment' => 1]
        );
        exit;
    }
    
    /**
     * PDF HTML içeriğini oluştur
     */
    private function generateHtml($quote) {
        $statusLabels = [
            'draft' => 'Taslak',
            'sent' => 'Gönderildi',
            'approved' => 'Onaylandı',
            'rejected' => 'Reddedildi'
        ];
        
        $siteName = getThemeSetting('site_name', 'Bilişim Servis');
        $siteAddress = getThemeSetting('contact_address', '');
        $sitePhone = getThemeSetting('contact_phone', '');
        $siteEmail = getThemeSetting('contact_email', '');
        
        $html = '<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <style>
        @page { margin: 0; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: DejaVu Sans, sans-serif; 
            font-size: 11px; 
            color: #1a1a2e; 
            background: #ffffff;
            line-height: 1.5;
        }
        
        /* Header - Koyu Gradient */
        .main-header {
            background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%);
            color: #ffffff;
            padding: 30px 40px;
            position: relative;
        }
        .main-header::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #0066FF 0%, #00D4FF 100%);
        }
        .header-content {
            display: table;
            width: 100%;
        }
        .company-info {
            display: table-cell;
            vertical-align: middle;
            width: 60%;
        }
        .company-name {
            font-size: 22px;
            font-weight: bold;
            color: #ffffff;
            margin-bottom: 5px;
        }
        .company-name span { color: #0066FF; }
        .company-tagline {
            font-size: 10px;
            color: #a0aec0;
            letter-spacing: 1px;
        }
        .quote-badge {
            display: table-cell;
            vertical-align: middle;
            text-align: right;
            width: 40%;
        }
        .quote-title {
            font-size: 28px;
            font-weight: bold;
            color: #0066FF;
            letter-spacing: 2px;
        }
        .quote-number {
            font-size: 14px;
            color: #e2e8f0;
            margin-top: 5px;
        }
        
        /* Content Area */
        .content {
            padding: 30px 40px;
        }
        
        /* Info Cards */
        .info-grid {
            display: table;
            width: 100%;
            margin-bottom: 25px;
        }
        .info-card {
            display: table-cell;
            width: 48%;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            vertical-align: top;
        }
        .info-card:first-child { margin-right: 4%; }
        .info-card-title {
            font-size: 11px;
            font-weight: bold;
            color: #0066FF;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #0066FF;
        }
        .info-row {
            margin-bottom: 6px;
            font-size: 11px;
        }
        .info-label {
            color: #64748b;
            display: inline-block;
            width: 80px;
        }
        .info-value {
            color: #1a1a2e;
            font-weight: 500;
        }
        .company-name-large {
            font-size: 14px;
            font-weight: bold;
            color: #1a1a2e;
            margin-bottom: 8px;
        }
        
        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-draft { background: #fef3c7; color: #92400e; }
        .status-sent { background: #dbeafe; color: #1e40af; }
        .status-approved { background: #d1fae5; color: #065f46; }
        .status-rejected { background: #fee2e2; color: #991b1b; }
        
        /* Subject Section */
        .subject-section {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-left: 4px solid #0066FF;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 0 8px 8px 0;
        }
        .subject-label {
            font-size: 10px;
            color: #0066FF;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        .subject-text {
            font-size: 13px;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        /* Table */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 10px;
        }
        .items-table thead th {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #ffffff;
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 9px;
        }
        .items-table thead th:first-child { border-radius: 8px 0 0 0; }
        .items-table thead th:last-child { border-radius: 0 8px 0 0; }
        .items-table tbody td {
            padding: 12px 10px;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: top;
        }
        .items-table tbody tr:nth-child(even) { background: #f8fafc; }
        .items-table tbody tr:hover { background: #f1f5f9; }
        .item-name {
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 3px;
        }
        .item-desc {
            font-size: 9px;
            color: #64748b;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        
        /* Totals */
        .totals-section {
            display: table;
            width: 100%;
            margin-top: 20px;
        }
        .totals-spacer {
            display: table-cell;
            width: 55%;
        }
        .totals-box {
            display: table-cell;
            width: 45%;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 15px 20px;
        }
        .total-row {
            display: table;
            width: 100%;
            margin-bottom: 8px;
            font-size: 11px;
        }
        .total-label {
            display: table-cell;
            color: #64748b;
        }
        .total-value {
            display: table-cell;
            text-align: right;
            font-weight: 500;
            color: #1a1a2e;
        }
        .grand-total-row {
            border-top: 2px solid #0066FF;
            padding-top: 12px;
            margin-top: 12px;
        }
        .grand-total-row .total-label {
            font-size: 13px;
            font-weight: bold;
            color: #1a1a2e;
        }
        .grand-total-row .total-value {
            font-size: 16px;
            font-weight: bold;
            color: #0066FF;
        }
        
        /* Notes */
        .notes-section {
            background: #fffbeb;
            border: 1px solid #fcd34d;
            border-radius: 8px;
            padding: 15px 20px;
            margin-top: 25px;
        }
        .notes-title {
            font-size: 10px;
            font-weight: bold;
            color: #92400e;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }
        .notes-text {
            font-size: 11px;
            color: #78350f;
            line-height: 1.6;
        }
        
        /* Customer Note */
        .customer-note-section {
            background: #f0fdf4;
            border: 1px solid #86efac;
            border-radius: 8px;
            padding: 15px 20px;
            margin-top: 15px;
        }
        .customer-note-title {
            font-size: 10px;
            font-weight: bold;
            color: #166534;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }
        .customer-note-text {
            font-size: 11px;
            color: #15803d;
            line-height: 1.6;
        }
        
        /* Footer */
        .main-footer {
            background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 100%);
            color: #a0aec0;
            padding: 20px 40px;
            margin-top: 30px;
            font-size: 9px;
        }
        .footer-content {
            display: table;
            width: 100%;
        }
        .footer-left {
            display: table-cell;
            width: 50%;
            vertical-align: middle;
        }
        .footer-right {
            display: table-cell;
            width: 50%;
            text-align: right;
            vertical-align: middle;
        }
        .footer-company {
            font-size: 12px;
            font-weight: bold;
            color: #ffffff;
            margin-bottom: 5px;
        }
        .footer-company span { color: #0066FF; }
        .footer-contact {
            line-height: 1.8;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="main-header">
        <div class="header-content">
            <div class="company-info">
                <div class="company-name"><span>' . htmlspecialchars(explode(' ', $siteName)[0] ?? 'BİLİŞİM') . '</span> ' . htmlspecialchars(implode(' ', array_slice(explode(' ', $siteName), 1)) ?: 'SERVİS') . '</div>
                <div class="company-tagline">Profesyonel Teknoloji Çözümleri</div>
            </div>
            <div class="quote-badge">
                <div class="quote-title">TEKLİF</div>
                <div class="quote-number">' . htmlspecialchars($quote['quote_number']) . '</div>
            </div>
        </div>
    </div>
    
    <!-- Content -->
    <div class="content">
        <!-- Info Cards -->
        <div class="info-grid">
            <div class="info-card">
                <div class="info-card-title">Müşteri Bilgileri</div>
                <div class="company-name-large">' . htmlspecialchars($quote['company_name']) . '</div>
                <div class="info-row">
                    <span class="info-value">' . htmlspecialchars($quote['province'] . ' / ' . $quote['district']) . '</span>
                </div>
                ' . (!empty($quote['address']) ? '<div class="info-row"><span class="info-value">' . htmlspecialchars($quote['address']) . '</span></div>' : '') . '
                ' . (!empty($quote['phone']) ? '<div class="info-row"><span class="info-label">Telefon:</span><span class="info-value">' . htmlspecialchars($quote['phone']) . '</span></div>' : '') . '
                ' . (!empty($quote['email']) ? '<div class="info-row"><span class="info-label">E-posta:</span><span class="info-value">' . htmlspecialchars($quote['email']) . '</span></div>' : '') . '
                ' . (!empty($quote['tax_number']) ? '<div class="info-row"><span class="info-label">Vergi No:</span><span class="info-value">' . htmlspecialchars($quote['tax_number']) . '</span></div>' : '') . '
            </div>
            <div class="info-card" style="margin-left: 20px;">
                <div class="info-card-title">Teklif Detayları</div>
                <div class="info-row">
                    <span class="info-label">Tarih:</span>
                    <span class="info-value">' . formatDate($quote['created_at']) . '</span>
                </div>
                ' . (!empty($quote['valid_until']) ? '<div class="info-row"><span class="info-label">Geçerlilik:</span><span class="info-value">' . formatDate($quote['valid_until']) . '</span></div>' : '') . '
                <div class="info-row">
                    <span class="info-label">Durum:</span>
                    <span class="status-badge status-' . $quote['status'] . '">' . ($statusLabels[$quote['status']] ?? $quote['status']) . '</span>
                </div>
            </div>
        </div>
        
        <!-- Subject -->
        <div class="subject-section">
            <div class="subject-label">Teklif Konusu</div>
            <div class="subject-text">' . htmlspecialchars($quote['subject']) . '</div>
        </div>
        
        <!-- Items Table -->
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th style="width: 35%;">Hizmet / Ürün</th>
                    <th class="text-center" style="width: 10%;">Miktar</th>
                    <th class="text-right" style="width: 15%;">Birim Fiyat</th>
                    <th class="text-center" style="width: 8%;">KDV</th>
                    <th class="text-right" style="width: 12%;">İndirim</th>
                    <th class="text-right" style="width: 15%;">Toplam</th>
                </tr>
            </thead>
            <tbody>';
        
        foreach ($quote['items'] as $index => $item) {
            $html .= '
                <tr>
                    <td class="text-center">' . ($index + 1) . '</td>
                    <td>
                        <div class="item-name">' . htmlspecialchars($item['item_name']) . '</div>
                        ' . (!empty($item['description']) ? '<div class="item-desc">' . htmlspecialchars($item['description']) . '</div>' : '') . '
                    </td>
                    <td class="text-center">' . number_format($item['quantity'], 0, ',', '.') . '</td>
                    <td class="text-right">' . formatMoney($item['unit_price']) . '</td>
                    <td class="text-center">%' . number_format($item['tax_rate'], 0) . '</td>
                    <td class="text-right">' . formatMoney($item['discount']) . '</td>
                    <td class="text-right" style="font-weight: 600; color: #0066FF;">' . formatMoney($item['total']) . '</td>
                </tr>';
        }
        
        $html .= '
            </tbody>
        </table>
        
        <!-- Totals -->
        <div class="totals-section">
            <div class="totals-spacer"></div>
            <div class="totals-box">
                <div class="total-row">
                    <span class="total-label">Ara Toplam</span>
                    <span class="total-value">' . formatMoney($quote['subtotal']) . '</span>
                </div>
                <div class="total-row">
                    <span class="total-label">KDV Toplamı</span>
                    <span class="total-value">' . formatMoney($quote['tax_total']) . '</span>
                </div>
                <div class="total-row">
                    <span class="total-label">İndirim</span>
                    <span class="total-value">-' . formatMoney($quote['discount_total']) . '</span>
                </div>
                <div class="total-row grand-total-row">
                    <span class="total-label">Genel Toplam</span>
                    <span class="total-value">' . formatMoney($quote['grand_total']) . '</span>
                </div>
            </div>
        </div>';
        
        // Müşteri Notu (Teklifte görünür)
        if (!empty($quote['customer_note'])) {
            $html .= '
        <div class="customer-note-section">
            <div class="customer-note-title">Bilgilendirme</div>
            <div class="customer-note-text">' . nl2br(htmlspecialchars($quote['customer_note'])) . '</div>
        </div>';
        }
        
        // Dahili notlar (opsiyonel - müşteriye göstermek istemeyebilirsiniz)
        // if (!empty($quote['notes'])) {
        //     $html .= '
        // <div class="notes-section">
        //     <div class="notes-title">Notlar</div>
        //     <div class="notes-text">' . nl2br(htmlspecialchars($quote['notes'])) . '</div>
        // </div>';
        // }
        
        $html .= '
    </div>
    
    <!-- Footer -->
    <div class="main-footer">
        <div class="footer-content">
            <div class="footer-left">
                <div class="footer-company"><span>' . htmlspecialchars(explode(' ', $siteName)[0] ?? 'BİLİŞİM') . '</span> ' . htmlspecialchars(implode(' ', array_slice(explode(' ', $siteName), 1)) ?: 'SERVİS') . '</div>
                <div class="footer-contact">
                    ' . (!empty($siteAddress) ? htmlspecialchars($siteAddress) . '<br>' : '') . '
                    ' . (!empty($sitePhone) ? 'Tel: ' . htmlspecialchars($sitePhone) : '') . '
                    ' . (!empty($siteEmail) ? ' | ' . htmlspecialchars($siteEmail) : '') . '
                </div>
            </div>
            <div class="footer-right">
                Bu teklif ' . date('d.m.Y') . ' tarihinde oluşturulmuştur.<br>
                ' . (!empty($quote['valid_until']) ? 'Geçerlilik: ' . formatDate($quote['valid_until']) : '') . '
            </div>
        </div>
    </div>
</body>
</html>';
        
        return $html;
    }
}
