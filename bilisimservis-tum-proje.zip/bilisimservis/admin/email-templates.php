<?php
/**
 * Email Templates Entry Point
 * E-posta Şablonları Yönetimi
 */

require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/EmailTemplateController.php';

$controller = new EmailTemplateController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('email-templates.php'));
        }
        break;
    case 'toggle':
        if ($id) {
            $controller->toggle($id);
        }
        redirect(adminUrl('email-templates.php'));
        break;
    case 'preview':
        if ($id) {
            $controller->preview($id);
        }
        break;
    default:
        $controller->index();
        break;
}
