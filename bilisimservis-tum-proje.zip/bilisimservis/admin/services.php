<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/ServiceController.php';

$controller = new ServiceController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'create':
        $controller->create();
        break;
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('services.php'));
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        } else {
            redirect(adminUrl('services.php'));
        }
        break;
    case 'toggle':
        if ($id) {
            $controller->toggleActive($id);
        } else {
            redirect(adminUrl('services.php'));
        }
        break;
    default:
        $controller->index();
        break;
}
