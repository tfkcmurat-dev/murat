<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/SeoController.php';

$controller = new SeoController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'create':
        $controller->create();
        break;
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('seo.php'));
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        } else {
            redirect(adminUrl('seo.php'));
        }
        break;
    case 'settings':
        $controller->settings();
        break;
    default:
        $controller->index();
        break;
}
