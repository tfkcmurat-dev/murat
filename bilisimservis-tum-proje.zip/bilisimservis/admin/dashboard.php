<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/DashboardController.php';

$controller = new DashboardController();
$controller->index();
