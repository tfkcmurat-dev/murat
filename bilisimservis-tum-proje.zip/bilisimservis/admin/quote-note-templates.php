<?php
/**
 * Quote Note Templates Entry Point
 * Teklif Not Şablonları Yönetimi
 */

require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/QuoteNoteTemplateController.php';

$controller = new QuoteNoteTemplateController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'create':
        $controller->create();
        break;
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('quote-note-templates.php'));
        }
        break;
    case 'delete':
        if ($id) {
            $controller->delete($id);
        }
        redirect(adminUrl('quote-note-templates.php'));
        break;
    case 'toggle':
        if ($id) {
            $controller->toggle($id);
        }
        redirect(adminUrl('quote-note-templates.php'));
        break;
    case 'get':
        if ($id) {
            $controller->get($id);
        }
        break;
    default:
        $controller->index();
        break;
}
