<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/AboutPageController.php';

$controller = new AboutPageController();
$controller->index();
