<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/AuthController.php';

$controller = new AuthController();
$controller->changePassword();
