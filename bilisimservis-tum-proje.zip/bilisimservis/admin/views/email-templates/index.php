<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>E-Mail Şablonları</h1>
        <p>Sistem tarafından gönderilen e-posta şablonlarını buradan yönetin.</p>
    </div>
</div>

<!-- Şablon Listesi -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-envelope-paper me-2"></i>
        Şablonlar
    </div>
    <div class="card-body" style="padding: 0;">
        <table class="table">
            <thead>
                <tr>
                    <th>Şablon Adı</th>
                    <th>Slug</th>
                    <th>Konu</th>
                    <th style="text-align: center;">Durum</th>
                    <th style="text-align: center;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($templates)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                            Henüz şablon bulunmuyor.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($templates as $template): ?>
                        <tr>
                            <td>
                                <strong><?= clean($template['name']) ?></strong>
                            </td>
                            <td>
                                <code style="background: var(--bg-input); padding: 4px 8px; border-radius: 4px; font-size: 0.85rem;">
                                    <?= clean($template['slug']) ?>
                                </code>
                            </td>
                            <td style="color: var(--text-secondary);">
                                <?= clean($template['subject']) ?>
                            </td>
                            <td style="text-align: center;">
                                <?php if ($template['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <div class="d-flex gap-2 justify-content-center">
                                    <button type="button" class="btn btn-sm" onclick="previewTemplate(<?= $template['id'] ?>)" style="background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.3);">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <a href="<?= adminUrl('email-templates.php?action=edit&id=' . $template['id']) ?>" class="btn btn-sm btn-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="<?= adminUrl('email-templates.php?action=toggle&id=' . $template['id']) ?>" class="btn btn-sm" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                                        <i class="bi bi-<?= $template['is_active'] ? 'pause' : 'play' ?>-fill"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Değişkenler Bilgisi -->
<div class="card">
    <div class="card-header bg-info">
        <i class="bi bi-info-circle me-2"></i>
        Kullanılabilir Değişkenler
    </div>
    <div class="card-body">
        <p style="color: var(--text-secondary); margin-bottom: 16px;">
            Şablonlarda aşağıdaki değişkenleri <code>{değişken_adı}</code> formatında kullanabilirsiniz:
        </p>
        <div class="row">
            <div class="col-md-4 mb-3">
                <h6 style="color: var(--accent-secondary); margin-bottom: 8px;">Genel</h6>
                <ul style="list-style: none; padding: 0; margin: 0; color: var(--text-secondary); font-size: 0.9rem;">
                    <li><code>{site_name}</code> - Site adı</li>
                    <li><code>{site_url}</code> - Site URL'si</li>
                    <li><code>{contact_phone}</code> - İletişim telefonu</li>
                    <li><code>{contact_email}</code> - İletişim e-postası</li>
                    <li><code>{date}</code> - Tarih/saat</li>
                    <li><code>{year}</code> - Yıl</li>
                </ul>
            </div>
            <div class="col-md-4 mb-3">
                <h6 style="color: var(--accent-secondary); margin-bottom: 8px;">İletişim Formu</h6>
                <ul style="list-style: none; padding: 0; margin: 0; color: var(--text-secondary); font-size: 0.9rem;">
                    <li><code>{name}</code> - Ad soyad</li>
                    <li><code>{email}</code> - E-posta</li>
                    <li><code>{subject}</code> - Konu</li>
                    <li><code>{message}</code> - Mesaj</li>
                    <li><code>{ip_address}</code> - IP adresi</li>
                </ul>
            </div>
            <div class="col-md-4 mb-3">
                <h6 style="color: var(--accent-secondary); margin-bottom: 8px;">Teklif</h6>
                <ul style="list-style: none; padding: 0; margin: 0; color: var(--text-secondary); font-size: 0.9rem;">
                    <li><code>{customer_name}</code> - Müşteri adı</li>
                    <li><code>{quote_number}</code> - Teklif numarası</li>
                    <li><code>{quote_subject}</code> - Teklif konusu</li>
                    <li><code>{quote_items}</code> - Teklif kalemleri</li>
                    <li><code>{grand_total}</code> - Genel toplam</li>
                    <li><code>{valid_until}</code> - Geçerlilik tarihi</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Önizleme Modal -->
<div id="previewModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 1000; overflow-y: auto; padding: 40px 20px;">
    <div style="background: var(--bg-card); border-radius: 16px; max-width: 800px; margin: 0 auto; border: 1px solid var(--border-color);">
        <div style="padding: 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; color: var(--text-primary);">Şablon Önizleme</h3>
            <button type="button" onclick="closePreview()" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div style="padding: 20px;">
            <div style="margin-bottom: 16px;">
                <strong style="color: var(--text-muted);">Konu:</strong>
                <div id="previewSubject" style="padding: 10px; background: var(--bg-input); border-radius: 8px; margin-top: 4px;"></div>
            </div>
            <div>
                <strong style="color: var(--text-muted);">İçerik:</strong>
                <div id="previewBody" style="padding: 20px; background: white; border-radius: 8px; margin-top: 4px; max-height: 500px; overflow-y: auto;"></div>
            </div>
        </div>
    </div>
</div>

<script>
function previewTemplate(id) {
    fetch('<?= adminUrl("email-templates.php?action=preview&id=") ?>' + id)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('previewSubject').textContent = data.subject;
                document.getElementById('previewBody').innerHTML = data.body;
                document.getElementById('previewModal').style.display = 'block';
            } else {
                alert(data.message || 'Önizleme yüklenemedi.');
            }
        })
        .catch(error => {
            alert('Bir hata oluştu: ' + error.message);
        });
}

function closePreview() {
    document.getElementById('previewModal').style.display = 'none';
}

// ESC tuşu ile modal kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreview();
    }
});
</script>
