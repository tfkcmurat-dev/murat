<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Şablon Düzenle</h1>
        <p><?= clean($template['name']) ?></p>
    </div>
    <a href="<?= adminUrl('email-templates.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="">
    <?= csrfField() ?>
    
    <div class="row">
        <div class="col-md-8">
            <!-- Şablon Bilgileri -->
            <div class="card">
                <div class="card-header bg-primary">
                    <i class="bi bi-envelope-paper me-2"></i>
                    Şablon Bilgileri
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Şablon Adı</label>
                            <input type="text" name="name" class="form-control" value="<?= clean($template['name']) ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Slug (Değiştirilemez)</label>
                            <input type="text" class="form-control" value="<?= clean($template['slug']) ?>" disabled style="opacity: 0.6;">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">E-posta Konusu</label>
                            <input type="text" name="subject" class="form-control" value="<?= clean($template['subject']) ?>" required>
                            <small style="color: var(--text-muted);">Değişkenler kullanabilirsiniz: {name}, {site_name} vb.</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- E-posta İçeriği -->
            <div class="card">
                <div class="card-header bg-info">
                    <i class="bi bi-code-slash me-2"></i>
                    E-posta İçeriği (HTML)
                </div>
                <div class="card-body">
                    <textarea name="body" id="emailBody" class="form-control" rows="20" style="font-family: monospace; font-size: 0.9rem;"><?= clean($template['body']) ?></textarea>
                    <small style="color: var(--text-muted);">HTML formatında içerik girebilirsiniz. Değişkenler için {değişken_adı} formatını kullanın.</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Durum -->
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-toggle-on me-2"></i>
                    Durum
                </div>
                <div class="card-body">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="is_active" value="1" <?= $template['is_active'] ? 'checked' : '' ?> style="width: 20px; height: 20px;">
                        <span>Şablon Aktif</span>
                    </label>
                    <small style="color: var(--text-muted); display: block; margin-top: 8px;">
                        Pasif şablonlar mail gönderiminde kullanılmaz.
                    </small>
                </div>
            </div>

            <!-- Kullanılan Değişkenler -->
            <div class="card">
                <div class="card-header bg-secondary">
                    <i class="bi bi-braces me-2"></i>
                    Kullanılan Değişkenler
                </div>
                <div class="card-body">
                    <div id="variablesList">
                        <?php if (!empty($variables)): ?>
                            <?php foreach ($variables as $var): ?>
                                <span class="badge badge-info" style="margin: 2px; font-size: 0.85rem;">{<?= clean($var) ?>}</span>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <span style="color: var(--text-muted);">Değişken bulunamadı</span>
                        <?php endif; ?>
                    </div>
                    <small style="color: var(--text-muted); display: block; margin-top: 12px;">
                        İçerikte tespit edilen değişkenler.
                    </small>
                </div>
            </div>

            <!-- Önizleme -->
            <div class="card">
                <div class="card-header bg-success">
                    <i class="bi bi-eye me-2"></i>
                    Önizleme
                </div>
                <div class="card-body">
                    <button type="button" id="previewBtn" class="btn btn-success" style="width: 100%;">
                        <i class="bi bi-play-fill me-2"></i>Önizleme Göster
                    </button>
                    <small style="color: var(--text-muted); display: block; margin-top: 8px; text-align: center;">
                        Örnek verilerle şablonu önizleyin.
                    </small>
                </div>
            </div>

            <!-- Bilgi -->
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i>
                    Bilgi
                </div>
                <div class="card-body">
                    <p style="margin-bottom: 8px; color: var(--text-secondary); font-size: 0.9rem;">
                        <strong>Oluşturulma:</strong><br>
                        <?= formatDate($template['created_at']) ?>
                    </p>
                    <?php if ($template['updated_at']): ?>
                        <p style="margin-bottom: 0; color: var(--text-secondary); font-size: 0.9rem;">
                            <strong>Son Güncelleme:</strong><br>
                            <?= formatDate($template['updated_at']) ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Kaydet -->
    <div class="d-flex justify-content-end gap-2 mb-4">
        <a href="<?= adminUrl('email-templates.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
            İptal
        </a>
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="bi bi-check-lg me-2"></i>Değişiklikleri Kaydet
        </button>
    </div>
</form>

<!-- Önizleme Modal -->
<div id="previewModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 1000; overflow-y: auto; padding: 40px 20px;">
    <div style="background: var(--bg-card); border-radius: 16px; max-width: 800px; margin: 0 auto; border: 1px solid var(--border-color);">
        <div style="padding: 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; color: var(--text-primary);">Şablon Önizleme</h3>
            <button type="button" onclick="closePreview()" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div style="padding: 20px;">
            <div style="margin-bottom: 16px;">
                <strong style="color: var(--text-muted);">Konu:</strong>
                <div id="previewSubject" style="padding: 10px; background: var(--bg-input); border-radius: 8px; margin-top: 4px;"></div>
            </div>
            <div>
                <strong style="color: var(--text-muted);">İçerik:</strong>
                <div id="previewBody" style="padding: 20px; background: white; border-radius: 8px; margin-top: 4px; max-height: 500px; overflow-y: auto;"></div>
            </div>
        </div>
    </div>
</div>

<script>
// Önizleme
document.getElementById('previewBtn').addEventListener('click', function() {
    fetch('<?= adminUrl("email-templates.php?action=preview&id=" . $template["id"]) ?>')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('previewSubject').textContent = data.subject;
                document.getElementById('previewBody').innerHTML = data.body;
                document.getElementById('previewModal').style.display = 'block';
            } else {
                alert(data.message || 'Önizleme yüklenemedi.');
            }
        })
        .catch(error => {
            alert('Bir hata oluştu: ' + error.message);
        });
});

function closePreview() {
    document.getElementById('previewModal').style.display = 'none';
}

// ESC tuşu ile modal kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreview();
    }
});

// Değişkenleri güncelle
document.getElementById('emailBody').addEventListener('input', function() {
    const content = this.value;
    const regex = /\{([a-zA-Z_]+)\}/g;
    const matches = [...content.matchAll(regex)];
    const variables = [...new Set(matches.map(m => m[1]))];
    
    const container = document.getElementById('variablesList');
    if (variables.length > 0) {
        container.innerHTML = variables.map(v => 
            '<span class="badge badge-info" style="margin: 2px; font-size: 0.85rem;">{' + v + '}</span>'
        ).join('');
    } else {
        container.innerHTML = '<span style="color: var(--text-muted);">Değişken bulunamadı</span>';
    }
});
</script>
