<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Tema Ayarları</h1>
        <p>Site içeriklerini buradan düzenleyebilirsiniz.</p>
    </div>
</div>

<form method="POST" action="" enctype="multipart/form-data">
    <?= csrfField() ?>
    
    <?php foreach ($groups as $groupKey => $groupName): ?>
    <div class="card">
        <div class="card-header bg-primary">
            <i class="bi bi-gear me-2"></i>
            <?= clean($groupName) ?>
        </div>
        <div class="card-body">
            <?php if ($groupKey === 'general'): ?>
                <!-- Favicon Yükleme Alanı -->
                <div class="row mb-4">
                    <div class="col-md-12">
                        <label for="favicon_file" class="form-label">
                            <i class="bi bi-image me-2"></i>Favicon
                        </label>
                        <input 
                            type="file"
                            id="favicon_file"
                            name="favicon_file"
                            accept="image/x-icon,image/vnd.microsoft.icon,image/png,image/jpeg,image/gif,image/webp"
                            class="form-control"
                        >
                        <small class="form-text text-muted">
                            Favicon dosyası yükleyin (ICO, PNG, JPEG, GIF veya WebP formatında, maksimum 5MB)
                        </small>
                        <?php 
                        $currentFavicon = null;
                        foreach ($settings[$groupKey] ?? [] as $setting) {
                            if ($setting['setting_key'] === 'favicon') {
                                $currentFavicon = $setting['setting_value'];
                                break;
                            }
                        }
                        ?>
                        <?php if (!empty($currentFavicon)): ?>
                            <div class="mt-2">
                                <small class="text-muted">Mevcut favicon:</small><br>
                                <img src="<?= clean($currentFavicon) ?>" alt="Favicon" style="width: 32px; height: 32px; margin-top: 5px;" onerror="this.style.display='none';">
                                <small class="text-muted d-block mt-1"><?= clean($currentFavicon) ?></small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (isset($settings[$groupKey]) && !empty($settings[$groupKey])): ?>
                <div class="row">
                    <?php foreach ($settings[$groupKey] as $setting): ?>
                        <?php if ($setting['setting_key'] !== 'favicon'): ?>
                        <div class="col-md-6 mb-3">
                            <label for="setting_<?= $setting['setting_key'] ?>" class="form-label">
                                <?= clean($setting['description'] ?? $setting['setting_key']) ?>
                            </label>
                            
                            <?php if ($setting['setting_type'] == 'textarea'): ?>
                                <textarea 
                                    id="setting_<?= $setting['setting_key'] ?>"
                                    name="settings[<?= clean($setting['setting_key']) ?>]"
                                    rows="3"
                                    class="form-control"
                                ><?= clean($setting['setting_value']) ?></textarea>
                            <?php elseif ($setting['setting_type'] == 'email'): ?>
                                <input 
                                    type="email"
                                    id="setting_<?= $setting['setting_key'] ?>"
                                    name="settings[<?= clean($setting['setting_key']) ?>]"
                                    value="<?= clean($setting['setting_value']) ?>"
                                    class="form-control"
                                >
                            <?php else: ?>
                                <input 
                                    type="text"
                                    id="setting_<?= $setting['setting_key'] ?>"
                                    name="settings[<?= clean($setting['setting_key']) ?>]"
                                    value="<?= clean($setting['setting_value']) ?>"
                                    class="form-control"
                                >
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: var(--text-muted);">Bu grupta henüz ayar bulunmamaktadır.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    
    <div class="d-flex justify-content-end mb-4">
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="bi bi-check-lg me-2"></i>Ayarları Kaydet
        </button>
    </div>
</form>
