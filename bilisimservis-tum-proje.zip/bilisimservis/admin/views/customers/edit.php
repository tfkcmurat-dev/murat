<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Müşteri Düzenle</h1>
        <p>Müşteri bilgilerini güncelleyin.</p>
    </div>
    <a href="<?= adminUrl('customers.php') ?>" class="btn btn-outline-primary">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<div class="card">
    <div class="card-header bg-primary">
        <i class="bi bi-pencil-square me-2"></i>Müşteri Bilgileri
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <?= csrfField() ?>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="company_name" class="form-label">
                        Firma Adı <span style="color: #f87171;">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="company_name" 
                        name="company_name" 
                        required
                        value="<?= clean($customer['company_name']) ?>"
                        class="form-control"
                        placeholder="Firma adını girin"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="tax_number" class="form-label">Vergi Numarası</label>
                    <input 
                        type="text" 
                        id="tax_number" 
                        name="tax_number"
                        value="<?= clean($customer['tax_number']) ?>"
                        class="form-control"
                        placeholder="Vergi numarasını girin"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="province" class="form-label">İl</label>
                    <input 
                        type="text" 
                        id="province" 
                        name="province"
                        value="<?= clean($customer['province']) ?>"
                        class="form-control"
                        placeholder="İl"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="district" class="form-label">İlçe</label>
                    <input 
                        type="text" 
                        id="district" 
                        name="district"
                        value="<?= clean($customer['district']) ?>"
                        class="form-control"
                        placeholder="İlçe"
                    >
                </div>
                
                <div class="col-12 mb-3">
                    <label for="address" class="form-label">Açık Adres</label>
                    <textarea 
                        id="address" 
                        name="address" 
                        rows="3"
                        class="form-control"
                        placeholder="Açık adresi girin"
                    ><?= clean($customer['address']) ?></textarea>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="phone" class="form-label">Telefon</label>
                    <input 
                        type="text" 
                        id="phone" 
                        name="phone"
                        value="<?= clean($customer['phone']) ?>"
                        class="form-control"
                        placeholder="+90 (___) ___ __ __"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label">E-posta</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email"
                        value="<?= clean($customer['email']) ?>"
                        class="form-control"
                        placeholder="ornek@firma.com"
                    >
                </div>
                
                <div class="col-12 mb-4">
                    <label class="form-label" style="margin-bottom: 12px;">Durum</label>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 12px 20px; background: var(--bg-input); border-radius: 10px; border: 1px solid var(--border-color);">
                            <input 
                                type="checkbox" 
                                name="is_active" 
                                value="1" 
                                <?= $customer['is_active'] ? 'checked' : '' ?>
                                style="width: 18px; height: 18px; accent-color: var(--accent-primary);"
                            >
                            <span>Aktif</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; justify-content: flex-end; gap: 12px; padding-top: 16px; border-top: 1px solid var(--border-color);">
                <a href="<?= adminUrl('customers.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
                    <i class="bi bi-x-lg me-2"></i>İptal
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-2"></i>Güncelle
                </button>
            </div>
        </form>
    </div>
</div>
