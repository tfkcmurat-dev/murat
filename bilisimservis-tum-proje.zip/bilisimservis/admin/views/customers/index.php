<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Müşteriler</h1>
        <p>Teklif göndereceğiniz müşterileri yönetin.</p>
    </div>
    <a href="<?= adminUrl('customers.php?action=create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Yeni Müşteri Ekle
    </a>
</div>

<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Firma Adı</th>
                    <th>İl/İlçe</th>
                    <th>Telefon</th>
                    <th>E-posta</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($customers)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-people" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz müşteri bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td>
                                <div style="font-weight: 600;"><?= clean($customer['company_name']) ?></div>
                                <?php if (!empty($customer['tax_number'])): ?>
                                    <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">
                                        Vergi No: <?= clean($customer['tax_number']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="color: var(--text-secondary);">
                                <?= clean($customer['province']) ?> / <?= clean($customer['district']) ?>
                            </td>
                            <td>
                                <a href="tel:<?= clean($customer['phone']) ?>" style="color: var(--accent-secondary);">
                                    <?= clean($customer['phone']) ?>
                                </a>
                            </td>
                            <td>
                                <a href="mailto:<?= clean($customer['email']) ?>" style="color: var(--text-secondary); font-size: 0.9rem;">
                                    <?= clean($customer['email']) ?>
                                </a>
                            </td>
                            <td>
                                <?php if ($customer['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge" style="background: rgba(107, 114, 128, 0.2); color: #9ca3af;">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                    <a href="<?= adminUrl('customers.php?action=edit&id=' . $customer['id']) ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Düzenle
                                    </a>
                                    <a href="<?= adminUrl('customers.php?action=delete&id=' . $customer['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);"
                                       onclick="return confirm('Bu müşteriyi silmek istediğinize emin misiniz?')">
                                        Sil
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
