<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Teklif Hizmetleri</h1>
        <p>Teklif sisteminde kullanılacak hizmetleri yönetin.</p>
    </div>
    <a href="<?= adminUrl('services.php?action=create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Yeni Hizmet Ekle
    </a>
</div>

<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Hizmet Adı</th>
                    <th>Açıklama</th>
                    <th>Varsayılan Fiyat</th>
                    <th>KDV Oranı</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($services)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-calculator" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz hizmet bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($services as $service): ?>
                        <tr>
                            <td style="font-weight: 600;"><?= clean($service['name']) ?></td>
                            <td style="color: var(--text-secondary); font-size: 0.9rem;">
                                <?= clean(mb_substr($service['description'] ?? '', 0, 50)) ?><?= mb_strlen($service['description'] ?? '') > 50 ? '...' : '' ?>
                            </td>
                            <td>
                                <span style="color: var(--accent-secondary); font-weight: 600;">
                                    <?= formatMoney($service['default_price']) ?>
                                </span>
                            </td>
                            <td>
                                <span style="background: var(--bg-input); padding: 4px 10px; border-radius: 6px; font-size: 0.85rem;">
                                    %<?= number_format($service['tax_rate'], 2) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($service['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge" style="background: rgba(107, 114, 128, 0.2); color: #9ca3af;">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                    <a href="<?= adminUrl('services.php?action=toggle&id=' . $service['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                                        <?= $service['is_active'] ? 'Pasif Yap' : 'Aktif Yap' ?>
                                    </a>
                                    <a href="<?= adminUrl('services.php?action=edit&id=' . $service['id']) ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Düzenle
                                    </a>
                                    <a href="<?= adminUrl('services.php?action=delete&id=' . $service['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);"
                                       onclick="return confirm('Bu hizmeti silmek istediğinize emin misiniz?')">
                                        Sil
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
