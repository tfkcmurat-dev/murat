<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Yeni Hizmet Ekle</h1>
        <p>Teklif sistemi için yeni hizmet oluşturun.</p>
    </div>
    <a href="<?= adminUrl('services.php') ?>" class="btn btn-outline-primary">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<div class="card">
    <div class="card-header bg-success">
        <i class="bi bi-plus-circle me-2"></i>Hizmet Bilgileri
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <?= csrfField() ?>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label">
                        Hizmet Adı <span style="color: #f87171;">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name" 
                        required
                        class="form-control"
                        placeholder="Hizmet adını girin"
                    >
                </div>
                
                <div class="col-md-3 mb-3">
                    <label for="default_price" class="form-label">Varsayılan Fiyat (₺)</label>
                    <input 
                        type="number" 
                        id="default_price" 
                        name="default_price" 
                        step="0.01"
                        value="0.00"
                        class="form-control"
                        placeholder="0.00"
                    >
                </div>
                
                <div class="col-md-3 mb-3">
                    <label for="tax_rate" class="form-label">KDV Oranı (%)</label>
                    <input 
                        type="number" 
                        id="tax_rate" 
                        name="tax_rate" 
                        step="0.01"
                        value="18.00"
                        class="form-control"
                        placeholder="18.00"
                    >
                </div>
                
                <div class="col-12 mb-3">
                    <label for="description" class="form-label">Açıklama</label>
                    <textarea 
                        id="description" 
                        name="description" 
                        rows="4"
                        class="form-control"
                        placeholder="Hizmet açıklamasını girin"
                    ></textarea>
                </div>
                
                <div class="col-12 mb-4">
                    <label class="form-label" style="margin-bottom: 12px;">Durum</label>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 12px 20px; background: var(--bg-input); border-radius: 10px; border: 1px solid var(--border-color);">
                            <input 
                                type="checkbox" 
                                name="is_active" 
                                value="1" 
                                checked
                                style="width: 18px; height: 18px; accent-color: var(--accent-primary);"
                            >
                            <span>Aktif</span>
                        </label>
                        <span style="color: var(--text-muted); font-size: 0.85rem;">
                            Aktif hizmetler teklif oluştururken seçilebilir.
                        </span>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; justify-content: flex-end; gap: 12px; padding-top: 16px; border-top: 1px solid var(--border-color);">
                <a href="<?= adminUrl('services.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
                    <i class="bi bi-x-lg me-2"></i>İptal
                </a>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-check-lg me-2"></i>Kaydet
                </button>
            </div>
        </form>
    </div>
</div>
