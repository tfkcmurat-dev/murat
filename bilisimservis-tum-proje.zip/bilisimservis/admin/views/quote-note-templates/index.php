<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Teklif Not Şablonları</h1>
        <p>Tekliflerde kullanılacak hazır not şablonlarını yönetin.</p>
    </div>
    <a href="<?= adminUrl('quote-note-templates.php?action=create') ?>" class="btn btn-success">
        <i class="bi bi-plus-lg me-2"></i>Yeni Şablon
    </a>
</div>

<!-- Şablon Listesi -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-file-text me-2"></i>
        Şablonlar
    </div>
    <div class="card-body" style="padding: 0;">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 60px;">Sıra</th>
                    <th>Başlık</th>
                    <th>İçerik Önizleme</th>
                    <th style="text-align: center;">Durum</th>
                    <th style="text-align: center;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($templates)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                            Henüz şablon eklenmemiş.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($templates as $template): ?>
                        <tr>
                            <td style="text-align: center; color: var(--text-muted);">
                                <?= $template['sort_order'] ?>
                            </td>
                            <td>
                                <strong><?= clean($template['title']) ?></strong>
                            </td>
                            <td style="color: var(--text-secondary); max-width: 400px;">
                                <span style="display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= clean($template['content']) ?>">
                                    <?= clean(mb_substr($template['content'], 0, 100)) ?><?= mb_strlen($template['content']) > 100 ? '...' : '' ?>
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <?php if ($template['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <div class="d-flex gap-2 justify-content-center">
                                    <a href="<?= adminUrl('quote-note-templates.php?action=edit&id=' . $template['id']) ?>" class="btn btn-sm btn-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="<?= adminUrl('quote-note-templates.php?action=toggle&id=' . $template['id']) ?>" class="btn btn-sm" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                                        <i class="bi bi-<?= $template['is_active'] ? 'pause' : 'play' ?>-fill"></i>
                                    </a>
                                    <a href="<?= adminUrl('quote-note-templates.php?action=delete&id=' . $template['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu şablonu silmek istediğinize emin misiniz?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="alert alert-info" style="margin-top: 24px;">
    <i class="bi bi-info-circle me-2"></i>
    Bu şablonlar, teklif oluştururken veya düzenlerken "Müşteri Notu" alanında kullanılabilir. Hazır şablonlar sayesinde aynı metinleri tekrar tekrar yazmak zorunda kalmazsınız.
</div>
