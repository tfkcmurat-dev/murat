<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1><?= $template ? 'Şablon Düzenle' : 'Yeni Şablon Oluştur' ?></h1>
        <p><?= $template ? clean($template['title']) : 'Yeni not şablonu ekleyin.' ?></p>
    </div>
    <a href="<?= adminUrl('quote-note-templates.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="">
    <?= csrfField() ?>
    
    <div class="card">
        <div class="card-header bg-primary">
            <i class="bi bi-file-text me-2"></i>
            Şablon Bilgileri
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label class="form-label">
                        Şablon Başlığı <span style="color: #f87171;">*</span>
                    </label>
                    <input type="text" name="title" class="form-control" value="<?= clean($template['title'] ?? '') ?>" placeholder="Örn: Ödeme Koşulları" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Sıra No</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= $template['sort_order'] ?? 0 ?>">
                    <small style="color: var(--text-muted);">Küçük numara önce gösterilir.</small>
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label">
                        Şablon İçeriği <span style="color: #f87171;">*</span>
                    </label>
                    <textarea name="content" class="form-control" rows="6" placeholder="Şablon içeriğini buraya yazın..." required><?= clean($template['content'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="is_active" value="1" <?= ($template['is_active'] ?? 1) ? 'checked' : '' ?> style="width: 20px; height: 20px;">
                        <span>Şablon Aktif</span>
                    </label>
                    <small style="color: var(--text-muted);">Pasif şablonlar teklif formunda gösterilmez.</small>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= adminUrl('quote-note-templates.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
            İptal
        </a>
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="bi bi-check-lg me-2"></i><?= $template ? 'Güncelle' : 'Oluştur' ?>
        </button>
    </div>
</form>
