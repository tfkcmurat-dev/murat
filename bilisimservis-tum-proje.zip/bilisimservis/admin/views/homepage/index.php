<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Anasayfa Yönetimi</h1>
            <p class="text-muted mb-0">Anasayfadaki tüm içerikleri buradan düzenleyebilirsiniz.</p>
        </div>
    </div>

    <?php if ($flash = getFlash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= generateCsrfToken() ?>">
        
        <!-- Hero Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-house me-2"></i>Hero (Slider) Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Badge Metni</label>
                        <input type="text" name="settings[hero_badge_text]" class="form-control" value="<?= clean($settings['hero_badge_text']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık Satır 1</label>
                        <input type="text" name="settings[hero_title_line1]" class="form-control" value="<?= clean($settings['hero_title_line1']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık Satır 3</label>
                        <input type="text" name="settings[hero_title_line3]" class="form-control" value="<?= clean($settings['hero_title_line3']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[hero_subtitle]" class="form-control" rows="2"><?= clean($settings['hero_subtitle']) ?></textarea>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Dönen Yazılar <small class="text-muted">(Her satıra bir yazı)</small></label>
                        <textarea name="settings[hero_rotating_texts]" class="form-control" rows="8"><?= clean($settings['hero_rotating_texts']) ?></textarea>
                    </div>
                </div>
                
                <h6 class="border-bottom pb-2 mb-3">Hero İstatistikler</h6>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 1 - Sayı</label>
                        <input type="text" name="settings[hero_stat1_number]" class="form-control" value="<?= clean($settings['hero_stat1_number']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 1 - Etiket</label>
                        <input type="text" name="settings[hero_stat1_label]" class="form-control" value="<?= clean($settings['hero_stat1_label']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 2 - Sayı</label>
                        <input type="text" name="settings[hero_stat2_number]" class="form-control" value="<?= clean($settings['hero_stat2_number']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 2 - Etiket</label>
                        <input type="text" name="settings[hero_stat2_label]" class="form-control" value="<?= clean($settings['hero_stat2_label']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 3 - Sayı</label>
                        <input type="text" name="settings[hero_stat3_number]" class="form-control" value="<?= clean($settings['hero_stat3_number']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">İstatistik 3 - Etiket</label>
                        <input type="text" name="settings[hero_stat3_label]" class="form-control" value="<?= clean($settings['hero_stat3_label']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Services Section -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-grid me-2"></i>Hizmetler Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[services_badge]" class="form-control" value="<?= clean($settings['services_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[services_title]" class="form-control" value="<?= clean($settings['services_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[services_subtitle]" class="form-control" rows="2"><?= clean($settings['services_subtitle']) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Why Choose Us Section -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-star me-2"></i>Neden Bizi Seçmelisiniz Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[why_badge]" class="form-control" value="<?= clean($settings['why_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[why_title]" class="form-control" value="<?= clean($settings['why_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[why_subtitle]" class="form-control" rows="2"><?= clean($settings['why_subtitle']) ?></textarea>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-4">Özellikler</h6>
                
                <?php for($i = 1; $i <= 4; $i++): ?>
                <div class="row mb-3 pb-3 border-bottom">
                    <div class="col-12 mb-2">
                        <strong>Özellik <?= $i ?></strong>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[feature<?= $i ?>_title]" class="form-control" value="<?= clean($settings['feature' . $i . '_title']) ?>">
                    </div>
                    <div class="col-md-6 mb-2">
                        <label class="form-label">Açıklama</label>
                        <input type="text" name="settings[feature<?= $i ?>_desc]" class="form-control" value="<?= clean($settings['feature' . $i . '_desc']) ?>">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label class="form-label">Highlight Sayı</label>
                        <input type="text" name="settings[feature<?= $i ?>_highlight_num]" class="form-control" value="<?= clean($settings['feature' . $i . '_highlight_num']) ?>">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label class="form-label">Highlight Metin</label>
                        <input type="text" name="settings[feature<?= $i ?>_highlight_text]" class="form-control" value="<?= clean($settings['feature' . $i . '_highlight_text']) ?>">
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i>Rakamlarla Biz Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[stats_badge]" class="form-control" value="<?= clean($settings['stats_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[stats_title]" class="form-control" value="<?= clean($settings['stats_title']) ?>">
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-3">İstatistikler</h6>
                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Stat <?= $i ?> - Sayı</label>
                        <input type="text" name="settings[stat<?= $i ?>_number]" class="form-control" value="<?= clean($settings['stat' . $i . '_number']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Stat <?= $i ?> - Etiket</label>
                        <input type="text" name="settings[stat<?= $i ?>_label]" class="form-control" value="<?= clean($settings['stat' . $i . '_label']) ?>">
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- Process Section -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                <h5 class="mb-0"><i class="bi bi-diagram-3 me-2"></i>Süreç Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[process_badge]" class="form-control" value="<?= clean($settings['process_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[process_title]" class="form-control" value="<?= clean($settings['process_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[process_subtitle]" class="form-control" rows="2"><?= clean($settings['process_subtitle']) ?></textarea>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-3">Adımlar</h6>
                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-header"><strong>Adım <?= $i ?></strong></div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="settings[process<?= $i ?>_title]" class="form-control" value="<?= clean($settings['process' . $i . '_title']) ?>">
                                </div>
                                <div>
                                    <label class="form-label">Açıklama</label>
                                    <textarea name="settings[process<?= $i ?>_desc]" class="form-control" rows="2"><?= clean($settings['process' . $i . '_desc']) ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- CTA Section -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="bi bi-megaphone me-2"></i>CTA (Çağrı) Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[cta_badge]" class="form-control" value="<?= clean($settings['cta_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[cta_title]" class="form-control" value="<?= clean($settings['cta_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[cta_subtitle]" class="form-control" rows="2"><?= clean($settings['cta_subtitle']) ?></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Buton 1 Metni</label>
                        <input type="text" name="settings[cta_button1_text]" class="form-control" value="<?= clean($settings['cta_button1_text']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Buton 2 Metni</label>
                        <input type="text" name="settings[cta_button2_text]" class="form-control" value="<?= clean($settings['cta_button2_text']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Partners Section -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="bi bi-building me-2"></i>Referanslar Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[partners_badge]" class="form-control" value="<?= clean($settings['partners_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[partners_title]" class="form-control" value="<?= clean($settings['partners_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[partners_subtitle]" class="form-control" rows="2"><?= clean($settings['partners_subtitle']) ?></textarea>
                    </div>
                </div>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Referans logolarını <a href="<?= adminUrl('references.php') ?>">Referanslar</a> sayfasından yönetebilirsiniz.
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <div class="d-flex justify-content-end gap-2 mb-4">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check-lg me-2"></i>Değişiklikleri Kaydet
            </button>
        </div>
    </form>
</div>
