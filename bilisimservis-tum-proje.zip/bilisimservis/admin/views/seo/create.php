<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Yeni SEO Kaydı</h1>
        <p>Yeni bir sayfa için SEO ayarları oluşturun.</p>
    </div>
    <a href="<?= adminUrl('seo.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="<?= adminUrl('seo.php?action=create') ?>">
    <?= csrfField() ?>
    
    <div class="row">
        <div class="col-lg-8">
            <!-- Sayfa Bilgisi -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-file-earmark me-2"></i>Sayfa Bilgisi
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="page_slug" class="form-label">Sayfa Slug <span class="text-danger">*</span></label>
                        <input 
                            type="text" 
                            id="page_slug" 
                            name="page_slug" 
                            class="form-control"
                            required
                            placeholder="ornek-sayfa"
                        >
                        <small class="text-muted">URL'deki sayfa adı (örn: hakkimizda, hizmetler, blog)</small>
                    </div>
                </div>
            </div>
            
            <!-- Meta Tags -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-code-slash me-2"></i>Meta Etiketleri
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="meta_title" class="form-label">Meta Title</label>
                        <input 
                            type="text" 
                            id="meta_title" 
                            name="meta_title" 
                            class="form-control"
                            maxlength="255"
                        >
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_description" class="form-label">Meta Description</label>
                        <textarea 
                            id="meta_description" 
                            name="meta_description" 
                            class="form-control" 
                            rows="3"
                        ></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_keywords" class="form-label">Meta Keywords</label>
                        <input 
                            type="text" 
                            id="meta_keywords" 
                            name="meta_keywords" 
                            class="form-control"
                        >
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <!-- Robots -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-robot me-2"></i>Robots
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="robots" class="form-label">Robots Meta Tag</label>
                        <select id="robots" name="robots" class="form-control">
                            <option value="index, follow" selected>index, follow</option>
                            <option value="index, nofollow">index, nofollow</option>
                            <option value="noindex, follow">noindex, follow</option>
                            <option value="noindex, nofollow">noindex, nofollow</option>
                        </select>
                    </div>
                    
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" checked>
                        <label class="form-check-label" for="is_active">SEO Aktif</label>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="bi bi-plus-lg me-2"></i>Oluştur
            </button>
        </div>
    </div>
</form>
