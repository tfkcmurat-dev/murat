<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Genel SEO Ayarları</h1>
        <p>Site geneli SEO ve analytics ayarlarını yapılandırın.</p>
    </div>
    <a href="<?= adminUrl('seo.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="<?= adminUrl('seo.php?action=settings') ?>">
    <?= csrfField() ?>
    
    <div class="row">
        <div class="col-lg-8">
            <!-- Google Integration -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-google me-2"></i>Google Entegrasyonu
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="google_analytics_id" class="form-label">Google Analytics ID</label>
                        <input 
                            type="text" 
                            id="google_analytics_id" 
                            name="google_analytics_id" 
                            class="form-control"
                            value="<?= clean(getThemeSetting('google_analytics_id', '')) ?>"
                            placeholder="G-XXXXXXXXXX veya UA-XXXXXXXX-X"
                        >
                        <small class="text-muted">Google Analytics 4 veya Universal Analytics takip kodu</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="google_search_console" class="form-label">Google Search Console Doğrulama</label>
                        <input 
                            type="text" 
                            id="google_search_console" 
                            name="google_search_console" 
                            class="form-control"
                            value="<?= clean(getThemeSetting('google_search_console', '')) ?>"
                            placeholder="google-site-verification meta tag içeriği"
                        >
                        <small class="text-muted">Search Console'dan aldığınız doğrulama kodu</small>
                    </div>
                </div>
            </div>
            
            <!-- Sitemap Settings -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-diagram-3 me-2"></i>Sitemap Ayarları
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input 
                                class="form-check-input" 
                                type="checkbox" 
                                id="sitemap_enabled" 
                                name="sitemap_enabled"
                                <?= getThemeSetting('sitemap_enabled', '1') == '1' ? 'checked' : '' ?>
                            >
                            <label class="form-check-label" for="sitemap_enabled">Sitemap Aktif</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check form-switch mb-2">
                                <input 
                                    class="form-check-input" 
                                    type="checkbox" 
                                    id="sitemap_include_services" 
                                    name="sitemap_include_services"
                                    <?= getThemeSetting('sitemap_include_services', '1') == '1' ? 'checked' : '' ?>
                                >
                                <label class="form-check-label" for="sitemap_include_services">Hizmetleri Dahil Et</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check form-switch mb-2">
                                <input 
                                    class="form-check-input" 
                                    type="checkbox" 
                                    id="sitemap_include_blog" 
                                    name="sitemap_include_blog"
                                    <?= getThemeSetting('sitemap_include_blog', '1') == '1' ? 'checked' : '' ?>
                                >
                                <label class="form-check-label" for="sitemap_include_blog">Blog Yazılarını Dahil Et</label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3" style="margin-top: 16px;">
                        <label for="sitemap_changefreq" class="form-label">Güncelleme Sıklığı</label>
                        <select id="sitemap_changefreq" name="sitemap_changefreq" class="form-control">
                            <option value="always" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'always' ? 'selected' : '' ?>>Her Zaman</option>
                            <option value="hourly" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'hourly' ? 'selected' : '' ?>>Saatlik</option>
                            <option value="daily" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'daily' ? 'selected' : '' ?>>Günlük</option>
                            <option value="weekly" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'weekly' ? 'selected' : '' ?>>Haftalık</option>
                            <option value="monthly" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'monthly' ? 'selected' : '' ?>>Aylık</option>
                            <option value="yearly" <?= getThemeSetting('sitemap_changefreq', 'weekly') == 'yearly' ? 'selected' : '' ?>>Yıllık</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <!-- Quick Links -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-link-45deg me-2"></i>Hızlı Bağlantılar
                </div>
                <div class="card-body">
                    <a href="<?= url('sitemap.xml') ?>" target="_blank" class="btn btn-outline-primary" style="width: 100%; margin-bottom: 8px;">
                        <i class="bi bi-diagram-3 me-2"></i>Sitemap.xml
                    </a>
                    <a href="<?= url('robots.txt') ?>" target="_blank" class="btn btn-outline-primary" style="width: 100%; margin-bottom: 8px;">
                        <i class="bi bi-robot me-2"></i>Robots.txt
                    </a>
                    <a href="https://search.google.com/search-console" target="_blank" class="btn btn-outline-primary" style="width: 100%;">
                        <i class="bi bi-google me-2"></i>Search Console
                    </a>
                </div>
            </div>
            
            <!-- Info -->
            <div class="card" style="margin-bottom: 24px; background: rgba(59, 130, 246, 0.1); border-color: rgba(59, 130, 246, 0.3);">
                <div class="card-body">
                    <h6 style="color: #3b82f6; margin-bottom: 12px;">
                        <i class="bi bi-info-circle me-2"></i>Search Console Kayıt
                    </h6>
                    <ol style="color: var(--text-secondary); font-size: 0.9rem; padding-left: 20px; margin: 0;">
                        <li style="margin-bottom: 8px;">Search Console'a gidin</li>
                        <li style="margin-bottom: 8px;">Mülk ekle > URL öneki seçin</li>
                        <li style="margin-bottom: 8px;">Sitenizin URL'sini girin</li>
                        <li style="margin-bottom: 8px;">HTML etiketi doğrulama yöntemini seçin</li>
                        <li style="margin-bottom: 8px;">Meta tag içeriğini yukarıya yapıştırın</li>
                        <li>Sitemap URL'ini ekleyin: <?= url('sitemap.xml') ?></li>
                    </ol>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="bi bi-check-lg me-2"></i>Kaydet
            </button>
        </div>
    </div>
</form>
