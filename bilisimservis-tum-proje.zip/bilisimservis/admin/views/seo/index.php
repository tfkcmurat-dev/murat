<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>SEO Ayarları</h1>
        <p>Sayfa bazlı meta etiketleri ve SEO ayarlarını yönetin.</p>
    </div>
    <div style="display: flex; gap: 12px;">
        <a href="<?= adminUrl('seo.php?action=settings') ?>" class="btn" style="background: rgba(59, 130, 246, 0.15); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.3);">
            <i class="bi bi-gear me-2"></i>Genel Ayarlar
        </a>
        <a href="<?= adminUrl('seo.php?action=create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-2"></i>Yeni Sayfa Ekle
        </a>
    </div>
</div>

<!-- Quick Links -->
<div class="row" style="margin-bottom: 24px;">
    <div class="col-md-4">
        <a href="<?= url('sitemap.xml') ?>" target="_blank" class="card" style="text-decoration: none; display: block; transition: all 0.3s;">
            <div class="card-body" style="display: flex; align-items: center; gap: 16px;">
                <div style="width: 48px; height: 48px; background: rgba(16, 185, 129, 0.15); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-diagram-3" style="font-size: 1.5rem; color: #10b981;"></i>
                </div>
                <div>
                    <h5 style="margin: 0; font-weight: 600;">Sitemap.xml</h5>
                    <p style="margin: 0; font-size: 0.85rem; color: var(--text-muted);">Sitemap dosyasını görüntüle</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?= url('robots.txt') ?>" target="_blank" class="card" style="text-decoration: none; display: block; transition: all 0.3s;">
            <div class="card-body" style="display: flex; align-items: center; gap: 16px;">
                <div style="width: 48px; height: 48px; background: rgba(245, 158, 11, 0.15); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-robot" style="font-size: 1.5rem; color: #f59e0b;"></i>
                </div>
                <div>
                    <h5 style="margin: 0; font-weight: 600;">Robots.txt</h5>
                    <p style="margin: 0; font-size: 0.85rem; color: var(--text-muted);">Robots dosyasını görüntüle</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="https://search.google.com/search-console" target="_blank" class="card" style="text-decoration: none; display: block; transition: all 0.3s;">
            <div class="card-body" style="display: flex; align-items: center; gap: 16px;">
                <div style="width: 48px; height: 48px; background: rgba(239, 68, 68, 0.15); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-google" style="font-size: 1.5rem; color: #ef4444;"></i>
                </div>
                <div>
                    <h5 style="margin: 0; font-weight: 600;">Search Console</h5>
                    <p style="margin: 0; font-size: 0.85rem; color: var(--text-muted);">Google Search Console</p>
                </div>
            </div>
        </a>
    </div>
</div>

<!-- Pages List -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-search me-2"></i>Sayfa SEO Ayarları
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Sayfa</th>
                    <th>Meta Title</th>
                    <th>Meta Description</th>
                    <th>Robots</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pages)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-search" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz SEO kaydı bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($pages as $page): ?>
                        <tr>
                            <td>
                                <span style="font-weight: 600; color: var(--accent-secondary);">
                                    <?= clean($page['page_slug']) ?>
                                </span>
                            </td>
                            <td style="max-width: 200px;">
                                <?php if (!empty($page['meta_title'])): ?>
                                    <span style="color: var(--text-secondary); font-size: 0.9rem;" title="<?= clean($page['meta_title']) ?>">
                                        <?= mb_substr(clean($page['meta_title']), 0, 40) ?><?= mb_strlen($page['meta_title']) > 40 ? '...' : '' ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted); font-style: italic;">Ayarlanmamış</span>
                                <?php endif; ?>
                            </td>
                            <td style="max-width: 250px;">
                                <?php if (!empty($page['meta_description'])): ?>
                                    <span style="color: var(--text-muted); font-size: 0.85rem;" title="<?= clean($page['meta_description']) ?>">
                                        <?= mb_substr(clean($page['meta_description']), 0, 50) ?><?= mb_strlen($page['meta_description']) > 50 ? '...' : '' ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted); font-style: italic;">Ayarlanmamış</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?= $page['robots'] == 'noindex, nofollow' ? 'badge-danger' : 'badge-success' ?>">
                                    <?= clean($page['robots'] ?? 'index, follow') ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($page['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <a href="<?= adminUrl('seo.php?action=edit&id=' . $page['id']) ?>" 
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- SEO Tips -->
<div class="card" style="margin-top: 24px;">
    <div class="card-header">
        <i class="bi bi-lightbulb me-2"></i>SEO İpuçları
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h6 style="color: var(--accent-secondary); margin-bottom: 12px;">Meta Title</h6>
                <ul style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 20px; padding-left: 20px;">
                    <li>50-60 karakter arasında tutun</li>
                    <li>Ana anahtar kelimeyi başta kullanın</li>
                    <li>Her sayfa için benzersiz olsun</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6 style="color: var(--accent-secondary); margin-bottom: 12px;">Meta Description</h6>
                <ul style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 20px; padding-left: 20px;">
                    <li>150-160 karakter arasında tutun</li>
                    <li>Sayfanın içeriğini özetleyin</li>
                    <li>Harekete geçirici ifadeler kullanın</li>
                </ul>
            </div>
        </div>
    </div>
</div>
