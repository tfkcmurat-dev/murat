<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>SEO Düzenle</h1>
        <p>Sayfa: <strong><?= clean($seo['page_slug']) ?></strong></p>
    </div>
    <a href="<?= adminUrl('seo.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="<?= adminUrl('seo.php?action=edit&id=' . $seo['id']) ?>">
    <?= csrfField() ?>
    
    <div class="row">
        <!-- Sol Kolon - Ana SEO -->
        <div class="col-lg-8">
            <!-- Meta Tags -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-code-slash me-2"></i>Meta Etiketleri
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="meta_title" class="form-label">
                            Meta Title
                            <small class="text-muted">(50-60 karakter önerilir)</small>
                        </label>
                        <input 
                            type="text" 
                            id="meta_title" 
                            name="meta_title" 
                            class="form-control"
                            value="<?= clean($seo['meta_title'] ?? '') ?>"
                            maxlength="255"
                            oninput="updateCharCount(this, 'titleCount', 60)"
                        >
                        <small class="text-muted">
                            <span id="titleCount"><?= strlen($seo['meta_title'] ?? '') ?></span>/60 karakter
                        </small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_description" class="form-label">
                            Meta Description
                            <small class="text-muted">(150-160 karakter önerilir)</small>
                        </label>
                        <textarea 
                            id="meta_description" 
                            name="meta_description" 
                            class="form-control" 
                            rows="3"
                            oninput="updateCharCount(this, 'descCount', 160)"
                        ><?= clean($seo['meta_description'] ?? '') ?></textarea>
                        <small class="text-muted">
                            <span id="descCount"><?= strlen($seo['meta_description'] ?? '') ?></span>/160 karakter
                        </small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_keywords" class="form-label">
                            Meta Keywords
                            <small class="text-muted">(virgülle ayırın)</small>
                        </label>
                        <input 
                            type="text" 
                            id="meta_keywords" 
                            name="meta_keywords" 
                            class="form-control"
                            value="<?= clean($seo['meta_keywords'] ?? '') ?>"
                            placeholder="bilgisayar tamiri, teknik servis, laptop onarım"
                        >
                    </div>
                </div>
            </div>
            
            <!-- Open Graph -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-share me-2"></i>Open Graph (Sosyal Medya)
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="og_title" class="form-label">OG Title</label>
                        <input 
                            type="text" 
                            id="og_title" 
                            name="og_title" 
                            class="form-control"
                            value="<?= clean($seo['og_title'] ?? '') ?>"
                            placeholder="Meta title kullanılır (boş bırakılırsa)"
                        >
                    </div>
                    
                    <div class="mb-3">
                        <label for="og_description" class="form-label">OG Description</label>
                        <textarea 
                            id="og_description" 
                            name="og_description" 
                            class="form-control" 
                            rows="2"
                            placeholder="Meta description kullanılır (boş bırakılırsa)"
                        ><?= clean($seo['og_description'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="og_image" class="form-label">OG Image URL</label>
                        <input 
                            type="url" 
                            id="og_image" 
                            name="og_image" 
                            class="form-control"
                            value="<?= clean($seo['og_image'] ?? '') ?>"
                            placeholder="https://example.com/image.jpg"
                        >
                        <small class="text-muted">Sosyal medyada paylaşıldığında görünecek görsel (1200x630px önerilir)</small>
                    </div>
                </div>
            </div>
            
            <!-- Schema -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-braces me-2"></i>Özel Schema (JSON-LD)
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="custom_schema" class="form-label">JSON-LD Schema</label>
                        <textarea 
                            id="custom_schema" 
                            name="custom_schema" 
                            class="form-control" 
                            rows="8"
                            style="font-family: monospace; font-size: 0.85rem;"
                            placeholder='{"@context": "https://schema.org", "@type": "LocalBusiness", ...}'
                        ><?= clean($seo['custom_schema'] ?? '') ?></textarea>
                        <small class="text-muted">Yapılandırılmış veri için JSON-LD formatında schema</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Sağ Kolon - Ayarlar -->
        <div class="col-lg-4">
            <!-- Durum -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-toggle-on me-2"></i>Durum
                </div>
                <div class="card-body">
                    <div class="form-check form-switch">
                        <input 
                            class="form-check-input" 
                            type="checkbox" 
                            id="is_active" 
                            name="is_active"
                            <?= ($seo['is_active'] ?? 1) ? 'checked' : '' ?>
                        >
                        <label class="form-check-label" for="is_active">SEO Aktif</label>
                    </div>
                </div>
            </div>
            
            <!-- Robots -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-robot me-2"></i>Robots
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="robots" class="form-label">Robots Meta Tag</label>
                        <select id="robots" name="robots" class="form-control">
                            <option value="index, follow" <?= ($seo['robots'] ?? '') == 'index, follow' ? 'selected' : '' ?>>index, follow (Varsayılan)</option>
                            <option value="index, nofollow" <?= ($seo['robots'] ?? '') == 'index, nofollow' ? 'selected' : '' ?>>index, nofollow</option>
                            <option value="noindex, follow" <?= ($seo['robots'] ?? '') == 'noindex, follow' ? 'selected' : '' ?>>noindex, follow</option>
                            <option value="noindex, nofollow" <?= ($seo['robots'] ?? '') == 'noindex, nofollow' ? 'selected' : '' ?>>noindex, nofollow</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <!-- Canonical -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-link-45deg me-2"></i>Canonical URL
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="canonical_url" class="form-label">Canonical URL</label>
                        <input 
                            type="url" 
                            id="canonical_url" 
                            name="canonical_url" 
                            class="form-control"
                            value="<?= clean($seo['canonical_url'] ?? '') ?>"
                            placeholder="https://example.com/sayfa"
                        >
                        <small class="text-muted">Boş bırakılırsa mevcut URL kullanılır</small>
                    </div>
                </div>
            </div>
            
            <!-- Google Preview -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <i class="bi bi-google me-2"></i>Google Önizleme
                </div>
                <div class="card-body" style="background: #fff; border-radius: 8px;">
                    <div id="googlePreview" style="font-family: Arial, sans-serif;">
                        <div style="color: #1a0dab; font-size: 18px; margin-bottom: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" id="previewTitle">
                            <?= clean($seo['meta_title'] ?? 'Sayfa Başlığı') ?>
                        </div>
                        <div style="color: #006621; font-size: 14px; margin-bottom: 3px;">
                            <?= url($seo['page_slug']) ?>
                        </div>
                        <div style="color: #545454; font-size: 13px; line-height: 1.4;" id="previewDesc">
                            <?= clean($seo['meta_description'] ?? 'Sayfa açıklaması burada görünecek...') ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Submit -->
            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="bi bi-check-lg me-2"></i>Kaydet
            </button>
        </div>
    </div>
</form>

<script>
function updateCharCount(input, countId, max) {
    const count = input.value.length;
    const countEl = document.getElementById(countId);
    countEl.textContent = count;
    
    if (count > max) {
        countEl.style.color = '#ef4444';
    } else if (count > max * 0.9) {
        countEl.style.color = '#f59e0b';
    } else {
        countEl.style.color = '';
    }
    
    // Google Preview güncelle
    if (input.id === 'meta_title') {
        document.getElementById('previewTitle').textContent = input.value || 'Sayfa Başlığı';
    }
    if (input.id === 'meta_description') {
        document.getElementById('previewDesc').textContent = input.value || 'Sayfa açıklaması burada görünecek...';
    }
}
</script>
