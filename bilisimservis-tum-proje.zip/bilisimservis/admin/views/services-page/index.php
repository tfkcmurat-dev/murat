<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Hizmetler Sayfası Yönetimi</h1>
            <p class="text-muted mb-0">Hizmetler sayfasındaki içerikleri buradan düzenleyebilirsiniz.</p>
        </div>
        <a href="<?= url('hizmetler') ?>" target="_blank" class="btn btn-outline-primary">
            <i class="bi bi-eye me-2"></i>Sayfayı Görüntüle
        </a>
    </div>

    <?php if ($flash = getFlash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= generateCsrfToken() ?>">
        
        <!-- Hero Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-house me-2"></i>Hero Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[svc_hero_badge]" class="form-control" value="<?= clean($settings['svc_hero_badge']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık Satır 1</label>
                        <input type="text" name="settings[svc_hero_title_line1]" class="form-control" value="<?= clean($settings['svc_hero_title_line1']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Vurgulu Başlık</label>
                        <input type="text" name="settings[svc_hero_title_highlight]" class="form-control" value="<?= clean($settings['svc_hero_title_highlight']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık Satır 3</label>
                        <input type="text" name="settings[svc_hero_title_line3]" class="form-control" value="<?= clean($settings['svc_hero_title_line3']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[svc_hero_subtitle]" class="form-control" rows="2"><?= clean($settings['svc_hero_subtitle']) ?></textarea>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3">Hero İstatistikler</h6>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Stat 1 Etiket (Sayı otomatik)</label>
                        <input type="text" name="settings[svc_stat1_label]" class="form-control" value="<?= clean($settings['svc_stat1_label']) ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat 2 Sayı</label>
                        <input type="text" name="settings[svc_stat2_number]" class="form-control" value="<?= clean($settings['svc_stat2_number']) ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat 2 Etiket</label>
                        <input type="text" name="settings[svc_stat2_label]" class="form-control" value="<?= clean($settings['svc_stat2_label']) ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat 3 Sayı</label>
                        <input type="text" name="settings[svc_stat3_number]" class="form-control" value="<?= clean($settings['svc_stat3_number']) ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat 3 Etiket</label>
                        <input type="text" name="settings[svc_stat3_label]" class="form-control" value="<?= clean($settings['svc_stat3_label']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-funnel me-2"></i>Kategori Filtreleri</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Filtre Etiketi</label>
                        <input type="text" name="settings[svc_filter_label]" class="form-control" value="<?= clean($settings['svc_filter_label']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tümü</label>
                        <input type="text" name="settings[svc_filter_all]" class="form-control" value="<?= clean($settings['svc_filter_all']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Bilgisayar</label>
                        <input type="text" name="settings[svc_filter_computer]" class="form-control" value="<?= clean($settings['svc_filter_computer']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Telefon & Tablet</label>
                        <input type="text" name="settings[svc_filter_mobile]" class="form-control" value="<?= clean($settings['svc_filter_mobile']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Yazıcı</label>
                        <input type="text" name="settings[svc_filter_printer]" class="form-control" value="<?= clean($settings['svc_filter_printer']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Yazılım</label>
                        <input type="text" name="settings[svc_filter_software]" class="form-control" value="<?= clean($settings['svc_filter_software']) ?>">
                    </div>
                </div>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Hizmetleri <a href="<?= adminUrl('site-services.php') ?>">Site Hizmetleri</a> sayfasından yönetebilirsiniz.
                </div>
            </div>
        </div>

        <!-- Process Section -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                <h5 class="mb-0"><i class="bi bi-diagram-3 me-2"></i>Süreç Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[svc_process_badge]" class="form-control" value="<?= clean($settings['svc_process_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[svc_process_title]" class="form-control" value="<?= clean($settings['svc_process_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[svc_process_subtitle]" class="form-control" rows="2"><?= clean($settings['svc_process_subtitle']) ?></textarea>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-3">Adımlar</h6>
                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-header"><strong>Adım <?= $i ?></strong></div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="settings[svc_process<?= $i ?>_title]" class="form-control" value="<?= clean($settings['svc_process' . $i . '_title']) ?>">
                                </div>
                                <div>
                                    <label class="form-label">Açıklama</label>
                                    <textarea name="settings[svc_process<?= $i ?>_desc]" class="form-control" rows="2"><?= clean($settings['svc_process' . $i . '_desc']) ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- CTA Section -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="bi bi-megaphone me-2"></i>CTA Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[svc_cta_title]" class="form-control" value="<?= clean($settings['svc_cta_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[svc_cta_subtitle]" class="form-control" rows="2"><?= clean($settings['svc_cta_subtitle']) ?></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Buton 1</label>
                        <input type="text" name="settings[svc_cta_button1]" class="form-control" value="<?= clean($settings['svc_cta_button1']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Buton 2</label>
                        <input type="text" name="settings[svc_cta_button2]" class="form-control" value="<?= clean($settings['svc_cta_button2']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <div class="d-flex justify-content-end gap-2 mb-4">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check-lg me-2"></i>Değişiklikleri Kaydet
            </button>
        </div>
    </form>
</div>
