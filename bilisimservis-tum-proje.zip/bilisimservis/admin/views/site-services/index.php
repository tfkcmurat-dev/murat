<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Site Hizmetleri</h1>
        <p>Frontend'de gösterilecek hizmetleri yönetin.</p>
    </div>
    <a href="<?= adminUrl('site-services.php?action=create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Yeni Hizmet Ekle
    </a>
</div>

<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Hizmet</th>
                    <th>Alt Başlık</th>
                    <th>Slug</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($services)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz site hizmeti bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php 
                    $iconMap = [
                        'laptop' => 'bi-laptop',
                        'smartphone' => 'bi-phone',
                        'tablet' => 'bi-tablet',
                        'printer' => 'bi-printer',
                        'settings' => 'bi-gear',
                        'users' => 'bi-people'
                    ];
                    foreach ($services as $service): 
                        $iconClass = $iconMap[$service['icon'] ?? 'settings'] ?? 'bi-gear';
                        $slug = $service['slug'] ?? '';
                    ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div style="width: 40px; height: 40px; background: rgba(0, 102, 255, 0.15); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                        <i class="bi <?= $iconClass ?>" style="font-size: 1.2rem; color: var(--accent-secondary);"></i>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;"><?= clean($service['name']) ?></div>
                                        <?php if (!empty($service['description'])): ?>
                                            <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">
                                                <?= clean(mb_substr($service['description'], 0, 50)) ?><?= mb_strlen($service['description']) > 50 ? '...' : '' ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td style="color: var(--text-secondary);"><?= clean($service['subtitle'] ?? '-') ?></td>
                            <td>
                                <?php if ($slug): ?>
                                    <a href="<?= url('hizmet/' . $slug) ?>" target="_blank" style="color: var(--accent-secondary); font-size: 0.85rem;">
                                        /hizmet/<?= clean($slug) ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($service['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge" style="background: rgba(107, 114, 128, 0.2); color: #9ca3af;">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                    <a href="<?= adminUrl('site-services.php?action=toggle&id=' . $service['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                                        <?= $service['is_active'] ? 'Pasif Yap' : 'Aktif Yap' ?>
                                    </a>
                                    <a href="<?= adminUrl('site-services.php?action=edit&id=' . $service['id']) ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Düzenle
                                    </a>
                                    <a href="<?= adminUrl('site-services.php?action=delete&id=' . $service['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);"
                                       onclick="return confirm('Bu hizmeti silmek istediğinize emin misiniz?')">
                                        Sil
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
