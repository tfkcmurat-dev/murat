<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>E-Mail Log Kayıtları</h1>
        <p>Sistemden gönderilen e-postaların geçmişini görüntüleyin.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= adminUrl('email-logs.php?action=clean&days=30') ?>" class="btn" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);" onclick="return confirm('30 günden eski tüm log kayıtları silinecek. Emin misiniz?');">
            <i class="bi bi-trash me-2"></i>Eski Logları Temizle
        </a>
    </div>
</div>

<!-- İstatistikler -->
<div class="stats-grid" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="bi bi-envelope"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['total']) ?></div>
            <div class="stat-label">Toplam</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="bi bi-check-circle"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['sent']) ?></div>
            <div class="stat-label">Başarılı</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">
            <i class="bi bi-x-circle"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['failed']) ?></div>
            <div class="stat-label">Başarısız</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class="bi bi-calendar-check"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['today']) ?></div>
            <div class="stat-label">Bugün</div>
        </div>
    </div>
</div>

<!-- Filtreler -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-body">
        <form method="GET" action="" class="row align-items-center">
            <div class="col-md-2 mb-3">
                <label class="form-label">Durum</label>
                <select name="status" class="form-control">
                    <option value="">Tümü</option>
                    <option value="sent" <?= ($filters['status'] ?? '') == 'sent' ? 'selected' : '' ?>>Başarılı</option>
                    <option value="failed" <?= ($filters['status'] ?? '') == 'failed' ? 'selected' : '' ?>>Başarısız</option>
                    <option value="pending" <?= ($filters['status'] ?? '') == 'pending' ? 'selected' : '' ?>>Beklemede</option>
                </select>
            </div>
            <div class="col-md-2 mb-3">
                <label class="form-label">Başlangıç Tarihi</label>
                <input type="date" name="date_from" class="form-control" value="<?= clean($filters['date_from'] ?? '') ?>">
            </div>
            <div class="col-md-2 mb-3">
                <label class="form-label">Bitiş Tarihi</label>
                <input type="date" name="date_to" class="form-control" value="<?= clean($filters['date_to'] ?? '') ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">Ara</label>
                <input type="text" name="search" class="form-control" placeholder="E-posta veya konu..." value="<?= clean($filters['search'] ?? '') ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">&nbsp;</label>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search me-2"></i>Filtrele
                    </button>
                    <a href="<?= adminUrl('email-logs.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary);">
                        Temizle
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Log Listesi -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div>
            <i class="bi bi-list-ul me-2"></i>
            Log Kayıtları
            <span class="badge badge-info" style="margin-left: 8px;"><?= number_format($totalCount) ?> kayıt</span>
        </div>
        <button type="button" id="deleteSelectedBtn" class="btn btn-sm btn-danger" style="display: none;">
            <i class="bi bi-trash me-2"></i>Seçilenleri Sil
        </button>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 40px;">
                        <input type="checkbox" id="selectAll" style="width: 18px; height: 18px;">
                    </th>
                    <th>Alıcı</th>
                    <th>Konu</th>
                    <th>Şablon</th>
                    <th style="text-align: center;">Durum</th>
                    <th>Tarih</th>
                    <th style="text-align: center;">İşlem</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                            Log kaydı bulunamadı.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="log-checkbox" value="<?= $log['id'] ?>" style="width: 18px; height: 18px;">
                            </td>
                            <td>
                                <div style="font-weight: 500;"><?= clean($log['recipient_email']) ?></div>
                                <?php if ($log['recipient_name']): ?>
                                    <small style="color: var(--text-muted);"><?= clean($log['recipient_name']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td style="max-width: 250px;">
                                <span style="display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= clean($log['subject']) ?>">
                                    <?= clean($log['subject']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($log['template_slug']): ?>
                                    <code style="background: var(--bg-input); padding: 2px 6px; border-radius: 4px; font-size: 0.8rem;">
                                        <?= clean($log['template_slug']) ?>
                                    </code>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php
                                $statusClasses = [
                                    'sent' => 'badge-success',
                                    'failed' => 'badge-danger',
                                    'pending' => 'badge-warning'
                                ];
                                $statusLabels = [
                                    'sent' => 'Gönderildi',
                                    'failed' => 'Başarısız',
                                    'pending' => 'Beklemede'
                                ];
                                ?>
                                <span class="badge <?= $statusClasses[$log['status']] ?? 'badge-warning' ?>">
                                    <?= $statusLabels[$log['status']] ?? $log['status'] ?>
                                </span>
                            </td>
                            <td>
                                <small style="color: var(--text-secondary);">
                                    <?= date('d.m.Y H:i', strtotime($log['created_at'])) ?>
                                </small>
                            </td>
                            <td style="text-align: center;">
                                <div class="d-flex gap-2 justify-content-center">
                                    <button type="button" class="btn btn-sm" onclick="viewLog(<?= $log['id'] ?>)" style="background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.3);">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <a href="<?= adminUrl('email-logs.php?action=delete&id=' . $log['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu log kaydını silmek istediğinize emin misiniz?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Sayfalama -->
<?php if ($totalPages > 1): ?>
<div class="d-flex justify-content-center mt-4 mb-4">
    <div class="d-flex gap-2">
        <?php if ($currentPage > 1): ?>
            <a href="<?= adminUrl('email-logs.php?' . http_build_query(array_merge($_GET, ['page' => $currentPage - 1]))) ?>" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-chevron-left"></i>
            </a>
        <?php endif; ?>
        
        <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="<?= adminUrl('email-logs.php?' . http_build_query(array_merge($_GET, ['page' => $i]))) ?>" class="btn btn-sm <?= $i == $currentPage ? 'btn-primary' : '' ?>" style="<?= $i != $currentPage ? 'background: var(--bg-input); color: var(--text-secondary);' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
        
        <?php if ($currentPage < $totalPages): ?>
            <a href="<?= adminUrl('email-logs.php?' . http_build_query(array_merge($_GET, ['page' => $currentPage + 1]))) ?>" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-chevron-right"></i>
            </a>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<!-- Log Detay Modal -->
<div id="logModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 1000; overflow-y: auto; padding: 40px 20px;">
    <div style="background: var(--bg-card); border-radius: 16px; max-width: 800px; margin: 0 auto; border: 1px solid var(--border-color);">
        <div style="padding: 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; color: var(--text-primary);">Log Detayı</h3>
            <button type="button" onclick="closeLogModal()" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div style="padding: 20px;" id="logModalContent">
            <!-- İçerik AJAX ile yüklenecek -->
        </div>
    </div>
</div>

<script>
const csrfToken = '<?= generateCsrfToken() ?>';
const csrfName = '<?= CSRF_TOKEN_NAME ?>';

// Tümünü seç
document.getElementById('selectAll').addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.log-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
    updateDeleteButton();
});

// Checkbox değişikliği
document.querySelectorAll('.log-checkbox').forEach(cb => {
    cb.addEventListener('change', updateDeleteButton);
});

function updateDeleteButton() {
    const checked = document.querySelectorAll('.log-checkbox:checked').length;
    const btn = document.getElementById('deleteSelectedBtn');
    btn.style.display = checked > 0 ? 'inline-flex' : 'none';
    btn.innerHTML = '<i class="bi bi-trash me-2"></i>Seçilenleri Sil (' + checked + ')';
}

// Toplu silme
document.getElementById('deleteSelectedBtn').addEventListener('click', function() {
    if (!confirm('Seçili log kayıtlarını silmek istediğinize emin misiniz?')) return;
    
    const ids = Array.from(document.querySelectorAll('.log-checkbox:checked')).map(cb => cb.value);
    
    const formData = new FormData();
    formData.append(csrfName, csrfToken);
    ids.forEach(id => formData.append('ids[]', id));
    
    fetch('<?= adminUrl("email-logs.php?action=delete-multiple") ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    });
});

// Log detay görüntüle
function viewLog(id) {
    fetch('<?= adminUrl("email-logs.php?action=view&id=") ?>' + id)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const log = data.log;
                let statusBadge = '';
                if (log.status === 'sent') statusBadge = '<span class="badge badge-success">Gönderildi</span>';
                else if (log.status === 'failed') statusBadge = '<span class="badge badge-danger">Başarısız</span>';
                else statusBadge = '<span class="badge badge-warning">Beklemede</span>';
                
                let html = `
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <strong style="color: var(--text-muted);">Alıcı:</strong><br>
                            ${log.recipient_email}
                            ${log.recipient_name ? '<small style="color: var(--text-muted);"> (' + log.recipient_name + ')</small>' : ''}
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong style="color: var(--text-muted);">Durum:</strong><br>
                            ${statusBadge}
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong style="color: var(--text-muted);">Tarih:</strong><br>
                            ${log.created_at}
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong style="color: var(--text-muted);">Şablon:</strong><br>
                            ${log.template_slug || '-'}
                        </div>
                    </div>
                    <div class="mb-3">
                        <strong style="color: var(--text-muted);">Konu:</strong>
                        <div style="padding: 10px; background: var(--bg-input); border-radius: 8px; margin-top: 4px;">
                            ${log.subject}
                        </div>
                    </div>
                    ${log.error_message ? `
                    <div class="mb-3">
                        <strong style="color: #ef4444;">Hata Mesajı:</strong>
                        <div style="padding: 10px; background: rgba(239, 68, 68, 0.1); border-radius: 8px; margin-top: 4px; color: #f87171;">
                            ${log.error_message}
                        </div>
                    </div>
                    ` : ''}
                    <div>
                        <strong style="color: var(--text-muted);">İçerik:</strong>
                        <div style="padding: 20px; background: white; border-radius: 8px; margin-top: 4px; max-height: 400px; overflow-y: auto;">
                            ${log.body || '<em style="color: #999;">İçerik kaydedilmemiş</em>'}
                        </div>
                    </div>
                `;
                
                document.getElementById('logModalContent').innerHTML = html;
                document.getElementById('logModal').style.display = 'block';
            } else {
                alert(data.message);
            }
        });
}

function closeLogModal() {
    document.getElementById('logModal').style.display = 'none';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeLogModal();
});
</script>
