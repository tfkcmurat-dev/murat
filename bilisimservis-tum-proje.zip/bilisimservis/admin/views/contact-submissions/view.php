<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Form Detayı</h1>
        <p><?= clean($submission['name']) ?> - <?= date('d.m.Y H:i', strtotime($submission['created_at'])) ?></p>
    </div>
    <a href="<?= adminUrl('contact-submissions.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <!-- Gönderen Bilgileri -->
        <div class="card">
            <div class="card-header bg-primary">
                <i class="bi bi-person me-2"></i>
                Gönderen Bilgileri
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" style="color: var(--text-muted);">Ad Soyad</label>
                        <div style="font-weight: 600; font-size: 1.1rem;"><?= clean($submission['name']) ?></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" style="color: var(--text-muted);">E-posta</label>
                        <div>
                            <a href="mailto:<?= clean($submission['email']) ?>" style="color: var(--accent-secondary); text-decoration: none;">
                                <?= clean($submission['email']) ?>
                            </a>
                        </div>
                    </div>
                    <?php if ($submission['phone']): ?>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" style="color: var(--text-muted);">Telefon</label>
                            <div>
                                <a href="tel:<?= clean($submission['phone']) ?>" style="color: var(--accent-secondary); text-decoration: none;">
                                    <?= clean($submission['phone']) ?>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($submission['subject']): ?>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" style="color: var(--text-muted);">Konu</label>
                            <div><?= clean($submission['subject']) ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Mesaj -->
        <div class="card">
            <div class="card-header bg-info">
                <i class="bi bi-chat-text me-2"></i>
                Mesaj
            </div>
            <div class="card-body">
                <div style="white-space: pre-wrap; line-height: 1.7;"><?= clean($submission['message']) ?></div>
            </div>
        </div>

        <!-- Notlar -->
        <div class="card">
            <div class="card-header bg-secondary">
                <i class="bi bi-sticky me-2"></i>
                Notlar
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <?= csrfField() ?>
                    <textarea name="notes" class="form-control" rows="4" placeholder="Bu kayıt hakkında notlarınızı buraya ekleyebilirsiniz..."><?= clean($submission['notes'] ?? '') ?></textarea>
                    <div class="d-flex justify-content-end mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-lg me-2"></i>Notu Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <!-- Durum -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>
                Durum
            </div>
            <div class="card-body">
                <?php
                $statusClasses = [
                    'new' => 'badge-info',
                    'read' => 'badge-warning',
                    'replied' => 'badge-success',
                    'converted' => 'badge-success'
                ];
                $statusLabels = [
                    'new' => 'Yeni',
                    'read' => 'Okundu',
                    'replied' => 'Yanıtlandı',
                    'converted' => 'Dönüştürüldü'
                ];
                ?>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                    <span>Mevcut Durum:</span>
                    <span class="badge <?= $statusClasses[$submission['status']] ?? 'badge-warning' ?>">
                        <?= $statusLabels[$submission['status']] ?? $submission['status'] ?>
                    </span>
                </div>
                
                <label class="form-label" style="color: var(--text-muted);">Durumu Değiştir</label>
                <select id="statusSelect" class="form-control" style="margin-bottom: 12px;">
                    <option value="new" <?= $submission['status'] == 'new' ? 'selected' : '' ?>>Yeni</option>
                    <option value="read" <?= $submission['status'] == 'read' ? 'selected' : '' ?>>Okundu</option>
                    <option value="replied" <?= $submission['status'] == 'replied' ? 'selected' : '' ?>>Yanıtlandı</option>
                    <option value="converted" <?= $submission['status'] == 'converted' ? 'selected' : '' ?>>Dönüştürüldü</option>
                </select>
                <button type="button" id="updateStatusBtn" class="btn btn-primary" style="width: 100%;">
                    <i class="bi bi-check me-2"></i>Durumu Güncelle
                </button>
            </div>
        </div>

        <!-- Hızlı İşlemler -->
        <div class="card">
            <div class="card-header bg-success">
                <i class="bi bi-lightning me-2"></i>
                Hızlı İşlemler
            </div>
            <div class="card-body">
                <?php if (!$submission['customer_id']): ?>
                    <a href="<?= adminUrl('contact-submissions.php?action=convert-customer&id=' . $submission['id']) ?>" class="btn btn-success" style="width: 100%; margin-bottom: 12px;" onclick="return confirm('Bu kaydı müşteriye dönüştürmek istediğinize emin misiniz?');">
                        <i class="bi bi-person-plus me-2"></i>Müşteriye Dönüştür
                    </a>
                <?php else: ?>
                    <a href="<?= adminUrl('customers.php?action=edit&id=' . $submission['customer_id']) ?>" class="btn" style="width: 100%; margin-bottom: 12px; background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3);">
                        <i class="bi bi-person-check me-2"></i>Müşteriyi Görüntüle
                    </a>
                <?php endif; ?>
                
                <a href="<?= adminUrl('contact-submissions.php?action=create-quote&id=' . $submission['id']) ?>" class="btn btn-primary" style="width: 100%; margin-bottom: 12px;">
                    <i class="bi bi-file-earmark-text me-2"></i>Teklif Oluştur
                </a>
                
                <a href="mailto:<?= clean($submission['email']) ?>?subject=Re: <?= clean($submission['subject'] ?? 'İletişim Formunuz') ?>" class="btn" style="width: 100%; background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.3);">
                    <i class="bi bi-reply me-2"></i>E-posta ile Yanıtla
                </a>
            </div>
        </div>

        <!-- Teknik Bilgiler -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-code-slash me-2"></i>
                Teknik Bilgiler
            </div>
            <div class="card-body">
                <div style="margin-bottom: 12px;">
                    <label class="form-label" style="color: var(--text-muted); margin-bottom: 4px;">Gönderim Tarihi</label>
                    <div style="font-size: 0.9rem;"><?= date('d.m.Y H:i:s', strtotime($submission['created_at'])) ?></div>
                </div>
                <?php if ($submission['ip_address']): ?>
                    <div style="margin-bottom: 12px;">
                        <label class="form-label" style="color: var(--text-muted); margin-bottom: 4px;">IP Adresi</label>
                        <div style="font-size: 0.9rem;"><?= clean($submission['ip_address']) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($submission['user_agent']): ?>
                    <div>
                        <label class="form-label" style="color: var(--text-muted); margin-bottom: 4px;">Tarayıcı</label>
                        <div style="font-size: 0.85rem; color: var(--text-secondary); word-break: break-all;"><?= clean(mb_substr($submission['user_agent'], 0, 100)) ?>...</div>
                    </div>
                <?php endif; ?>
                
                <?php if ($submission['customer_id']): ?>
                    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--border-color);">
                        <label class="form-label" style="color: var(--text-muted); margin-bottom: 4px;">Bağlı Müşteri</label>
                        <div>
                            <a href="<?= adminUrl('customers.php?action=edit&id=' . $submission['customer_id']) ?>" style="color: var(--accent-secondary);">
                                <?= $submission['customer_company'] ?? ('Müşteri #' . $submission['customer_id']) ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($submission['quote_id']): ?>
                    <div style="margin-top: 12px;">
                        <label class="form-label" style="color: var(--text-muted); margin-bottom: 4px;">Bağlı Teklif</label>
                        <div>
                            <a href="<?= adminUrl('quotes.php?action=view&id=' . $submission['quote_id']) ?>" style="color: var(--accent-secondary);">
                                <?= $submission['quote_number'] ?? ('Teklif #' . $submission['quote_id']) ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sil -->
        <div class="card" style="border-color: rgba(239, 68, 68, 0.3);">
            <div class="card-header bg-danger">
                <i class="bi bi-exclamation-triangle me-2"></i>
                Tehlikeli Alan
            </div>
            <div class="card-body">
                <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 12px;">
                    Bu kaydı silmek geri alınamaz bir işlemdir.
                </p>
                <a href="<?= adminUrl('contact-submissions.php?action=delete&id=' . $submission['id']) ?>" class="btn btn-danger" style="width: 100%;" onclick="return confirm('Bu kaydı silmek istediğinize emin misiniz? Bu işlem geri alınamaz.');">
                    <i class="bi bi-trash me-2"></i>Kaydı Sil
                </a>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('updateStatusBtn').addEventListener('click', function() {
    const status = document.getElementById('statusSelect').value;
    const btn = this;
    
    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Güncelleniyor...';
    
    const formData = new FormData();
    formData.append('<?= CSRF_TOKEN_NAME ?>', '<?= generateCsrfToken() ?>');
    formData.append('status', status);
    
    fetch('<?= adminUrl("contact-submissions.php?action=update-status&id=" . $submission["id"]) ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        alert('Bir hata oluştu: ' + error.message);
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check me-2"></i>Durumu Güncelle';
    });
});
</script>
