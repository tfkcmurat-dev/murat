<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Form Kayıtları</h1>
        <p>Site üzerinden gelen iletişim formu kayıtları.</p>
    </div>
</div>

<!-- Durum İstatistikleri -->
<div class="stats-grid" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="bi bi-envelope-fill"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($statusCounts['total']) ?></div>
            <div class="stat-label">Toplam</div>
        </div>
    </div>
    <div class="stat-card" style="<?= $statusCounts['new'] > 0 ? 'border-color: rgba(59, 130, 246, 0.5); box-shadow: 0 0 20px rgba(59, 130, 246, 0.2);' : '' ?>">
        <div class="stat-icon blue">
            <i class="bi bi-bell-fill"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($statusCounts['new']) ?></div>
            <div class="stat-label">Yeni</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow">
            <i class="bi bi-eye-fill"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($statusCounts['read']) ?></div>
            <div class="stat-label">Okundu</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="bi bi-check-circle-fill"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($statusCounts['replied'] + $statusCounts['converted']) ?></div>
            <div class="stat-label">İşlendi</div>
        </div>
    </div>
</div>

<!-- Filtreler -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-body">
        <form method="GET" action="" class="row align-items-center">
            <div class="col-md-2 mb-3">
                <label class="form-label">Durum</label>
                <select name="status" class="form-control">
                    <option value="">Tümü</option>
                    <option value="new" <?= ($filters['status'] ?? '') == 'new' ? 'selected' : '' ?>>Yeni</option>
                    <option value="read" <?= ($filters['status'] ?? '') == 'read' ? 'selected' : '' ?>>Okundu</option>
                    <option value="replied" <?= ($filters['status'] ?? '') == 'replied' ? 'selected' : '' ?>>Yanıtlandı</option>
                    <option value="converted" <?= ($filters['status'] ?? '') == 'converted' ? 'selected' : '' ?>>Dönüştürüldü</option>
                </select>
            </div>
            <div class="col-md-2 mb-3">
                <label class="form-label">Başlangıç</label>
                <input type="date" name="date_from" class="form-control" value="<?= clean($filters['date_from'] ?? '') ?>">
            </div>
            <div class="col-md-2 mb-3">
                <label class="form-label">Bitiş</label>
                <input type="date" name="date_to" class="form-control" value="<?= clean($filters['date_to'] ?? '') ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">Ara</label>
                <input type="text" name="search" class="form-control" placeholder="Ad, e-posta veya mesaj..." value="<?= clean($filters['search'] ?? '') ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">&nbsp;</label>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search me-2"></i>Filtrele
                    </button>
                    <a href="<?= adminUrl('contact-submissions.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary);">
                        Temizle
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Kayıt Listesi -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-inbox me-2"></i>
        Kayıtlar
        <span class="badge badge-info" style="margin-left: 8px;"><?= number_format($totalCount) ?> kayıt</span>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 200px;">Gönderen</th>
                    <th>Konu</th>
                    <th style="max-width: 300px;">Mesaj</th>
                    <th style="text-align: center;">Durum</th>
                    <th>Tarih</th>
                    <th style="text-align: center;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($submissions)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                            Form kaydı bulunamadı.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($submissions as $submission): ?>
                        <tr style="<?= $submission['status'] === 'new' ? 'background: rgba(59, 130, 246, 0.05);' : '' ?>">
                            <td>
                                <div style="font-weight: 600;">
                                    <?php if ($submission['status'] === 'new'): ?>
                                        <span style="display: inline-block; width: 8px; height: 8px; background: #3b82f6; border-radius: 50%; margin-right: 6px;"></span>
                                    <?php endif; ?>
                                    <?= clean($submission['name']) ?>
                                </div>
                                <small style="color: var(--text-muted);"><?= clean($submission['email']) ?></small>
                                <?php if ($submission['phone']): ?>
                                    <br><small style="color: var(--text-muted);"><?= clean($submission['phone']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($submission['subject']): ?>
                                    <span style="color: var(--text-secondary);"><?= clean($submission['subject']) ?></span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="max-width: 300px;">
                                <span style="display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--text-secondary);" title="<?= clean($submission['message']) ?>">
                                    <?= clean(mb_substr($submission['message'], 0, 80)) ?><?= mb_strlen($submission['message']) > 80 ? '...' : '' ?>
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <?php
                                $statusClasses = [
                                    'new' => 'badge-info',
                                    'read' => 'badge-warning',
                                    'replied' => 'badge-success',
                                    'converted' => 'badge-success'
                                ];
                                $statusLabels = [
                                    'new' => 'Yeni',
                                    'read' => 'Okundu',
                                    'replied' => 'Yanıtlandı',
                                    'converted' => 'Dönüştürüldü'
                                ];
                                ?>
                                <span class="badge <?= $statusClasses[$submission['status']] ?? 'badge-warning' ?>">
                                    <?= $statusLabels[$submission['status']] ?? $submission['status'] ?>
                                </span>
                                <?php if ($submission['customer_id']): ?>
                                    <br><small style="color: var(--text-muted);">Müşteri #<?= $submission['customer_id'] ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small style="color: var(--text-secondary);">
                                    <?= date('d.m.Y', strtotime($submission['created_at'])) ?><br>
                                    <?= date('H:i', strtotime($submission['created_at'])) ?>
                                </small>
                            </td>
                            <td style="text-align: center;">
                                <div class="d-flex gap-2 justify-content-center">
                                    <a href="<?= adminUrl('contact-submissions.php?action=view&id=' . $submission['id']) ?>" class="btn btn-sm btn-primary">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if (!$submission['customer_id']): ?>
                                        <a href="<?= adminUrl('contact-submissions.php?action=convert-customer&id=' . $submission['id']) ?>" class="btn btn-sm" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3);" title="Müşteriye Dönüştür" onclick="return confirm('Bu kaydı müşteriye dönüştürmek istediğinize emin misiniz?');">
                                            <i class="bi bi-person-plus"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?= adminUrl('contact-submissions.php?action=delete&id=' . $submission['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu kaydı silmek istediğinize emin misiniz?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Sayfalama -->
<?php if ($totalPages > 1): ?>
<div class="d-flex justify-content-center mt-4 mb-4">
    <div class="d-flex gap-2">
        <?php if ($currentPage > 1): ?>
            <a href="<?= adminUrl('contact-submissions.php?' . http_build_query(array_merge($_GET, ['page' => $currentPage - 1]))) ?>" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-chevron-left"></i>
            </a>
        <?php endif; ?>
        
        <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="<?= adminUrl('contact-submissions.php?' . http_build_query(array_merge($_GET, ['page' => $i]))) ?>" class="btn btn-sm <?= $i == $currentPage ? 'btn-primary' : '' ?>" style="<?= $i != $currentPage ? 'background: var(--bg-input); color: var(--text-secondary);' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
        
        <?php if ($currentPage < $totalPages): ?>
            <a href="<?= adminUrl('contact-submissions.php?' . http_build_query(array_merge($_GET, ['page' => $currentPage + 1]))) ?>" class="btn btn-sm" style="background: var(--bg-input); color: var(--text-secondary);">
                <i class="bi bi-chevron-right"></i>
            </a>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
