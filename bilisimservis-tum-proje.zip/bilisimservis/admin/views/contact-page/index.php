<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">İletişim Sayfası Yönetimi</h1>
            <p class="text-muted mb-0">İletişim sayfasındaki içerikleri buradan düzenleyebilirsiniz.</p>
        </div>
        <a href="<?= url('iletisim') ?>" target="_blank" class="btn btn-outline-primary">
            <i class="bi bi-eye me-2"></i>Sayfayı Görüntüle
        </a>
    </div>

    <?php if ($flash = getFlash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= generateCsrfToken() ?>">
        
        <!-- Hero Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-house me-2"></i>Hero Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[contact_hero_badge]" class="form-control" value="<?= clean($settings['contact_hero_badge']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[contact_hero_title]" class="form-control" value="<?= clean($settings['contact_hero_title']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Vurgulu Kelime</label>
                        <input type="text" name="settings[contact_hero_highlight]" class="form-control" value="<?= clean($settings['contact_hero_highlight']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[contact_hero_subtitle]" class="form-control" rows="2"><?= clean($settings['contact_hero_subtitle']) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Info -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>İletişim Bilgileri Etiketleri</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Telefon Etiketi</label>
                        <input type="text" name="settings[contact_phone_label]" class="form-control" value="<?= clean($settings['contact_phone_label']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">E-posta Etiketi</label>
                        <input type="text" name="settings[contact_email_label]" class="form-control" value="<?= clean($settings['contact_email_label']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Çalışma Saatleri Etiketi</label>
                        <input type="text" name="settings[contact_hours_label]" class="form-control" value="<?= clean($settings['contact_hours_label']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Çalışma Saatleri Değeri</label>
                        <input type="text" name="settings[contact_hours_value]" class="form-control" value="<?= clean($settings['contact_hours_value']) ?>">
                    </div>
                </div>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Telefon, e-posta ve adres bilgilerini <a href="<?= adminUrl('theme-settings.php') ?>">Tema Ayarları</a> sayfasından değiştirebilirsiniz.
                </div>
            </div>
        </div>

        <!-- Form Section -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-envelope me-2"></i>Form Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Form Başlığı</label>
                        <input type="text" name="settings[contact_form_title]" class="form-control" value="<?= clean($settings['contact_form_title']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Form Alt Başlığı</label>
                        <input type="text" name="settings[contact_form_subtitle]" class="form-control" value="<?= clean($settings['contact_form_subtitle']) ?>">
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-3">Alan Etiketleri ve Placeholder'lar</h6>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Ad Soyad Etiketi</label>
                        <input type="text" name="settings[contact_form_name_label]" class="form-control" value="<?= clean($settings['contact_form_name_label']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Ad Soyad Placeholder</label>
                        <input type="text" name="settings[contact_form_name_placeholder]" class="form-control" value="<?= clean($settings['contact_form_name_placeholder']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">E-posta Etiketi</label>
                        <input type="text" name="settings[contact_form_email_label]" class="form-control" value="<?= clean($settings['contact_form_email_label']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">E-posta Placeholder</label>
                        <input type="text" name="settings[contact_form_email_placeholder]" class="form-control" value="<?= clean($settings['contact_form_email_placeholder']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Konu Etiketi</label>
                        <input type="text" name="settings[contact_form_subject_label]" class="form-control" value="<?= clean($settings['contact_form_subject_label']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Mesaj Etiketi</label>
                        <input type="text" name="settings[contact_form_message_label]" class="form-control" value="<?= clean($settings['contact_form_message_label']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Mesaj Placeholder</label>
                        <input type="text" name="settings[contact_form_message_placeholder]" class="form-control" value="<?= clean($settings['contact_form_message_placeholder']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Gönder Butonu</label>
                        <input type="text" name="settings[contact_form_button]" class="form-control" value="<?= clean($settings['contact_form_button']) ?>">
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-3">Konu Seçenekleri</h6>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Genel Bilgi</label>
                        <input type="text" name="settings[contact_subject_general]" class="form-control" value="<?= clean($settings['contact_subject_general']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Teknik Destek</label>
                        <input type="text" name="settings[contact_subject_support]" class="form-control" value="<?= clean($settings['contact_subject_support']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Fiyat Teklifi</label>
                        <input type="text" name="settings[contact_subject_quote]" class="form-control" value="<?= clean($settings['contact_subject_quote']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Şikayet</label>
                        <input type="text" name="settings[contact_subject_complaint]" class="form-control" value="<?= clean($settings['contact_subject_complaint']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Diğer</label>
                        <input type="text" name="settings[contact_subject_other]" class="form-control" value="<?= clean($settings['contact_subject_other']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Map Section -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-geo-alt me-2"></i>Harita Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[contact_map_badge]" class="form-control" value="<?= clean($settings['contact_map_badge']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[contact_map_title]" class="form-control" value="<?= clean($settings['contact_map_title']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Adres Kartı Başlığı</label>
                        <input type="text" name="settings[contact_map_address_title]" class="form-control" value="<?= clean($settings['contact_map_address_title']) ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Social Section -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="bi bi-share me-2"></i>Sosyal Medya Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[contact_social_title]" class="form-control" value="<?= clean($settings['contact_social_title']) ?>">
                    </div>
                </div>
                
                <h6 class="border-bottom pb-2 mb-3 mt-3">Sosyal Medya Linkleri</h6>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-facebook me-2" style="color: #1877f2;"></i>Facebook URL</label>
                        <input type="url" name="settings[social_facebook_url]" class="form-control" value="<?= clean($settings['social_facebook_url']) ?>" placeholder="https://facebook.com/sayfaniz">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-instagram me-2" style="color: #e4405f;"></i>Instagram URL</label>
                        <input type="url" name="settings[social_instagram_url]" class="form-control" value="<?= clean($settings['social_instagram_url']) ?>" placeholder="https://instagram.com/sayfaniz">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-twitter-x me-2"></i>Twitter/X URL</label>
                        <input type="url" name="settings[social_twitter_url]" class="form-control" value="<?= clean($settings['social_twitter_url']) ?>" placeholder="https://twitter.com/sayfaniz">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-whatsapp me-2" style="color: #25d366;"></i>WhatsApp URL</label>
                        <input type="url" name="settings[social_whatsapp_url]" class="form-control" value="<?= clean($settings['social_whatsapp_url']) ?>" placeholder="https://wa.me/905551234567">
                        <small style="color: var(--text-muted);">Format: https://wa.me/905551234567</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-youtube me-2" style="color: #ff0000;"></i>YouTube URL</label>
                        <input type="url" name="settings[social_youtube_url]" class="form-control" value="<?= clean($settings['social_youtube_url']) ?>" placeholder="https://youtube.com/@kanaliniz">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-linkedin me-2" style="color: #0077b5;"></i>LinkedIn URL</label>
                        <input type="url" name="settings[social_linkedin_url]" class="form-control" value="<?= clean($settings['social_linkedin_url']) ?>" placeholder="https://linkedin.com/company/sirketiniz">
                    </div>
                </div>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Boş bırakılan sosyal medya ikonları iletişim sayfasında gösterilmeyecektir.
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <div class="d-flex justify-content-end gap-2 mb-4">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check-lg me-2"></i>Değişiklikleri Kaydet
            </button>
        </div>
    </form>
</div>
