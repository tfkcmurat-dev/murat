<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Referanslar</h1>
        <p>Anasayfada gösterilecek firma referanslarını yönetin.</p>
    </div>
    <a href="<?= adminUrl('references.php?action=create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Yeni Referans Ekle
    </a>
</div>

<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Logo</th>
                    <th>Firma Adı</th>
                    <th>Link</th>
                    <th>Sıra</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($references)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-building" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz referans bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($references as $reference): ?>
                        <tr>
                            <td>
                                <?php if (!empty($reference['logo_url'])): ?>
                                    <div style="background: white; padding: 8px; border-radius: 8px; display: inline-block;">
                                        <img 
                                            src="<?= clean(normalizeImageUrl($reference['logo_url'])) ?>" 
                                            alt="<?= clean($reference['name']) ?>"
                                            style="height: 40px; width: auto; max-width: 120px; object-fit: contain;"
                                            onerror="this.parentElement.innerHTML='<span style=\'color: var(--text-muted); font-size: 0.85rem;\'>Yüklenemedi</span>'"
                                        >
                                    </div>
                                <?php else: ?>
                                    <div style="width: 80px; height: 40px; background: var(--bg-input); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                        <i class="bi bi-image" style="color: var(--text-muted);"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="font-weight: 600;"><?= clean($reference['name']) ?></td>
                            <td>
                                <?php if (!empty($reference['link'])): ?>
                                    <a href="<?= clean($reference['link']) ?>" target="_blank" style="color: var(--accent-secondary); font-size: 0.85rem;">
                                        <?= clean(mb_substr($reference['link'], 0, 35)) ?><?= mb_strlen($reference['link']) > 35 ? '...' : '' ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 6px; font-size: 0.85rem;">
                                    <?= $reference['sort_order'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($reference['is_active']): ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge" style="background: rgba(107, 114, 128, 0.2); color: #9ca3af;">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                    <a href="<?= adminUrl('references.php?action=toggle&id=' . $reference['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                                        <?= $reference['is_active'] ? 'Pasif Yap' : 'Aktif Yap' ?>
                                    </a>
                                    <a href="<?= adminUrl('references.php?action=edit&id=' . $reference['id']) ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Düzenle
                                    </a>
                                    <a href="<?= adminUrl('references.php?action=delete&id=' . $reference['id'] . '&token=' . generateCsrfToken()) ?>" 
                                       class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);"
                                       onclick="return confirm('Bu referansı silmek istediğinize emin misiniz?')">
                                        Sil
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
