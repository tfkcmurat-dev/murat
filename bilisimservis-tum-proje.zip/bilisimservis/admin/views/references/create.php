<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Yeni Referans Ekle</h1>
        <p>Anasayfada gösterilecek yeni firma referansı ekleyin.</p>
    </div>
    <a href="<?= adminUrl('references.php') ?>" class="btn btn-outline-primary">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<div class="card">
    <div class="card-header bg-success">
        <i class="bi bi-building-add me-2"></i>Referans Bilgileri
    </div>
    <div class="card-body">
        <form method="POST" action="" enctype="multipart/form-data">
            <?= csrfField() ?>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label">
                        Firma Adı <span style="color: #f87171;">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name" 
                        required
                        class="form-control"
                        placeholder="Firma adını girin"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="link" class="form-label">Firma Web Sitesi (Opsiyonel)</label>
                    <input 
                        type="url" 
                        id="link" 
                        name="link" 
                        placeholder="https://example.com"
                        class="form-control"
                    >
                </div>
                
                <div class="col-12 mb-3">
                    <label class="form-label">Logo</label>
                    <div class="card" style="background: var(--bg-input);">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="logo_file" class="form-label">
                                        <i class="bi bi-upload me-2"></i>Dosya Yükle
                                    </label>
                                    <input 
                                        type="file" 
                                        id="logo_file" 
                                        name="logo_file" 
                                        accept="image/jpeg,image/png,image/gif,image/webp"
                                        class="form-control"
                                    >
                                    <small style="color: var(--text-muted); display: block; margin-top: 8px;">
                                        Maksimum 5MB. Formatlar: JPG, PNG, GIF, WEBP
                                    </small>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="logo_url" class="form-label">
                                        <i class="bi bi-link-45deg me-2"></i>veya Logo URL
                                    </label>
                                    <input 
                                        type="url" 
                                        id="logo_url" 
                                        name="logo_url" 
                                        placeholder="https://example.com/logo.png"
                                        class="form-control"
                                    >
                                    <small style="color: var(--text-muted); display: block; margin-top: 8px;">
                                        Harici bir URL'den logo ekleyebilirsiniz.
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="sort_order" class="form-label">Sıralama</label>
                    <input 
                        type="number" 
                        id="sort_order" 
                        name="sort_order" 
                        value="0"
                        class="form-control"
                    >
                    <small style="color: var(--text-muted);">Düşük sayılar önce gösterilir.</small>
                </div>
                
                <div class="col-md-6 mb-4">
                    <label class="form-label" style="margin-bottom: 12px;">Durum</label>
                    <div style="display: flex; align-items: center; gap: 12px; height: 46px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 12px 20px; background: var(--bg-card); border-radius: 10px; border: 1px solid var(--border-color);">
                            <input 
                                type="checkbox" 
                                name="is_active" 
                                value="1" 
                                checked
                                style="width: 18px; height: 18px; accent-color: var(--accent-primary);"
                            >
                            <span>Aktif</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; justify-content: flex-end; gap: 12px; padding-top: 16px; border-top: 1px solid var(--border-color);">
                <a href="<?= adminUrl('references.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
                    <i class="bi bi-x-lg me-2"></i>İptal
                </a>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-check-lg me-2"></i>Kaydet
                </button>
            </div>
        </form>
    </div>
</div>
