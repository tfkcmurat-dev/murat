<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Yeni Teklif Oluştur</h1>
        <p>Müşteriye gönderilecek yeni teklif hazırlayın.</p>
    </div>
    <a href="<?= adminUrl('quotes.php') ?>" class="btn btn-outline-primary">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="" x-data="quoteForm()">
    <?= csrfField() ?>
    
    <!-- Teklif Bilgileri -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header bg-success">
            <i class="bi bi-file-earmark-text me-2"></i>Teklif Bilgileri
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="customer_id" class="form-label">
                        Müşteri <span style="color: #f87171;">*</span>
                    </label>
                    <select 
                        id="customer_id" 
                        name="customer_id" 
                        required
                        x-on:change="loadCustomerData($event.target.value)"
                        class="form-control"
                    >
                        <option value="">Müşteri Seçin</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= $customer['id'] ?>" 
                                data-province="<?= clean($customer['province']) ?>"
                                data-district="<?= clean($customer['district']) ?>"
                                data-address="<?= clean($customer['address']) ?>"
                                data-tax="<?= clean($customer['tax_number']) ?>"
                            >
                                <?= clean($customer['company_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="subject" class="form-label">
                        Teklif Konusu <span style="color: #f87171;">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="subject" 
                        name="subject" 
                        required
                        class="form-control"
                        placeholder="Teklif konusunu girin"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="status" class="form-label">Durum</label>
                    <select id="status" name="status" class="form-control">
                        <option value="draft">Taslak</option>
                        <option value="sent">Gönderildi</option>
                        <option value="approved">Onaylandı</option>
                        <option value="rejected">Reddedildi</option>
                    </select>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="valid_until" class="form-label">Geçerlilik Tarihi</label>
                    <input 
                        type="date" 
                        id="valid_until" 
                        name="valid_until"
                        class="form-control"
                    >
                </div>
                
                <div class="col-12 mb-3">
                    <label for="notes" class="form-label">Dahili Notlar</label>
                    <textarea 
                        id="notes" 
                        name="notes" 
                        rows="2"
                        class="form-control"
                        placeholder="Sadece sizin göreceğiniz dahili notlar..."
                    ></textarea>
                    <small style="color: var(--text-muted);">Bu not müşteriye gösterilmez.</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Müşteri Notu -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header bg-info" style="display: flex; justify-content: space-between; align-items: center;">
            <span><i class="bi bi-chat-text me-2"></i>Müşteri Notu (Teklifte Görünür)</span>
            <?php if (!empty($noteTemplates)): ?>
            <div>
                <select id="noteTemplateSelect" class="form-control form-control-sm" style="width: auto; display: inline-block;">
                    <option value="">Şablon Seç...</option>
                    <?php foreach ($noteTemplates as $tmpl): ?>
                        <option value="<?= $tmpl['id'] ?>"><?= clean($tmpl['title']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="button" id="applyTemplateBtn" class="btn btn-sm btn-info">Uygula</button>
            </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <textarea 
                id="customer_note" 
                name="customer_note" 
                rows="4"
                class="form-control"
                placeholder="Müşteriye gösterilecek açıklamalar, ödeme koşulları, garanti bilgisi vb..."
            ></textarea>
            <small style="color: var(--text-muted);">Bu not müşteriye gönderilen teklifte ve canlı teklif sayfasında görünür.</small>
        </div>
    </div>
    
    <!-- Teklif Kalemleri -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <span><i class="bi bi-list-ol me-2"></i>Teklif Kalemleri</span>
            <button 
                type="button"
                x-on:click="addItem()"
                class="btn btn-success btn-sm"
            >
                <i class="bi bi-plus-lg me-2"></i>Kalem Ekle
            </button>
        </div>
        <div class="card-body">
            <template x-for="(item, index) in items" :key="index">
                <div style="border: 1px solid var(--border-color); border-radius: 12px; padding: 20px; margin-bottom: 16px; background: var(--bg-input);">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Hizmet Seç (Opsiyonel)</label>
                            <select 
                                :name="'items[' + index + '][service_id]'"
                                x-on:change="loadServiceData(index, $event.target.value)"
                                class="form-control"
                            >
                                <option value="">Manuel Giriş</option>
                                <?php foreach ($services as $service): ?>
                                    <option 
                                        value="<?= $service['id'] ?>"
                                        data-name="<?= clean($service['name']) ?>"
                                        data-price="<?= $service['default_price'] ?>"
                                        data-tax="<?= $service['tax_rate'] ?>"
                                    >
                                        <?= clean($service['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                Kalem Adı <span style="color: #f87171;">*</span>
                            </label>
                            <input 
                                type="text" 
                                :name="'items[' + index + '][item_name]'"
                                x-model="item.item_name"
                                required
                                class="form-control"
                                placeholder="Kalem adını girin"
                            >
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Açıklama</label>
                            <textarea 
                                :name="'items[' + index + '][description]'"
                                x-model="item.description"
                                rows="2"
                                class="form-control"
                                placeholder="Kalem açıklaması..."
                            ></textarea>
                        </div>
                        <div class="col-6 col-md-2 mb-3">
                            <label class="form-label">Miktar</label>
                            <input 
                                type="number" 
                                :name="'items[' + index + '][quantity]'"
                                x-model.number="item.quantity"
                                step="0.01"
                                x-on:input="calculateItem(index)"
                                class="form-control"
                            >
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <label class="form-label">Birim Fiyat (₺)</label>
                            <input 
                                type="number" 
                                :name="'items[' + index + '][unit_price]'"
                                x-model.number="item.unit_price"
                                step="0.01"
                                x-on:input="calculateItem(index)"
                                class="form-control"
                            >
                        </div>
                        <div class="col-6 col-md-2 mb-3">
                            <label class="form-label">KDV (%)</label>
                            <input 
                                type="number" 
                                :name="'items[' + index + '][tax_rate]'"
                                x-model.number="item.tax_rate"
                                step="0.01"
                                x-on:input="calculateItem(index)"
                                class="form-control"
                            >
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <label class="form-label">İndirim</label>
                            <div style="display: flex; gap: 8px;">
                                <select 
                                    :name="'items[' + index + '][discount_type]'"
                                    x-model="item.discount_type"
                                    x-on:change="calculateItem(index)"
                                    class="form-control"
                                    style="width: 80px;"
                                >
                                    <option value="fixed">₺</option>
                                    <option value="percentage">%</option>
                                </select>
                                <input 
                                    type="number" 
                                    :name="'items[' + index + '][discount]'"
                                    x-model.number="item.discount"
                                    step="0.01"
                                    x-on:input="calculateItem(index)"
                                    class="form-control"
                                    style="flex: 1;"
                                >
                            </div>
                        </div>
                        <div class="col-12 col-md-2 mb-3">
                            <label class="form-label">Toplam</label>
                            <input 
                                type="text" 
                                :value="formatMoney(item.total)"
                                readonly
                                class="form-control"
                                style="background: var(--bg-card); font-weight: 600; color: var(--accent-secondary);"
                            >
                        </div>
                    </div>
                    
                    <div style="text-align: right;">
                        <button 
                            type="button"
                            x-on:click="removeItem(index)"
                            class="btn btn-sm"
                            style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);"
                        >
                            <i class="bi bi-trash me-1"></i>Kalemi Sil
                        </button>
                    </div>
                </div>
            </template>
            
            <div x-show="items.length === 0" style="text-align: center; color: var(--text-muted); padding: 48px;">
                <i class="bi bi-inbox" style="font-size: 2.5rem; display: block; margin-bottom: 12px; opacity: 0.5;"></i>
                Henüz kalem eklenmedi. "Kalem Ekle" butonuna tıklayarak ekleyebilirsiniz.
            </div>
            
            <!-- Toplam Özet -->
            <div style="margin-top: 24px; padding-top: 24px; border-top: 1px solid var(--border-color);">
                <div style="display: flex; justify-content: flex-end;">
                    <div style="width: 320px; background: var(--bg-input); border-radius: 12px; padding: 20px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; color: var(--text-secondary);">
                            <span>Ara Toplam:</span>
                            <span style="font-weight: 600;" x-text="formatMoney(totals.subtotal)"></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; color: var(--text-secondary);">
                            <span>KDV Toplamı:</span>
                            <span style="font-weight: 600;" x-text="formatMoney(totals.taxTotal)"></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 16px; color: var(--text-secondary);">
                            <span>İndirim Toplamı:</span>
                            <span style="font-weight: 600;" x-text="formatMoney(totals.discountTotal)"></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-top: 16px; border-top: 1px solid var(--border-color);">
                            <span style="font-size: 1.1rem; font-weight: 700;">Genel Toplam:</span>
                            <span style="font-size: 1.1rem; font-weight: 700; color: var(--accent-secondary);" x-text="formatMoney(totals.grandTotal)"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div style="display: flex; justify-content: flex-end; gap: 12px;">
        <a href="<?= adminUrl('quotes.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
            <i class="bi bi-x-lg me-2"></i>İptal
        </a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-check-lg me-2"></i>Teklifi Kaydet
        </button>
    </div>
</form>

<script>
function quoteForm() {
    return {
        items: [],
        totals: {
            subtotal: 0,
            taxTotal: 0,
            discountTotal: 0,
            grandTotal: 0
        },
        
        init() {
            this.addItem();
            this.initTemplateSelect();
        },
        
        initTemplateSelect() {
            const templateSelect = document.getElementById('noteTemplateSelect');
            const applyBtn = document.getElementById('applyTemplateBtn');
            
            if (templateSelect && applyBtn) {
                applyBtn.addEventListener('click', () => {
                    const templateId = templateSelect.value;
                    if (!templateId) return;
                    
                    fetch('<?= adminUrl("quote-note-templates.php?action=get&id=") ?>' + templateId)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                const textarea = document.getElementById('customer_note');
                                if (textarea.value) {
                                    textarea.value += '\n\n' + data.template.content;
                                } else {
                                    textarea.value = data.template.content;
                                }
                            }
                        });
                });
            }
        },
        
        addItem() {
            this.items.push({
                service_id: '',
                item_name: '',
                description: '',
                quantity: 1,
                unit_price: 0,
                tax_rate: 18,
                discount: 0,
                discount_type: 'fixed',
                subtotal: 0,
                tax_amount: 0,
                total: 0
            });
        },
        
        removeItem(index) {
            this.items.splice(index, 1);
            this.calculateTotals();
        },
        
        loadServiceData(index, serviceId) {
            if (!serviceId) return;
            
            const select = event.target;
            const option = select.options[select.selectedIndex];
            
            if (option) {
                this.items[index].item_name = option.getAttribute('data-name') || '';
                this.items[index].unit_price = parseFloat(option.getAttribute('data-price') || 0);
                this.items[index].tax_rate = parseFloat(option.getAttribute('data-tax') || 18);
                this.calculateItem(index);
            }
        },
        
        loadCustomerData(customerId) {
            if (!customerId) return;
            
            const select = document.getElementById('customer_id');
            const option = select.options[select.selectedIndex];
        },
        
        calculateItem(index) {
            const item = this.items[index];
            const itemGross = item.quantity * item.unit_price;
            
            // İndirim hesapla
            let actualDiscount = 0;
            if (item.discount_type === 'percentage') {
                actualDiscount = itemGross * (item.discount / 100);
            } else {
                actualDiscount = item.discount;
            }
            
            const subtotal = itemGross - actualDiscount;
            const taxAmount = subtotal * (item.tax_rate / 100);
            const total = subtotal + taxAmount;
            
            item.actualDiscount = Math.round(actualDiscount * 100) / 100;
            item.subtotal = Math.round(subtotal * 100) / 100;
            item.tax_amount = Math.round(taxAmount * 100) / 100;
            item.total = Math.round(total * 100) / 100;
            
            this.calculateTotals();
        },
        
        calculateTotals() {
            this.totals.subtotal = this.items.reduce((sum, item) => sum + (item.subtotal || 0), 0);
            this.totals.taxTotal = this.items.reduce((sum, item) => sum + (item.tax_amount || 0), 0);
            this.totals.discountTotal = this.items.reduce((sum, item) => sum + (item.actualDiscount || 0), 0);
            this.totals.grandTotal = this.totals.subtotal + this.totals.taxTotal;
        },
        
        formatMoney(amount) {
            return new Intl.NumberFormat('tr-TR', {
                style: 'currency',
                currency: 'TRY'
            }).format(amount || 0);
        }
    }
}
</script>
