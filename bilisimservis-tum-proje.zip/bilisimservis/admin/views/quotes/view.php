<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1><?= clean($quote['quote_number']) ?></h1>
        <p><?= clean($quote['subject']) ?></p>
    </div>
    <div style="display: flex; gap: 12px;">
        <?php if (in_array($quote['status'], ['sent', 'approved'])): ?>
        <a href="<?= url('teklif/' . $quote['quote_number']) ?>" target="_blank" class="btn" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3);">
            <i class="bi bi-link-45deg me-2"></i>Canlı Link
        </a>
        <?php endif; ?>
        <a href="<?= adminUrl('quotes-pdf.php?id=' . $quote['id']) ?>" target="_blank" class="btn" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);">
            <i class="bi bi-file-pdf me-2"></i>PDF İndir
        </a>
        <a href="<?= adminUrl('quotes.php?action=edit&id=' . $quote['id']) ?>" class="btn btn-primary">
            <i class="bi bi-pencil me-2"></i>Düzenle
        </a>
    </div>
</div>

<!-- Teklif Özeti -->
<div class="row" style="margin-bottom: 24px;">
    <div class="col-md-6">
        <div class="card" style="height: 100%;">
            <div class="card-header">
                <i class="bi bi-building me-2"></i>Müşteri Bilgileri
            </div>
            <div class="card-body">
                <h4 style="margin-bottom: 8px; font-weight: 600;"><?= clean($quote['company_name']) ?></h4>
                <p style="color: var(--text-secondary); margin-bottom: 4px;">
                    <i class="bi bi-geo-alt me-2" style="opacity: 0.7;"></i>
                    <?= clean($quote['province']) ?> / <?= clean($quote['district']) ?>
                </p>
                <p style="color: var(--text-secondary); margin-bottom: 4px; font-size: 0.9rem;"><?= clean($quote['address']) ?></p>
                <?php if (!empty($quote['tax_number'])): ?>
                    <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 12px;">
                        <i class="bi bi-receipt me-2"></i>Vergi No: <?= clean($quote['tax_number']) ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card" style="height: 100%;">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>Teklif Bilgileri
            </div>
            <div class="card-body">
                <?php
                $statusClasses = [
                    'draft' => 'badge-warning',
                    'sent' => 'badge-info',
                    'approved' => 'badge-success',
                    'rejected' => 'badge-danger'
                ];
                $statusLabels = [
                    'draft' => 'Taslak',
                    'sent' => 'Gönderildi',
                    'approved' => 'Onaylandı',
                    'rejected' => 'Reddedildi'
                ];
                ?>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                    <span>Durum:</span>
                    <span class="badge <?= $statusClasses[$quote['status']] ?? 'badge-warning' ?>">
                        <?= $statusLabels[$quote['status']] ?? $quote['status'] ?>
                    </span>
                </div>
                <p style="color: var(--text-secondary); margin-bottom: 4px; font-size: 0.9rem;">
                    <i class="bi bi-calendar-plus me-2" style="opacity: 0.7;"></i>
                    Oluşturulma: <?= formatDate($quote['created_at']) ?>
                </p>
                <p style="color: var(--text-secondary); margin-bottom: 4px; font-size: 0.9rem;">
                    <i class="bi bi-calendar-check me-2" style="opacity: 0.7;"></i>
                    Güncellenme: <?= formatDate($quote['updated_at']) ?>
                </p>
                <?php if (!empty($quote['valid_until'])): ?>
                    <p style="color: var(--text-secondary); margin-bottom: 0; font-size: 0.9rem;">
                        <i class="bi bi-calendar-event me-2" style="opacity: 0.7;"></i>
                        Geçerlilik: <?= formatDate($quote['valid_until']) ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($quote['notes'])): ?>
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <i class="bi bi-sticky me-2"></i>Dahili Notlar
    </div>
    <div class="card-body">
        <p style="margin: 0; color: var(--text-secondary);"><?= nl2br(clean($quote['notes'])) ?></p>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($quote['customer_note'])): ?>
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header bg-info">
        <i class="bi bi-chat-text me-2"></i>Müşteri Notu (Teklifte Görünür)
    </div>
    <div class="card-body">
        <p style="margin: 0; color: var(--text-secondary); white-space: pre-wrap;"><?= clean($quote['customer_note']) ?></p>
    </div>
</div>
<?php endif; ?>

<!-- Müşteri Yanıtı -->
<?php 
$customerResponse = $quote['customer_response'] ?? 'pending';
$responseLabels = [
    'pending' => ['text' => 'Yanıt Bekleniyor', 'class' => 'badge-warning', 'icon' => 'hourglass-split'],
    'approved' => ['text' => 'Müşteri Onayladı', 'class' => 'badge-success', 'icon' => 'check-circle-fill'],
    'rejected' => ['text' => 'Müşteri Reddetti', 'class' => 'badge-danger', 'icon' => 'x-circle-fill'],
    'revision_requested' => ['text' => 'Revize Talep Edildi', 'class' => 'badge-warning', 'icon' => 'pencil-square']
];
$responseInfo = $responseLabels[$customerResponse] ?? $responseLabels['pending'];
?>
<?php if ($customerResponse !== 'pending'): ?>
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header" style="background: <?= $customerResponse === 'approved' ? 'rgba(16, 185, 129, 0.15)' : ($customerResponse === 'rejected' ? 'rgba(239, 68, 68, 0.15)' : 'rgba(245, 158, 11, 0.15)') ?>; color: <?= $customerResponse === 'approved' ? '#10b981' : ($customerResponse === 'rejected' ? '#ef4444' : '#f59e0b') ?>;">
        <i class="bi bi-<?= $responseInfo['icon'] ?> me-2"></i>Müşteri Yanıtı
    </div>
    <div class="card-body">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
            <span class="badge <?= $responseInfo['class'] ?>"><?= $responseInfo['text'] ?></span>
            <?php if (!empty($quote['customer_response_date'])): ?>
                <span style="color: var(--text-muted); font-size: 0.85rem;">
                    <i class="bi bi-clock me-1"></i>
                    <?= date('d.m.Y H:i', strtotime($quote['customer_response_date'])) ?>
                </span>
            <?php endif; ?>
        </div>
        <?php if ($customerResponse === 'revision_requested' && !empty($quote['customer_response_message'])): ?>
            <div style="background: rgba(245, 158, 11, 0.1); padding: 16px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                <strong style="color: #f59e0b; display: block; margin-bottom: 8px;">
                    <i class="bi bi-chat-quote me-2"></i>Müşterinin Revize Talebi:
                </strong>
                <p style="margin: 0; color: var(--text-secondary); white-space: pre-wrap;"><?= clean($quote['customer_response_message']) ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<!-- Teklif Kalemleri -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <i class="bi bi-list-ol me-2"></i>Teklif Kalemleri
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Kalem</th>
                    <th>Açıklama</th>
                    <th style="text-align: right;">Miktar</th>
                    <th style="text-align: right;">Birim Fiyat</th>
                    <th style="text-align: right;">KDV</th>
                    <th style="text-align: right;">İndirim</th>
                    <th style="text-align: right;">Toplam</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($quote['items'] as $item): ?>
                    <tr>
                        <td style="font-weight: 600;"><?= clean($item['item_name']) ?></td>
                        <td style="color: var(--text-muted); font-size: 0.9rem;"><?= clean($item['description']) ?></td>
                        <td style="text-align: right;"><?= number_format($item['quantity'], 2, ',', '.') ?></td>
                        <td style="text-align: right;"><?= formatMoney($item['unit_price']) ?></td>
                        <td style="text-align: right; color: var(--text-muted);">%<?= number_format($item['tax_rate'], 2) ?></td>
                        <td style="text-align: right; color: var(--text-muted);"><?= formatMoney($item['discount']) ?></td>
                        <td style="text-align: right; font-weight: 600; color: var(--accent-secondary);"><?= formatMoney($item['total']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Toplam Özeti -->
        <div style="padding: 24px; border-top: 1px solid var(--border-color);">
            <div style="display: flex; justify-content: flex-end;">
                <div style="width: 320px; background: var(--bg-input); border-radius: 12px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; color: var(--text-secondary);">
                        <span>Ara Toplam:</span>
                        <span style="font-weight: 600;"><?= formatMoney($quote['subtotal']) ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; color: var(--text-secondary);">
                        <span>KDV Toplamı:</span>
                        <span style="font-weight: 600;"><?= formatMoney($quote['tax_total']) ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px; color: var(--text-secondary);">
                        <span>İndirim Toplamı:</span>
                        <span style="font-weight: 600;"><?= formatMoney($quote['discount_total']) ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; padding-top: 16px; border-top: 1px solid var(--border-color);">
                        <span style="font-size: 1.1rem; font-weight: 700;">Genel Toplam:</span>
                        <span style="font-size: 1.1rem; font-weight: 700; color: var(--accent-secondary);"><?= formatMoney($quote['grand_total']) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Durum Güncelleme ve E-posta Gönderimi -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <span><i class="bi bi-arrow-repeat me-2"></i>Durum Güncelle</span>
        <?php if (in_array($quote['status'], ['sent', 'approved', 'rejected'])): ?>
        <a href="<?= adminUrl('quotes.php?action=resendEmail&id=' . $quote['id']) ?>" 
           class="btn btn-sm" 
           style="background: rgba(59, 130, 246, 0.15); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.3);"
           onclick="return confirm('Teklif e-postasını müşteriye tekrar göndermek istiyor musunuz?')">
            <i class="bi bi-envelope-arrow-up me-1"></i>E-posta Tekrar Gönder
        </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form method="POST" action="<?= adminUrl('quotes.php?action=updateStatus&id=' . $quote['id']) ?>" id="statusForm">
            <?= csrfField() ?>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="status" class="form-label">Yeni Durum</label>
                    <select id="status" name="status" class="form-control" onchange="toggleEmailOption()">
                        <option value="draft" <?= $quote['status'] == 'draft' ? 'selected' : '' ?>>Taslak</option>
                        <option value="sent" <?= $quote['status'] == 'sent' ? 'selected' : '' ?>>Gönderildi</option>
                        <option value="approved" <?= $quote['status'] == 'approved' ? 'selected' : '' ?>>Onaylandı</option>
                        <option value="rejected" <?= $quote['status'] == 'rejected' ? 'selected' : '' ?>>Reddedildi</option>
                    </select>
                </div>
                <div class="col-md-5 mb-3">
                    <label for="status_notes" class="form-label">Not</label>
                    <input 
                        type="text" 
                        id="status_notes" 
                        name="notes"
                        placeholder="Durum değişikliği notu (opsiyonel)"
                        class="form-control"
                    >
                </div>
                <div class="col-md-2 mb-3" id="emailOption" style="display: none;">
                    <label class="form-label">&nbsp;</label>
                    <div class="form-check" style="padding-top: 8px;">
                        <input type="checkbox" class="form-check-input" id="send_email" name="send_email" value="1" checked>
                        <label class="form-check-label" for="send_email" style="font-size: 0.9rem;">
                            <i class="bi bi-envelope me-1"></i>E-posta Gönder
                        </label>
                    </div>
                </div>
                <div class="col-md-2 mb-3" style="display: flex; align-items: flex-end;">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="bi bi-check-lg me-2"></i>Güncelle
                    </button>
                </div>
            </div>
            
            <!-- E-posta bilgisi -->
            <div id="emailInfo" style="display: none; background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: 8px; padding: 12px 16px; margin-top: 8px;">
                <p style="margin: 0; font-size: 0.9rem; color: var(--text-secondary);">
                    <i class="bi bi-info-circle me-2" style="color: #3b82f6;"></i>
                    <?php if (!empty($quote['email'])): ?>
                        Teklif <strong><?= clean($quote['email']) ?></strong> adresine gönderilecek.
                    <?php else: ?>
                        <span style="color: #f59e0b;">⚠️ Müşterinin e-posta adresi tanımlı değil.</span>
                    <?php endif; ?>
                </p>
            </div>
        </form>
    </div>
</div>

<script>
function toggleEmailOption() {
    const status = document.getElementById('status').value;
    const emailOption = document.getElementById('emailOption');
    const emailInfo = document.getElementById('emailInfo');
    
    if (status === 'sent') {
        emailOption.style.display = 'block';
        emailInfo.style.display = 'block';
    } else {
        emailOption.style.display = 'none';
        emailInfo.style.display = 'none';
    }
}

// Sayfa yüklendiğinde kontrol et
document.addEventListener('DOMContentLoaded', function() {
    toggleEmailOption();
});
</script>

<!-- Geçmiş -->
<?php if (!empty($history)): ?>
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <i class="bi bi-clock-history me-2"></i>Teklif Geçmişi
    </div>
    <div class="card-body">
        <?php foreach ($history as $entry): ?>
            <div style="border-left: 3px solid var(--accent-primary); padding-left: 16px; padding: 12px 0 12px 16px; margin-bottom: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div>
                        <p style="font-weight: 600; margin-bottom: 4px;">
                            <?php
                            $actionLabels = [
                                'created' => 'Oluşturuldu',
                                'updated' => 'Güncellendi',
                                'status_changed' => 'Durum Değiştirildi',
                                'customer_response' => 'Müşteri Yanıtı'
                            ];
                            echo $actionLabels[$entry['action']] ?? $entry['action'];
                            ?>
                            <?php if ($entry['old_status'] && $entry['new_status']): ?>
                                : <span style="color: var(--text-muted);"><?= $entry['old_status'] ?></span> 
                                <i class="bi bi-arrow-right" style="font-size: 0.8rem; margin: 0 4px;"></i> 
                                <span style="color: var(--accent-secondary);"><?= $entry['new_status'] ?></span>
                            <?php endif; ?>
                        </p>
                        <?php if (!empty($entry['notes'])): ?>
                            <p style="color: var(--text-secondary); margin: 0; font-size: 0.9rem;"><?= clean($entry['notes']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div style="text-align: right;">
                        <p style="color: var(--text-muted); margin: 0; font-size: 0.8rem;"><?= formatDate($entry['created_at'], 'd.m.Y H:i') ?></p>
                        <?php if ($entry['username']): ?>
                            <p style="color: var(--text-muted); margin: 0; font-size: 0.8rem;"><?= clean($entry['username']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div style="display: flex; justify-content: flex-end; gap: 12px;">
    <a href="<?= adminUrl('quotes.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
        <i class="bi bi-arrow-left me-2"></i>Listeye Dön
    </a>
</div>
