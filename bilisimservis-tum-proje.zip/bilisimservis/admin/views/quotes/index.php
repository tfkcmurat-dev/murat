<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Teklifler</h1>
        <p>Müşterilere gönderilen teklifleri yönetin.</p>
    </div>
    <a href="<?= adminUrl('quotes.php?action=create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-2"></i>Yeni Teklif Oluştur
    </a>
</div>

<!-- Durum Filtreleri -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-body" style="padding: 16px;">
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="<?= adminUrl('quotes.php') ?>" 
               class="btn btn-sm <?= !$currentStatus ? 'btn-primary' : 'btn-outline-primary' ?>">
                Tümü
            </a>
            <a href="<?= adminUrl('quotes.php?status=draft') ?>" 
               class="btn btn-sm <?= $currentStatus == 'draft' ? 'btn-primary' : 'btn-outline-primary' ?>">
                <i class="bi bi-file-earmark me-1"></i>Taslak
            </a>
            <a href="<?= adminUrl('quotes.php?status=sent') ?>" 
               class="btn btn-sm <?= $currentStatus == 'sent' ? 'btn-primary' : 'btn-outline-primary' ?>">
                <i class="bi bi-send me-1"></i>Gönderildi
            </a>
            <a href="<?= adminUrl('quotes.php?status=approved') ?>" 
               class="btn btn-sm <?= $currentStatus == 'approved' ? 'btn-primary' : 'btn-outline-primary' ?>">
                <i class="bi bi-check-circle me-1"></i>Onaylandı
            </a>
            <a href="<?= adminUrl('quotes.php?status=rejected') ?>" 
               class="btn btn-sm <?= $currentStatus == 'rejected' ? 'btn-primary' : 'btn-outline-primary' ?>">
                <i class="bi bi-x-circle me-1"></i>Reddedildi
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Teklif No</th>
                    <th>Müşteri</th>
                    <th>Konu</th>
                    <th>Durum</th>
                    <th>Tutar</th>
                    <th>Tarih</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($quotes)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="bi bi-file-earmark-text" style="font-size: 2rem; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                            Henüz teklif bulunmamaktadır.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($quotes as $quote): ?>
                        <tr>
                            <td>
                                <?php if (in_array($quote['status'], ['sent', 'approved', 'rejected'])): ?>
                                <a href="<?= url('teklif/' . $quote['quote_number']) ?>" target="_blank" style="font-weight: 600; color: var(--accent-secondary); text-decoration: none;" title="Canlı teklifi görüntüle">
                                    <?= clean($quote['quote_number']) ?>
                                    <i class="bi bi-box-arrow-up-right" style="font-size: 0.75rem; margin-left: 4px; opacity: 0.7;"></i>
                                </a>
                                <?php else: ?>
                                <span style="font-weight: 600; color: var(--accent-secondary);">
                                    <?= clean($quote['quote_number']) ?>
                                </span>
                                <?php endif; ?>
                            </td>
                            <td><?= clean($quote['company_name'] ?? '-') ?></td>
                            <td style="color: var(--text-secondary);"><?= clean($quote['subject']) ?></td>
                            <td>
                                <?php
                                $statusClasses = [
                                    'draft' => 'badge-warning',
                                    'sent' => 'badge-info',
                                    'approved' => 'badge-success',
                                    'rejected' => 'badge-danger'
                                ];
                                $statusLabels = [
                                    'draft' => 'Taslak',
                                    'sent' => 'Gönderildi',
                                    'approved' => 'Onaylandı',
                                    'rejected' => 'Reddedildi'
                                ];
                                $status = $quote['status'];
                                $customerResponse = $quote['customer_response'] ?? 'pending';
                                ?>
                                <span class="badge <?= $statusClasses[$status] ?? 'badge-warning' ?>">
                                    <?= $statusLabels[$status] ?? $status ?>
                                </span>
                                <?php if ($customerResponse === 'revision_requested'): ?>
                                    <span class="badge badge-warning" style="margin-left: 4px;" title="Müşteri revize talep etti">
                                        <i class="bi bi-pencil-square"></i> Revize
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-weight: 600;">
                                    <?= formatMoney($quote['grand_total']) ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted); font-size: 0.9rem;">
                                <?= formatDate($quote['created_at']) ?>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                    <a href="<?= adminUrl('quotes.php?action=view&id=' . $quote['id']) ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?= adminUrl('quotes.php?action=edit&id=' . $quote['id']) ?>" 
                                       class="btn btn-sm" style="background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3);">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="<?= adminUrl('quotes-pdf.php?id=' . $quote['id']) ?>" 
                                       target="_blank"
                                       class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3);">
                                        <i class="bi bi-file-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
