<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? clean($pageTitle) . ' - ' : '' ?>Admin Paneli - Bilişim Servis</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Admin CSS -->
    <link rel="stylesheet" href="<?= adminUrl('assets/css/admin.css') ?>">
    
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <?php require_once __DIR__ . '/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="admin-main">
            <!-- Top Header -->
            <header class="admin-header">
                <div class="header-left">
                    <button class="mobile-menu-btn" onclick="toggleSidebar()" style="display: none; background: transparent; border: none; color: white; font-size: 1.5rem; cursor: pointer;">
                        <i class="bi bi-list"></i>
                    </button>
                    <h1 class="page-title"><?= isset($pageTitle) ? clean($pageTitle) : 'Dashboard' ?></h1>
                </div>
                
                <div class="header-right">
                    <div class="header-user">
                        <div class="user-avatar">
                            <?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?>
                        </div>
                        <div class="user-info">
                            <span class="user-name"><?= clean($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin') ?></span>
                            <span class="user-role">Yönetici</span>
                        </div>
                    </div>
                    <a href="<?= adminUrl('logout.php') ?>" class="btn-logout">
                        <i class="bi bi-box-arrow-right"></i>
                        Çıkış
                    </a>
                </div>
            </header>
            
            <!-- Page Content -->
            <main class="admin-content">
                <?php 
                $success = getFlash('success');
                $error = getFlash('error');
                $info = getFlash('info');
                ?>
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible">
                        <i class="bi bi-check-circle-fill"></i>
                        <?= clean($success) ?>
                        <button type="button" class="btn-close" onclick="this.parentElement.remove()">×</button>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <i class="bi bi-exclamation-circle-fill"></i>
                        <?= clean($error) ?>
                        <button type="button" class="btn-close" onclick="this.parentElement.remove()">×</button>
                    </div>
                <?php endif; ?>
                <?php if ($info): ?>
                    <div class="alert alert-info alert-dismissible">
                        <i class="bi bi-info-circle-fill"></i>
                        <?= clean($info) ?>
                        <button type="button" class="btn-close" onclick="this.parentElement.remove()">×</button>
                    </div>
                <?php endif; ?>
