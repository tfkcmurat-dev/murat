            </main>
        </div>
    </div>
    
    <script src="<?= adminUrl('assets/js/admin.js') ?>"></script>
    
    <script>
    // Alert auto-dismiss
    document.querySelectorAll('.alert-dismissible').forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });
    
    // Mobile menu
    if (window.innerWidth < 992) {
        document.querySelector('.mobile-menu-btn').style.display = 'block';
    }
    
    window.addEventListener('resize', () => {
        const btn = document.querySelector('.mobile-menu-btn');
        if (btn) {
            btn.style.display = window.innerWidth < 992 ? 'block' : 'none';
        }
    });
    </script>
</body>
</html>
