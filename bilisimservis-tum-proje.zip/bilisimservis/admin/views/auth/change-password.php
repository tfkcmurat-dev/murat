<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Şifre Değiştir</h1>
        <p>Hesap güvenliğiniz için şifrenizi düzenli olarak değiştirin.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-shield-lock me-2"></i>Şifre Güncelleme
            </div>
            <div class="card-body">
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle me-2"></i><?= clean($success) ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-error">
                        <i class="bi bi-exclamation-circle me-2"></i><?= clean($error) ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error">
                        <i class="bi bi-exclamation-circle me-2"></i>
                        <ul style="margin: 0; padding-left: 20px;">
                            <?php foreach ($errors as $err): ?>
                                <li><?= clean($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="<?= adminUrl('change-password.php') ?>">
                    <?= csrfField() ?>
                    
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Mevcut Şifre <span class="text-danger">*</span></label>
                        <input 
                            type="password" 
                            id="current_password" 
                            name="current_password" 
                            class="form-control"
                            required
                            autocomplete="current-password"
                        >
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Yeni Şifre <span class="text-danger">*</span></label>
                        <input 
                            type="password" 
                            id="new_password" 
                            name="new_password" 
                            class="form-control"
                            required
                            autocomplete="new-password"
                            minlength="8"
                        >
                        <small class="text-muted">En az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir.</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Yeni Şifre (Tekrar) <span class="text-danger">*</span></label>
                        <input 
                            type="password" 
                            id="confirm_password" 
                            name="confirm_password" 
                            class="form-control"
                            required
                            autocomplete="new-password"
                        >
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-2"></i>Şifreyi Değiştir
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card" style="background: rgba(59, 130, 246, 0.1); border-color: rgba(59, 130, 246, 0.3);">
            <div class="card-header" style="background: transparent; border-color: rgba(59, 130, 246, 0.2);">
                <i class="bi bi-info-circle me-2"></i>Şifre Güvenliği İpuçları
            </div>
            <div class="card-body">
                <ul style="color: var(--text-secondary); font-size: 0.9rem; padding-left: 20px; margin: 0;">
                    <li style="margin-bottom: 12px;">
                        <strong>Güçlü şifre kullanın:</strong> En az 8 karakter, büyük/küçük harf, rakam kombinasyonu.
                    </li>
                    <li style="margin-bottom: 12px;">
                        <strong>Benzersiz olsun:</strong> Her site için farklı şifre kullanın.
                    </li>
                    <li style="margin-bottom: 12px;">
                        <strong>Düzenli değiştirin:</strong> Şifrenizi 3-6 ayda bir yenileyin.
                    </li>
                    <li style="margin-bottom: 12px;">
                        <strong>Paylaşmayın:</strong> Şifrenizi kimseyle paylaşmayın.
                    </li>
                    <li>
                        <strong>Tahmin edilemez olsun:</strong> Kişisel bilgilerinizi (doğum tarihi, isim vb.) kullanmayın.
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Şifre Gücü Göstergesi -->
        <div class="card" style="margin-top: 24px;">
            <div class="card-header">
                <i class="bi bi-speedometer2 me-2"></i>Şifre Gücü
            </div>
            <div class="card-body">
                <div id="passwordStrength">
                    <div class="strength-bar" style="height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden; margin-bottom: 12px;">
                        <div id="strengthIndicator" style="height: 100%; width: 0%; background: #ef4444; transition: all 0.3s;"></div>
                    </div>
                    <p id="strengthText" style="margin: 0; font-size: 0.9rem; color: var(--text-muted);">Şifre girin...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('new_password').addEventListener('input', function() {
    const password = this.value;
    const indicator = document.getElementById('strengthIndicator');
    const text = document.getElementById('strengthText');
    
    let strength = 0;
    let label = '';
    let color = '';
    
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    
    if (password.length === 0) {
        label = 'Şifre girin...';
        color = '#6b7280';
        strength = 0;
    } else if (strength <= 2) {
        label = 'Zayıf';
        color = '#ef4444';
    } else if (strength <= 4) {
        label = 'Orta';
        color = '#f59e0b';
    } else {
        label = 'Güçlü';
        color = '#10b981';
    }
    
    indicator.style.width = (strength / 6 * 100) + '%';
    indicator.style.background = color;
    text.textContent = label;
    text.style.color = color;
});

// Şifre eşleşme kontrolü
document.getElementById('confirm_password').addEventListener('input', function() {
    const password = document.getElementById('new_password').value;
    const confirm = this.value;
    
    if (confirm && password !== confirm) {
        this.style.borderColor = '#ef4444';
    } else {
        this.style.borderColor = '';
    }
});
</script>
