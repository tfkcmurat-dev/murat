<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>SMTP Ayarları</h1>
        <p>E-posta gönderimi için SMTP yapılandırmasını buradan ayarlayın.</p>
    </div>
</div>

<form method="POST" action="">
    <?= csrfField() ?>
    
    <!-- Mail Durumu -->
    <div class="card">
        <div class="card-header bg-<?= $settings['mail_enabled'] == '1' ? 'success' : 'warning' ?>">
            <i class="bi bi-power me-2"></i>
            Mail Gönderimi Durumu
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Mail Gönderimi</label>
                    <select name="settings[mail_enabled]" class="form-control">
                        <option value="0" <?= $settings['mail_enabled'] == '0' ? 'selected' : '' ?>>Devre Dışı</option>
                        <option value="1" <?= $settings['mail_enabled'] == '1' ? 'selected' : '' ?>>Aktif</option>
                    </select>
                    <small style="color: var(--text-muted);">Mail gönderimini aktif etmeden önce SMTP ayarlarını yapılandırın.</small>
                </div>
            </div>
        </div>
    </div>

    <!-- SMTP Sunucu Ayarları -->
    <div class="card">
        <div class="card-header bg-primary">
            <i class="bi bi-server me-2"></i>
            SMTP Sunucu Ayarları
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">SMTP Sunucu Adresi</label>
                    <input type="text" name="settings[smtp_host]" class="form-control" value="<?= clean($settings['smtp_host']) ?>" placeholder="smtp.gmail.com">
                    <small style="color: var(--text-muted);">Gmail için: smtp.gmail.com</small>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">SMTP Port</label>
                    <input type="text" name="settings[smtp_port]" class="form-control" value="<?= clean($settings['smtp_port']) ?>" placeholder="587">
                    <small style="color: var(--text-muted);">TLS: 587, SSL: 465</small>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Şifreleme</label>
                    <select name="settings[smtp_encryption]" class="form-control">
                        <option value="tls" <?= $settings['smtp_encryption'] == 'tls' ? 'selected' : '' ?>>TLS (Önerilen)</option>
                        <option value="ssl" <?= $settings['smtp_encryption'] == 'ssl' ? 'selected' : '' ?>>SSL</option>
                        <option value="" <?= $settings['smtp_encryption'] == '' ? 'selected' : '' ?>>Yok</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Kimlik Doğrulama -->
    <div class="card">
        <div class="card-header bg-info">
            <i class="bi bi-shield-lock me-2"></i>
            Kimlik Doğrulama
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">SMTP Kullanıcı Adı (E-posta)</label>
                    <input type="email" name="settings[smtp_username]" class="form-control" value="<?= clean($settings['smtp_username']) ?>" placeholder="your@gmail.com">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">SMTP Şifre</label>
                    <input type="password" name="settings[smtp_password]" class="form-control" value="<?= clean($settings['smtp_password']) ?>" placeholder="App Password">
                    <small style="color: var(--text-muted);">Gmail için "App Password" kullanın.</small>
                </div>
            </div>
            
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <strong>Gmail Kullanıcıları İçin:</strong><br>
                1. Google hesabınızda 2 Faktörlü Kimlik Doğrulama aktif olmalı<br>
                2. <a href="https://myaccount.google.com/apppasswords" target="_blank" style="color: inherit; text-decoration: underline;">Google App Passwords</a> sayfasından yeni bir App Password oluşturun<br>
                3. Oluşturulan 16 haneli şifreyi yukarıdaki "SMTP Şifre" alanına girin
            </div>
        </div>
    </div>

    <!-- Gönderen Bilgileri -->
    <div class="card">
        <div class="card-header bg-secondary">
            <i class="bi bi-person-badge me-2"></i>
            Gönderen Bilgileri
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Gönderen E-posta Adresi</label>
                    <input type="email" name="settings[smtp_from_email]" class="form-control" value="<?= clean($settings['smtp_from_email']) ?>" placeholder="noreply@sirketiniz.com">
                    <small style="color: var(--text-muted);">Genellikle SMTP kullanıcı adı ile aynı olmalı.</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Gönderen Adı</label>
                    <input type="text" name="settings[smtp_from_name]" class="form-control" value="<?= clean($settings['smtp_from_name']) ?>" placeholder="Bilişim Servis">
                </div>
            </div>
        </div>
    </div>

    <!-- Kaydet Butonu -->
    <div class="d-flex justify-content-between mb-4">
        <div class="d-flex gap-2">
            <button type="button" id="testConnectionBtn" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
                <i class="bi bi-plug me-2"></i>Bağlantı Testi
            </button>
            <button type="button" id="sendTestMailBtn" class="btn" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3);">
                <i class="bi bi-envelope-check me-2"></i>Test Maili Gönder
            </button>
        </div>
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="bi bi-check-lg me-2"></i>Ayarları Kaydet
        </button>
    </div>
</form>

<!-- Test Mail Modal -->
<div id="testMailModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 1000; align-items: center; justify-content: center;">
    <div style="background: var(--bg-card); border-radius: 16px; padding: 24px; max-width: 400px; width: 90%; border: 1px solid var(--border-color);">
        <h3 style="margin-bottom: 16px; color: var(--text-primary);">Test E-postası Gönder</h3>
        <div class="mb-3">
            <label class="form-label">Alıcı E-posta Adresi</label>
            <input type="email" id="testEmailInput" class="form-control" placeholder="test@example.com">
        </div>
        <div class="d-flex gap-2 justify-content-end">
            <button type="button" id="closeModalBtn" class="btn" style="background: var(--bg-input); color: var(--text-secondary);">İptal</button>
            <button type="button" id="confirmTestMailBtn" class="btn btn-primary">Gönder</button>
        </div>
    </div>
</div>

<!-- Result Modal -->
<div id="resultModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 1001; align-items: center; justify-content: center;">
    <div style="background: var(--bg-card); border-radius: 16px; padding: 24px; max-width: 400px; width: 90%; border: 1px solid var(--border-color); text-align: center;">
        <div id="resultIcon" style="font-size: 48px; margin-bottom: 16px;"></div>
        <h3 id="resultTitle" style="margin-bottom: 8px; color: var(--text-primary);"></h3>
        <p id="resultMessage" style="color: var(--text-secondary); margin-bottom: 16px;"></p>
        <button type="button" id="closeResultBtn" class="btn btn-primary">Tamam</button>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const csrfToken = '<?= generateCsrfToken() ?>';
    const csrfName = '<?= CSRF_TOKEN_NAME ?>';
    
    // Test Mail Modal
    const testMailModal = document.getElementById('testMailModal');
    const resultModal = document.getElementById('resultModal');
    
    document.getElementById('sendTestMailBtn').addEventListener('click', function() {
        testMailModal.style.display = 'flex';
    });
    
    document.getElementById('closeModalBtn').addEventListener('click', function() {
        testMailModal.style.display = 'none';
    });
    
    document.getElementById('closeResultBtn').addEventListener('click', function() {
        resultModal.style.display = 'none';
    });
    
    // Show result
    function showResult(success, title, message) {
        document.getElementById('resultIcon').innerHTML = success 
            ? '<i class="bi bi-check-circle" style="color: #10b981;"></i>'
            : '<i class="bi bi-x-circle" style="color: #ef4444;"></i>';
        document.getElementById('resultTitle').textContent = title;
        document.getElementById('resultMessage').textContent = message;
        resultModal.style.display = 'flex';
    }
    
    // Test Connection
    document.getElementById('testConnectionBtn').addEventListener('click', function() {
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Test Ediliyor...';
        
        const formData = new FormData();
        formData.append(csrfName, csrfToken);
        
        fetch('<?= adminUrl("mail-settings.php?action=test-connection") ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            showResult(data.success, data.success ? 'Başarılı!' : 'Hata!', data.message);
        })
        .catch(error => {
            showResult(false, 'Hata!', 'Bir hata oluştu: ' + error.message);
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-plug me-2"></i>Bağlantı Testi';
        });
    });
    
    // Send Test Mail
    document.getElementById('confirmTestMailBtn').addEventListener('click', function() {
        const email = document.getElementById('testEmailInput').value;
        if (!email) {
            alert('Lütfen bir e-posta adresi girin.');
            return;
        }
        
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Gönderiliyor...';
        
        testMailModal.style.display = 'none';
        
        const formData = new FormData();
        formData.append(csrfName, csrfToken);
        formData.append('test_email', email);
        
        fetch('<?= adminUrl("mail-settings.php?action=test") ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            showResult(data.success, data.success ? 'Gönderildi!' : 'Gönderilemedi!', data.message);
        })
        .catch(error => {
            showResult(false, 'Hata!', 'Bir hata oluştu: ' + error.message);
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = 'Gönder';
            document.getElementById('testEmailInput').value = '';
        });
    });
});
</script>
