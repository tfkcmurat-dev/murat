<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Hakkımızda Sayfası Yönetimi</h1>
            <p class="text-muted mb-0">Hakkımızda sayfasındaki tüm içerikleri buradan düzenleyebilirsiniz.</p>
        </div>
        <a href="<?= url('hakkimizda') ?>" target="_blank" class="btn btn-outline-primary">
            <i class="bi bi-eye me-2"></i>Sayfayı Görüntüle
        </a>
    </div>

    <?php if ($flash = getFlash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($flash = getFlash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $flash ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= generateCsrfToken() ?>">
        
        <!-- Hero Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-house me-2"></i>Hero Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[about_hero_badge]" class="form-control" value="<?= clean($settings['about_hero_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[about_hero_title]" class="form-control" value="<?= clean($settings['about_hero_title']) ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Vurgulu Kelime</label>
                        <input type="text" name="settings[about_hero_highlight]" class="form-control" value="<?= clean($settings['about_hero_highlight']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[about_hero_subtitle]" class="form-control" rows="2"><?= clean($settings['about_hero_subtitle']) ?></textarea>
                    </div>
                </div>
                
                <h6 class="border-bottom pb-2 mb-3">Hero İstatistikler</h6>
                <div class="row">
                    <?php for($i = 1; $i <= 3; $i++): ?>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat <?= $i ?> Sayı</label>
                        <input type="text" name="settings[about_stat<?= $i ?>_number]" class="form-control" value="<?= clean($settings['about_stat' . $i . '_number']) ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Stat <?= $i ?> Etiket</label>
                        <input type="text" name="settings[about_stat<?= $i ?>_label]" class="form-control" value="<?= clean($settings['about_stat' . $i . '_label']) ?>">
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- Story Section -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-book me-2"></i>Hikaye Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[about_story_badge]" class="form-control" value="<?= clean($settings['about_story_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[about_story_title]" class="form-control" value="<?= clean($settings['about_story_title']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">İçerik</label>
                        <textarea name="settings[about_story_content]" class="form-control" rows="4"><?= clean($settings['about_story_content']) ?></textarea>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 mb-3 mt-4">Zaman Çizelgesi</h6>
                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-header"><strong>Dönem <?= $i ?></strong></div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-4 mb-2">
                                        <label class="form-label">Yıl</label>
                                        <input type="text" name="settings[about_timeline<?= $i ?>_year]" class="form-control" value="<?= clean($settings['about_timeline' . $i . '_year']) ?>">
                                    </div>
                                    <div class="col-8 mb-2">
                                        <label class="form-label">Başlık</label>
                                        <input type="text" name="settings[about_timeline<?= $i ?>_title]" class="form-control" value="<?= clean($settings['about_timeline' . $i . '_title']) ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Açıklama</label>
                                        <input type="text" name="settings[about_timeline<?= $i ?>_desc]" class="form-control" value="<?= clean($settings['about_timeline' . $i . '_desc']) ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i>İstatistikler Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-3 mb-3">
                        <div class="card">
                            <div class="card-header"><strong>İstatistik <?= $i ?></strong></div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <label class="form-label">Sayı</label>
                                    <input type="text" name="settings[about_stats_stat<?= $i ?>_number]" class="form-control" value="<?= clean($settings['about_stats_stat' . $i . '_number']) ?>">
                                </div>
                                <div class="mb-2">
                                    <label class="form-label">Ek (%, + vb.)</label>
                                    <input type="text" name="settings[about_stats_stat<?= $i ?>_suffix]" class="form-control" value="<?= clean($settings['about_stats_stat' . $i . '_suffix']) ?>">
                                </div>
                                <div>
                                    <label class="form-label">Etiket</label>
                                    <input type="text" name="settings[about_stats_stat<?= $i ?>_label]" class="form-control" value="<?= clean($settings['about_stats_stat' . $i . '_label']) ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- Values Section -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-heart me-2"></i>Değerlerimiz Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Badge</label>
                        <input type="text" name="settings[about_values_badge]" class="form-control" value="<?= clean($settings['about_values_badge']) ?>">
                    </div>
                    <div class="col-md-8 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[about_values_title]" class="form-control" value="<?= clean($settings['about_values_title']) ?>">
                    </div>
                </div>

                <div class="row">
                    <?php for($i = 1; $i <= 4; $i++): ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-header"><strong>Değer <?= $i ?></strong></div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="settings[about_value<?= $i ?>_title]" class="form-control" value="<?= clean($settings['about_value' . $i . '_title']) ?>">
                                </div>
                                <div>
                                    <label class="form-label">Açıklama</label>
                                    <textarea name="settings[about_value<?= $i ?>_desc]" class="form-control" rows="2"><?= clean($settings['about_value' . $i . '_desc']) ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <!-- CTA Section -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="bi bi-megaphone me-2"></i>CTA Bölümü</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Başlık</label>
                        <input type="text" name="settings[about_cta_title]" class="form-control" value="<?= clean($settings['about_cta_title']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Buton Metni</label>
                        <input type="text" name="settings[about_cta_button]" class="form-control" value="<?= clean($settings['about_cta_button']) ?>">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Alt Başlık</label>
                        <textarea name="settings[about_cta_subtitle]" class="form-control" rows="2"><?= clean($settings['about_cta_subtitle']) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <div class="d-flex justify-content-end gap-2 mb-4">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check-lg me-2"></i>Değişiklikleri Kaydet
            </button>
        </div>
    </form>
</div>
