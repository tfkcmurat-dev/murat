<?php
require_once __DIR__ . '/../app/config/config.php';
require_once ADMIN_PATH . '/controllers/QuoteController.php';

$controller = new QuoteController();

$action = $_GET['action'] ?? 'index';
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'create':
        $controller->create();
        break;
    case 'edit':
        if ($id) {
            $controller->edit($id);
        } else {
            redirect(adminUrl('quotes.php'));
        }
        break;
    case 'view':
        if ($id) {
            $controller->view($id);
        } else {
            redirect(adminUrl('quotes.php'));
        }
        break;
    case 'updateStatus':
        if ($id) {
            $controller->updateStatus($id);
        } else {
            redirect(adminUrl('quotes.php'));
        }
        break;
    case 'resendEmail':
        if ($id) {
            $controller->resendEmail($id);
        } else {
            redirect(adminUrl('quotes.php'));
        }
        break;
    default:
        $controller->index();
        break;
}
