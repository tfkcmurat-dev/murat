// Page Transitions - Smooth page changes

// Ensure body is always visible - set immediately
if (document.body) {
    document.body.style.opacity = '1';
    document.body.style.visibility = 'visible';
}

document.addEventListener('DOMContentLoaded', function() {
    // Ensure body is visible
    document.body.style.opacity = '1';
    document.body.style.visibility = 'visible';
    
    // Add page transition class
    document.body.classList.add('page-transition');
    
    // Only animate if GSAP is available and loaded
    if (typeof gsap !== 'undefined' && typeof gsap.to === 'function') {
        try {
            // Small fade-in animation
            gsap.from('body', {
                opacity: 0.95,
                duration: 0.3,
                ease: 'power2.out'
            });
        } catch (e) {
            console.warn('GSAP animation error:', e);
            document.body.style.opacity = '1';
        }
    }
    
    // Safety: ensure body is visible after a short delay
    setTimeout(function() {
        document.body.style.opacity = '1';
        document.body.style.visibility = 'visible';
    }, 100);

    // Handle link clicks for smooth transitions
    const links = document.querySelectorAll('a[href^="/"], a[href^="http"]');
    
    links.forEach(link => {
        // Skip external links and admin links
        if (link.href.includes('admin') || link.target === '_blank') {
            return;
        }
        
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Skip if it's an anchor link or empty
            if (href.startsWith('#') || href === '' || href === '/') {
                return;
            }
            
            // Skip if it's the same page
            if (href === window.location.pathname) {
                e.preventDefault();
                return;
            }
            
            // Add fade out animation
            if (typeof gsap !== 'undefined') {
                gsap.to('body', {
                    opacity: 0,
                    duration: 0.3,
                    ease: 'power2.in',
                    onComplete: () => {
                        window.location.href = href;
                    }
                });
            } else {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '0';
                setTimeout(() => {
                    window.location.href = href;
                }, 300);
            }
            
            e.preventDefault();
        });
    });
});

// Loading state
window.addEventListener('load', function() {
    document.body.classList.add('loaded');
    document.body.classList.remove('loading');
    // Ensure body is visible after page load
    document.body.style.opacity = '1';
    document.body.style.visibility = 'visible';
});

// Safety fallback: ensure body is always visible
setTimeout(function() {
    if (document.body) {
        document.body.style.opacity = '1';
        document.body.style.visibility = 'visible';
    }
}, 500);
