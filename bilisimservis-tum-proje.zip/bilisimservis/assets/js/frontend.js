// Frontend JavaScript - Professional IT Service Theme

// Counter animation function (shared) - Smooth increment
// useCardStyle: true = slider/card stats (dark text), false = legacy gradient (white)
function animateCounter(element, target, suffix, useCardStyle) {
    if (element.classList.contains('counted')) return;
    element.classList.add('counted');
    
    let current = 0;
    const duration = 2500;
    const startTime = Date.now();
    
    function updateCounter() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        current = Math.floor(target * easeOutQuart);
        
        element.textContent = current + suffix;
        element.style.opacity = '1';
        element.style.visibility = 'visible';
        if (!useCardStyle) {
            element.style.color = 'white';
        }
        
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target + suffix;
        }
    }
    
    element.textContent = '0' + suffix;
    requestAnimationFrame(updateCounter);
}

document.addEventListener('DOMContentLoaded', function() {
    // Header scroll effect with GSAP
    const header = document.querySelector('.header');
    if (header && typeof ScrollTrigger !== 'undefined') {
        ScrollTrigger.create({
            start: 'top -50',
            end: 99999,
            toggleClass: { className: 'scrolled', targets: header }
        });
    } else if (header) {
        // Fallback without GSAP
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
    
    // Initialize counters (fallback if GSAP not available)
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
        const counters = document.querySelectorAll('.stat-number[data-target]');
        counters.forEach(counter => {
            const isSlider = !!counter.closest('.stats-section-slider');
            counter.style.opacity = '1';
            counter.style.visibility = 'visible';
            if (!isSlider) {
                counter.style.color = 'white';
            }
            const label = counter.nextElementSibling;
            if (label && label.classList.contains('stat-label')) {
                label.style.opacity = '1';
                label.style.visibility = 'visible';
                if (!isSlider) {
                    label.style.color = 'white';
                }
            }
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting && !counter.classList.contains('counted')) {
                        const target = parseInt(counter.getAttribute('data-target'));
                        const suffix = counter.getAttribute('data-suffix') || '';
                        animateCounter(counter, target, suffix, isSlider);
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });
            observer.observe(counter.closest('.stat-item') || counter.closest('.stats-section'));
        });
    }
    
    // Legacy stats (non-slider): ensure stat labels white
    document.querySelectorAll('.stats-section:not(.stats-section-slider) .stat-label').forEach(label => {
        label.style.color = 'white';
        label.style.opacity = '1';
        label.style.visibility = 'visible';
    });

    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navbarNav = document.querySelector('.navbar-nav');
    if (mobileMenuBtn && navbarNav) {
        mobileMenuBtn.addEventListener('click', function() {
            navbarNav.classList.toggle('active');
            this.classList.toggle('active');
            
            // Animate menu if GSAP available
            if (typeof gsap !== 'undefined' && navbarNav.classList.contains('active')) {
                gsap.from(navbarNav.querySelectorAll('li'), {
                    opacity: 0,
                    x: -20,
                    duration: 0.3,
                    stagger: 0.1,
                    ease: 'power2.out'
                });
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!navbarNav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                navbarNav.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            }
        });
    }

    // Smooth scroll handled by animations.js

    // Animations handled by animations.js

    // Partner logos carousel - CSS animation handles scrolling
    // Animation is handled by CSS keyframes (scroll-left)
    // Hover pause is handled by CSS :hover pseudo-class

    // Form validation
    const contactForm = document.querySelector('.contact-form form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('input[required], textarea[required]');
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('error');
                } else {
                    input.classList.remove('error');
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Lütfen tüm gerekli alanları doldurun.');
            }
        });
    }

    // Lazy loading images with Intersection Observer
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        // Create new image to preload
                        const newImg = new Image();
                        newImg.onload = () => {
                            img.src = img.dataset.src;
                            img.classList.add('loaded');
                            img.removeAttribute('data-src');
                            imageObserver.unobserve(img);
                        };
                        newImg.onerror = () => {
                            img.removeAttribute('data-src');
                            imageObserver.unobserve(img);
                        };
                        newImg.src = img.dataset.src;
                    }
                }
            });
        }, {
            rootMargin: '50px'
        });

        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
    
    // Preload critical images
    const criticalImages = [
        '<?= url("assets/images/logo.png") ?>'
    ];
    
    criticalImages.forEach(src => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
    });
});

// Hero text animation with Alpine.js
if (typeof Alpine !== 'undefined') {
    Alpine.data('heroSlider', () => ({
        changingTexts: [
            'BİLGİSAYAR TAMİRİ',
            'TELEFON TAMİRİ',
            'TABLET TAMİRİ',
            'YAZICI TAMİRİ',
            'FORMAT',
            'YAZILIM KURULUMU',
            'PARÇA DEĞİŞİMİ',
            'KURUMSAL & BİREYSEL TEKNİK SERVİS'
        ],
        currentIndex: 0,
        init() {
            this.currentIndex = 0;
            setInterval(() => {
                this.currentIndex = (this.currentIndex + 1) % this.changingTexts.length;
            }, 3000);
        }
    }));
}

// GSAP ScrollTo plugin (if not using CDN version)
if (typeof gsap !== 'undefined' && !gsap.plugins.scrollTo) {
    // Simple scrollTo implementation
    gsap.registerPlugin({
        name: 'scrollTo',
        init: function() {
            gsap.to(window, {
                scrollTo: { y: 0 },
                duration: 1
            });
        }
    });
}
