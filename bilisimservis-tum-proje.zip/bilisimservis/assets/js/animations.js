// GSAP Animations - Professional IT Service Theme

// Initialize animations when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Wait for GSAP to load
    if (typeof gsap === 'undefined') {
        console.warn('GSAP not loaded, animations will be limited');
        initAnimationsFallback();
        return;
    }
    
    // Register ScrollTrigger plugin if available
    if (typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);
    }
    
    initAnimations();
});

// Fallback animations without GSAP
function initAnimationsFallback() {
    // Simple fade-in animations using CSS classes
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
        el.style.opacity = '0';
        el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        observer.observe(el);
    });
}

function initAnimations() {
    // Check if GSAP is loaded
    if (typeof gsap === 'undefined') {
        console.warn('GSAP is not loaded');
        return;
    }
    
    // Fade in animations for sections
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.utils.toArray('.fade-in-up').forEach((element, index) => {
            gsap.from(element, {
                opacity: 0,
                y: 60,
                duration: 1,
                ease: 'power3.out',
                scrollTrigger: {
                    trigger: element,
                    start: 'top 85%',
                    toggleActions: 'play none none none'
                },
                delay: index * 0.1
            });
        });

        // Fade in from left
        gsap.utils.toArray('.fade-in-left').forEach((element) => {
            gsap.from(element, {
                opacity: 0,
                x: -60,
                duration: 1,
                ease: 'power3.out',
                scrollTrigger: {
                    trigger: element,
                    start: 'top 85%',
                    toggleActions: 'play none none none'
                }
            });
        });

        // Fade in from right
        gsap.utils.toArray('.fade-in-right').forEach((element) => {
            gsap.from(element, {
                opacity: 0,
                x: 60,
                duration: 1,
                ease: 'power3.out',
                scrollTrigger: {
                    trigger: element,
                    start: 'top 85%',
                    toggleActions: 'play none none none'
                }
            });
        });

        // Scale in animations
        gsap.utils.toArray('.scale-in').forEach((element, index) => {
            gsap.from(element, {
                opacity: 0,
                scale: 0.8,
                duration: 0.8,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: element,
                    start: 'top 85%',
                    toggleActions: 'play none none none'
                },
                delay: index * 0.1
            });
        });
    } else {
        // Fallback: Use CSS animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                }
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right, .scale-in').forEach(el => {
            observer.observe(el);
        });
    }

    // Stagger animations for cards
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        const cardContainers = document.querySelectorAll('.services-grid, .features-grid, .process-grid');
        cardContainers.forEach(container => {
            const cards = container.querySelectorAll('.service-card, .feature-box, .process-step');
            if (cards.length > 0) {
                // Ensure cards are visible before animation
                cards.forEach(card => {
                    card.style.opacity = '1';
                    card.style.visibility = 'visible';
                });
                
                gsap.from(cards, {
                    opacity: 0,
                    y: 50,
                    duration: 0.8,
                    ease: 'power3.out',
                    stagger: 0.15,
                    scrollTrigger: {
                        trigger: container,
                        start: 'top 85%',
                        toggleActions: 'play none none none',
                        onEnter: () => {
                            // Ensure visibility after animation
                            cards.forEach(card => {
                                card.style.opacity = '1';
                                card.style.visibility = 'visible';
                            });
                        }
                    }
                });
            }
        });
    } else {
        // Fallback: Ensure cards are visible without GSAP
        const cardContainers = document.querySelectorAll('.services-grid, .features-grid, .process-grid');
        cardContainers.forEach(container => {
            const cards = container.querySelectorAll('.service-card, .feature-box, .process-step');
            cards.forEach(card => {
                card.style.opacity = '1';
                card.style.visibility = 'visible';
            });
        });
    }

    // Animated counters with smooth increment
    const counters = document.querySelectorAll('.stat-number[data-target]');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const suffix = counter.getAttribute('data-suffix') || '';
        const isSlider = !!counter.closest('.stats-section-slider');
        
        counter.style.opacity = '1';
        counter.style.visibility = 'visible';
        if (!isSlider) {
            counter.style.color = 'white';
        }
        
        const label = counter.nextElementSibling;
        if (label && label.classList.contains('stat-label')) {
            label.style.opacity = '1';
            label.style.visibility = 'visible';
            if (!isSlider) {
                label.style.color = 'white';
            }
        }
        
        const animateCounterSmooth = window.animateCounter || function(element, target, suffix, useCardStyle) {
            if (element.classList.contains('counted')) return;
            element.classList.add('counted');
            
            let current = 0;
            const duration = 2500;
            const startTime = Date.now();
            
            function updateCounter() {
                const elapsed = Date.now() - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const easeOutQuart = 1 - Math.pow(1 - progress, 4);
                current = Math.floor(target * easeOutQuart);
                
                element.textContent = current + suffix;
                element.style.opacity = '1';
                element.style.visibility = 'visible';
                if (!useCardStyle) {
                    element.style.color = 'white';
                }
                
                if (progress < 1) {
                    requestAnimationFrame(updateCounter);
                } else {
                    element.textContent = target + suffix;
                }
            }
            
            element.textContent = '0' + suffix;
            requestAnimationFrame(updateCounter);
        };
        
        const triggerEl = counter.closest('.stat-item') || counter.closest('.stats-section');
        if (typeof ScrollTrigger !== 'undefined') {
            ScrollTrigger.create({
                trigger: triggerEl,
                start: 'top 80%',
                once: true,
                onEnter: () => {
                    animateCounterSmooth(counter, target, suffix, isSlider);
                }
            });
        } else {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting && !counter.classList.contains('counted')) {
                        animateCounterSmooth(counter, target, suffix, isSlider);
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });
            observer.observe(triggerEl);
        }
    });

    // Parallax effect for hero section
    const heroSection = document.querySelector('.hero-section');
    if (heroSection && typeof gsap !== 'undefined') {
        gsap.to('.floating-element', {
            y: -30,
            x: 20,
            rotation: 5,
            duration: 3,
            ease: 'sine.inOut',
            repeat: -1,
            yoyo: true,
            stagger: 0.5
        });
    }

    // 3D card tilt effect (only for non-service cards or when explicitly enabled)
    const cards3D = document.querySelectorAll('.card-3d:not(.service-card)');
    cards3D.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;
            
            if (typeof gsap !== 'undefined') {
                gsap.to(card, {
                    rotationX: rotateX,
                    rotationY: rotateY,
                    transformPerspective: 1000,
                    duration: 0.3,
                    ease: 'power2.out'
                });
            }
        });
        
        card.addEventListener('mouseleave', () => {
            if (typeof gsap !== 'undefined') {
                gsap.to(card, {
                    rotationX: 0,
                    rotationY: 0,
                    duration: 0.5,
                    ease: 'power2.out'
                });
            }
        });
    });
    
    // Reset all service cards to ensure alignment
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        // Ensure no transform is applied initially
        if (typeof gsap !== 'undefined') {
            gsap.set(card, {
                rotationX: 0,
                rotationY: 0,
                transform: 'none'
            });
        } else {
            card.style.transform = 'none';
        }
        
        // Only apply subtle hover effect, no 3D tilt
        card.addEventListener('mouseenter', () => {
            if (typeof gsap !== 'undefined') {
                gsap.to(card, {
                    y: -15,
                    scale: 1.02,
                    duration: 0.5,
                    ease: 'power2.out'
                });
            }
        });
        
        card.addEventListener('mouseleave', () => {
            if (typeof gsap !== 'undefined') {
                gsap.to(card, {
                    y: 0,
                    scale: 1,
                    rotationX: 0,
                    rotationY: 0,
                    duration: 0.5,
                    ease: 'power2.out'
                });
            } else {
                card.style.transform = 'none';
            }
        });
    });

    // Text reveal animation
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        const textRevealElements = document.querySelectorAll('.text-reveal');
        textRevealElements.forEach(element => {
            const text = element.textContent;
            element.innerHTML = '';
            const chars = text.split('');
            
            chars.forEach((char, index) => {
                const span = document.createElement('span');
                span.textContent = char === ' ' ? '\u00A0' : char;
                span.style.opacity = '0';
                element.appendChild(span);
                
                gsap.to(span, {
                    opacity: 1,
                    duration: 0.05,
                    delay: index * 0.03,
                    scrollTrigger: {
                        trigger: element,
                        start: 'top 85%',
                        toggleActions: 'play none none none'
                    }
                });
            });
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#' || href === '') return;
            
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                const headerOffset = 100;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                if (typeof gsap !== 'undefined' && gsap.to) {
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                } else {
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Hero section animations
    if (typeof gsap !== 'undefined') {
        const heroTitle = document.querySelector('.hero-title');
        const heroSubtitle = document.querySelector('.hero-subtitle');
        const heroButtons = document.querySelector('.hero-buttons');
        const heroImage = document.querySelector('.hero-image');

        if (heroTitle) {
            gsap.from(heroTitle, {
                opacity: 0,
                y: 50,
                duration: 1,
                ease: 'power3.out'
            });
        }

        if (heroSubtitle) {
            gsap.from(heroSubtitle, {
                opacity: 0,
                y: 30,
                duration: 1,
                delay: 0.2,
                ease: 'power3.out'
            });
        }

        if (heroButtons) {
            gsap.from(heroButtons, {
                opacity: 0,
                y: 30,
                duration: 1,
                delay: 0.4,
                ease: 'power3.out'
            });
        }

        if (heroImage) {
            gsap.from(heroImage, {
                opacity: 0,
                x: 50,
                duration: 1,
                delay: 0.6,
                ease: 'power3.out'
            });
        }
    }
}

// Export for use in other files
window.initAnimations = initAnimations;
