<?php
require __DIR__ . '/../sitemap.php';
