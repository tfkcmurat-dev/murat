<?php
/**
 * Homepage Content Controller
 * Anasayfa içeriklerini yönetir
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/ThemeSettings.php';

class HomepageController {
    private $themeModel;
    
    public function __construct() {
        $this->themeModel = new ThemeSettings();
    }
    
    /**
     * Anasayfa içerik yönetimi
     */
    public function index() {
        requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token kontrolü
            if (!validateCsrfToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
                setFlash('error', 'Güvenlik hatası. Lütfen tekrar deneyin.');
                redirect(adminUrl('homepage.php'));
            }
            
            // Ayarları kaydet
            $settings = $_POST['settings'] ?? [];
            foreach ($settings as $key => $value) {
                $this->themeModel->save($key, $value);
            }
            
            setFlash('success', 'Anasayfa içerikleri başarıyla kaydedildi.');
            redirect(adminUrl('homepage.php'));
        }
        
        // Anasayfa ayarlarını getir
        $settings = $this->getHomepageSettings();
        
        $pageTitle = 'Anasayfa Yönetimi';
        require_once ADMIN_PATH . '/views/layouts/header.php';
        adminView('homepage/index', [
            'settings' => $settings
        ]);
        require_once ADMIN_PATH . '/views/layouts/footer.php';
    }
    
    /**
     * Anasayfa ayarlarını getir
     */
    private function getHomepageSettings() {
        $defaults = [
            'hero_badge_text' => 'İstanbul için teknik servis çözümleri',
            'hero_title_line1' => 'Bilgisayardan Elektriğe,',
            'hero_title_line2' => 'Tüm Teknik Çözümler',
            'hero_title_line3' => 'Tek Adreste',
            'hero_subtitle' => 'Bilgisayar ve elektronik cihaz tamirinden elektrik tesisatına, TV-uydu ve kamera sistemlerine kadar teknik ihtiyaçlarınız için yanınızdayız.',
            'home_about_title' => 'Teknik Serviste Çözüm Ortağınız',
            'home_about_text' => 'Bireysel ve kurumsal müşterilerimizin bilgisayar, elektronik, elektrik, TV-uydu, kamera ve küçük ev aletleri ihtiyaçları için bakım ve onarım çözümleri sunuyoruz.'
        ];
        $settings = [];
        foreach ($defaults as $key => $default) $settings[$key] = $this->themeModel->get($key) ?? $default;
        return $settings;
    }
}
