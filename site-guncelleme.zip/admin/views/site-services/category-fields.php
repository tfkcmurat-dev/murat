<?php
$groupValue = 'bilgisayar-mac'; $subgroupValue = 'mutfak';
if (isset($service)) {
    foreach (bsServiceGroups(bsMergeServices([$service])) as $key => $group) {
        if (in_array($service['slug'], array_column($group['services'], 'slug'), true)) { $groupValue = $key; break; }
    }
    foreach (bsServiceCatalog() as $item) if ($item['slug'] === $service['slug']) $subgroupValue = $item['appliance_group'] ?? 'mutfak';
    $saved = bsManagedServiceMetadata()[$service['slug']] ?? [];
    $groupValue = $saved['group'] ?? $groupValue; $subgroupValue = $saved['appliance_group'] ?? $subgroupValue;
}
?>
<div class="card" style="margin-bottom:24px"><div class="card-body"><label class="form-label" for="service_group">Hizmet kategorisi</label><select class="form-control" id="service_group" name="service_group"><?php foreach (bsServiceGroupOptions() as $key=>$label): ?><option value="<?= clean($key) ?>" <?= $groupValue===$key?'selected':'' ?>><?= clean($label) ?></option><?php endforeach; ?></select><label class="form-label" for="appliance_group">Küçük ev aletleri alt kategorisi</label><select class="form-control" id="appliance_group" name="appliance_group"><?php foreach (['kisisel-bakim'=>'Kişisel Bakım','mutfak'=>'Mutfak Aletleri','temizlik'=>'Temizlik Cihazları','ev-konforu'=>'Ütü & Ev Konforu'] as $key=>$label): ?><option value="<?= clean($key) ?>" <?= $subgroupValue===$key?'selected':'' ?>><?= clean($label) ?></option><?php endforeach; ?></select><small>Alt kategori yalnızca Küçük Ev Aletleri seçildiğinde kullanılır.</small></div></div>
