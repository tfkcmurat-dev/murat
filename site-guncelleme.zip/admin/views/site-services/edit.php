<!-- Page Header -->
<div class="page-header">
    <div class="page-header-content">
        <h1>Site Hizmeti Düzenle</h1>
        <p>Hizmet bilgilerini güncelleyin.</p>
    </div>
    <a href="<?= adminUrl('site-services.php') ?>" class="btn btn-outline-primary">
        <i class="bi bi-arrow-left me-2"></i>Geri Dön
    </a>
</div>

<form method="POST" action="" enctype="multipart/form-data">
    <?= csrfField() ?>
    
    <?php require ADMIN_PATH . '/views/site-services/category-fields.php'; ?>
    <!-- Temel Bilgiler -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header bg-primary">
            <i class="bi bi-info-circle me-2"></i>Temel Bilgiler
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label">
                        Hizmet Adı <span style="color: #f87171;">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name" 
                        required
                        value="<?= clean($service['name'] ?? '') ?>"
                        class="form-control"
                        placeholder="Örn: Bilgisayar Tamiri"
                    >
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="slug" class="form-label">URL Slug</label>
                    <input 
                        type="text" 
                        id="slug" 
                        name="slug" 
                        value="<?= clean($service['slug'] ?? '') ?>"
                        class="form-control"
                        placeholder="Otomatik oluşturulur"
                    >
                    <small style="color: var(--text-muted);">Boş bırakılırsa hizmet adından otomatik oluşturulur</small>
                </div>
                
                <div class="col-12 mb-3">
                    <label for="subtitle" class="form-label">Alt Başlık</label>
                    <input 
                        type="text" 
                        id="subtitle" 
                        name="subtitle" 
                        value="<?= clean($service['subtitle'] ?? '') ?>"
                        class="form-control"
                        placeholder="Örn: Masaüstü ve dizüstü bilgisayar tamir hizmetleri"
                    >
                </div>
                
                <div class="col-12 mb-3">
                    <label for="description" class="form-label">Açıklama</label>
                    <textarea 
                        id="description" 
                        name="description" 
                        rows="5"
                        class="form-control"
                        placeholder="Hizmet hakkında detaylı açıklama..."
                    ><?= clean($service['description'] ?? '') ?></textarea>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Görsel ve İkon -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <i class="bi bi-image me-2"></i>Görsel ve İkon
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="icon" class="form-label">İkon</label>
                    <select id="icon" name="icon" class="form-control">
                        <option value="laptop" <?= ($service['icon'] ?? '') === 'laptop' ? 'selected' : '' ?>>💻 Laptop</option>
                        <option value="smartphone" <?= ($service['icon'] ?? '') === 'smartphone' ? 'selected' : '' ?>>📱 Smartphone</option>
                        <option value="tablet" <?= ($service['icon'] ?? '') === 'tablet' ? 'selected' : '' ?>>📱 Tablet</option>
                        <option value="printer" <?= ($service['icon'] ?? '') === 'printer' ? 'selected' : '' ?>>🖨️ Printer</option>
                        <option value="settings" <?= ($service['icon'] ?? '') === 'settings' || empty($service['icon']) ? 'selected' : '' ?>>⚙️ Settings</option>
                        <option value="users" <?= ($service['icon'] ?? '') === 'users' ? 'selected' : '' ?>>👥 Users</option>
                    </select>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="service_image" class="form-label">Fotoğraf yükle</label><input id="service_image" name="service_image" type="file" accept="image/png,image/jpeg,image/webp" class="form-control"><small>En fazla 5 MB. Dosya seçilirse aşağıdaki adres yerine yüklediğiniz görsel kullanılır.</small><label for="image" class="form-label">Görsel adresi (isteğe bağlı)</label>
                    <input 
                        type="text" 
                        id="image" 
                        name="image" 
                        value="<?= clean($service['image'] ?? '') ?>"
                        class="form-control"
                        placeholder="https://example.com/image.jpg"
                    >
                    <small style="color: var(--text-muted);">Hizmet detay sayfasında gösterilecek görsel</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Özellikler -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <i class="bi bi-list-check me-2"></i>Hizmet Özellikleri
        </div>
        <div class="card-body">
            <label for="features" class="form-label">Özellikler (Her satıra bir özellik)</label>
            <textarea 
                id="features" 
                name="features" 
                rows="6"
                class="form-control"
                placeholder="Örn:&#10;Ücretsiz teşhis&#10;Hızlı tamir süreci&#10;Garanti&#10;Uzman ekip"
            ><?php 
                if (!empty($service['features'])) {
                    $features = json_decode($service['features'], true);
                    if (is_array($features)) {
                        echo clean(implode("\n", $features));
                    }
                }
            ?></textarea>
            <small style="color: var(--text-muted);">Her satıra bir özellik yazın</small>
        </div>
    </div>
    
    <!-- FAQ -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-header">
            <i class="bi bi-question-circle me-2"></i>Sıkça Sorulan Sorular (FAQ)
        </div>
        <div class="card-body">
            <label for="faq" class="form-label">Soru ve Cevaplar (Her satıra bir soru-cevap çifti)</label>
            <textarea 
                id="faq" 
                name="faq" 
                rows="8"
                class="form-control"
                placeholder="Format: Soru | Cevap&#10;Örn:&#10;Hizmet ne kadar sürer? | Genellikle 1-3 iş günü içinde tamamlanır.&#10;Garanti var mı? | Evet, tüm işlemlerimizde garanti sunuyoruz."
            ><?php 
                if (!empty($service['faq'])) {
                    $faq = json_decode($service['faq'], true);
                    if (is_array($faq)) {
                        $faqLines = [];
                        foreach ($faq as $item) {
                            if (isset($item['question']) && isset($item['answer'])) {
                                $faqLines[] = clean($item['question']) . ' | ' . clean($item['answer']);
                            }
                        }
                        echo implode("\n", $faqLines);
                    }
                }
            ?></textarea>
            <small style="color: var(--text-muted);">Format: <strong>Soru | Cevap</strong> (her satıra bir soru-cevap çifti)</small>
        </div>
    </div>
    
    <!-- Durum -->
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label" style="margin-bottom: 12px;">Durum</label>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; padding: 12px 20px; background: var(--bg-input); border-radius: 10px; border: 1px solid var(--border-color);">
                            <input 
                                type="checkbox" 
                                name="is_active" 
                                value="1" 
                                <?= ($service['is_active'] ?? 0) ? 'checked' : '' ?>
                                style="width: 18px; height: 18px; accent-color: var(--accent-primary);"
                            >
                            <span>Aktif (Sitede görünsün)</span>
                        </label>
                    </div>
                </div>
                
                <div class="col-md-6" style="display: flex; align-items: flex-end; justify-content: flex-end; gap: 12px;">
                    <a href="<?= adminUrl('site-services.php') ?>" class="btn" style="background: var(--bg-input); color: var(--text-secondary); border: 1px solid var(--border-color);">
                        <i class="bi bi-x-lg me-2"></i>İptal
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-2"></i>Güncelle
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
// Slug otomatik oluşturma
document.getElementById('name').addEventListener('input', function() {
    const slugInput = document.getElementById('slug');
    if (!slugInput.value || slugInput.dataset.autoGenerated === 'true') {
        const slug = this.value
            .toLowerCase()
            .replace(/ş/g, 's')
            .replace(/ğ/g, 'g')
            .replace(/ü/g, 'u')
            .replace(/ı/g, 'i')
            .replace(/ö/g, 'o')
            .replace(/ç/g, 'c')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
        slugInput.value = slug;
        slugInput.dataset.autoGenerated = 'true';
    }
});

document.getElementById('slug').addEventListener('input', function() {
    this.dataset.autoGenerated = 'false';
});
</script>
