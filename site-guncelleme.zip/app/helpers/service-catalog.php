<?php
/** Public service content; no database writes. Existing records take precedence. */
function bsServiceCatalog() {
    return json_decode(<<<'CATALOG_JSON'
[
  {
    "id": "catalog-bilgisayar-mac-servis",
    "slug": "bilgisayar-mac-servis",
    "name": "Bilgisayar & Mac Servis",
    "subtitle": "Bilgisayar, MacBook, iMac ve laptop için onarım, bakım ve performans çözümleri.",
    "description": "Cihazınızın açılmaması, yavaş çalışması veya ısınması gibi sorunları donanım ve yazılım açısından değerlendiriyoruz. Yapılacak işlemleri ve parça seçeneklerini sizinle paylaşarak onayınız doğrultusunda ilerliyoruz.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Arıza tespiti ve donanım kontrolü\", \"İşletim sistemi ve yazılım kurulumu\", \"SSD ve bellek yükseltme\", \"Soğutma sistemi temizliği ve bakım\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektrik-elektronik",
    "slug": "elektrik-elektronik",
    "name": "Elektrik & Elektronik",
    "subtitle": "Elektrik tesisatı, aydınlatma ve elektronik cihazlar için teknik çözümler.",
    "description": "Ev ve iş yerlerindeki elektrik ve elektronik ihtiyaçlarını işin kapsamına göre değerlendiriyoruz. Tesisatın mevcut durumu incelenerek uygun malzeme ve uygulama seçenekleri belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Priz ve sigorta kontrolü\", \"Aydınlatma ve avize montajı\", \"Elektrik tesisatı arıza tespiti\", \"Elektronik devre değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tv-uydu-kamera",
    "slug": "tv-uydu-kamera",
    "name": "TV - Uydu - Kamera",
    "subtitle": "Televizyon tamiri, uydu kurulumu ve güvenlik kamera sistemleri.",
    "description": "Görüntü, sinyal ve kayıt sorunları için cihaz ve bağlantıları birlikte inceliyoruz. Televizyon, uydu ve kamera sistemlerinde ihtiyacınıza uygun kurulum veya onarım sürecini planlıyoruz.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Televizyon arıza tespiti\", \"Uydu anteni ve kanal ayarı\", \"Kamera sistemi planlaması\", \"Kayıt ve görüntü bağlantılarının kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kucuk-ev-aletleri-tamiri",
    "slug": "kucuk-ev-aletleri-tamiri",
    "name": "Küçük Ev Aletleri Tamiri",
    "subtitle": "Kahve makinesi, su ısıtıcısı, tost makinesi, blender ve diğer küçük ev aletleri.",
    "description": "Çalışmayan veya verimli çalışmayan küçük ev aletlerini cihazın marka, model ve arıza bilgisine göre değerlendiriyoruz. Onarımın mümkün olup olmadığı ve gerekli parça seçenekleri inceleme sonrasında paylaşılır.",
    "category": "appliance",
    "icon": "settings",
    "image": "",
    "features": "[\"Cihaz ve model değerlendirmesi\", \"Güç ve çalışma kontrolü\", \"Uygun parça seçenekleri\", \"Onarım sonrası işlev kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-bilgisayar-tamiri",
    "slug": "bilgisayar-tamiri",
    "name": "Bilgisayar Tamiri",
    "subtitle": "Masaüstü ve dizüstü bilgisayarlarda donanım ve yazılım arızaları.",
    "description": "Bilgisayarınızdaki sorunun kaynağını belirlemek için güç, depolama, bellek ve yazılım bileşenlerini kontrol ediyoruz. Veri içeren işlemlerden önce yedekleme ihtiyacını sizinle değerlendiriyoruz.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Açılmama ve görüntü sorunları\", \"Isınma ve fan kontrolü\", \"Disk ve bellek değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-macbook-imac-servis",
    "slug": "macbook-imac-servis",
    "name": "MacBook & iMac Servis",
    "subtitle": "Apple bilgisayarlar için bakım ve onarım değerlendirmesi.",
    "description": "MacBook ve iMac cihazlarda performans, açılış ve donanım sorunlarını modelin özelliklerine göre inceliyoruz. İşlem ve parça uygunluğu cihaz değerlendirmesi sonrasında belirlenir.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"Model bazlı arıza tespiti\", \"Depolama ve sistem kontrolü\", \"Soğutma bakımı\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-donanim-yukseltme",
    "slug": "donanim-yukseltme",
    "name": "Donanım Yükseltme",
    "subtitle": "Uyumlu SSD ve bellek seçenekleriyle cihaz performansını geliştirin.",
    "description": "Mevcut bilgisayarınızın ihtiyaçlarını ve yükseltme sınırlarını kontrol ediyoruz. Uyumlu parçalar, veri aktarımı ve kurulum seçenekleri işlem öncesinde sizinle paylaşılır.",
    "category": "computer",
    "icon": "laptop",
    "image": "",
    "features": "[\"SSD uyumluluk kontrolü\", \"RAM kapasitesi değerlendirmesi\", \"Veri aktarımı planlaması\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektrik-tesisati",
    "slug": "elektrik-tesisati",
    "name": "Elektrik Tesisatı",
    "subtitle": "Ev ve iş yerleri için tesisat kontrolü ve elektrik uygulamaları.",
    "description": "Elektrik tesisatının durumunu ve kullanım ihtiyacını yerinde inceleyerek yapılacak işlemleri planlıyoruz. Uygulama kapsamı ve malzeme seçimi inceleme sonrasında netleştirilir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Tesisat arıza tespiti\", \"Hat ve bağlantı kontrolü\", \"İhtiyaca uygun uygulama planı\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-priz-sigorta-aydinlatma",
    "slug": "priz-sigorta-aydinlatma",
    "name": "Priz - Sigorta - Aydınlatma",
    "subtitle": "Priz, anahtar, sigorta ve aydınlatma sorunları için destek.",
    "description": "Çalışmayan priz, atan sigorta veya aydınlatma problemlerinde bağlantı ve kullanım koşullarını birlikte değerlendiriyoruz. Uygun çözüm, arızanın kaynağı tespit edildikten sonra belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Priz ve anahtar kontrolü\", \"Sigorta arızalarının değerlendirilmesi\", \"Aydınlatma bağlantıları\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-avize-montaji",
    "slug": "avize-montaji",
    "name": "Avize Montajı",
    "subtitle": "Avize ve aydınlatma ürünleri için montaj desteği.",
    "description": "Avizenin ağırlığı, montaj yüzeyi ve elektrik bağlantıları değerlendirilerek montaj planlanır. İşlem öncesinde ürün bilgisi ve montaj yerinin fotoğrafı hazırlık sürecine yardımcı olur.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Montaj noktasının kontrolü\", \"Ürün ve bağlantı uygunluğu\", \"Montaj sonrası çalışma kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tv-tamiri",
    "slug": "tv-tamiri",
    "name": "TV Tamiri",
    "subtitle": "Televizyonlarda görüntü, ses ve açılma sorunlarının değerlendirilmesi.",
    "description": "Televizyonunuzun marka, model ve arıza belirtisine göre inceleme yapıyoruz. Ekran, güç veya bağlantı kaynaklı sorunlar için onarım seçenekleri değerlendirme sonrasında paylaşılır.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Görüntü ve ses kontrolü\", \"Güç ve bağlantı değerlendirmesi\", \"Model bazlı parça uygunluğu\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-uydu-sistemleri",
    "slug": "uydu-sistemleri",
    "name": "Uydu Sistemleri",
    "subtitle": "Uydu anteni, sinyal ve kanal ayarlama işlemleri.",
    "description": "Sinyal kaybı ve kanal sorunlarında anten, kablo ve uydu alıcısını birlikte kontrol ediyoruz. Kurulum veya ayar işlemleri mevcut sistemin durumuna göre planlanır.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Anten ve kablo kontrolü\", \"Sinyal değerlendirmesi\", \"Kanal ve alıcı ayarları\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kamera-sistemleri",
    "slug": "kamera-sistemleri",
    "name": "Kamera Sistemleri",
    "subtitle": "Ev ve işletmeler için görüntüleme ve kayıt çözümleri.",
    "description": "Kamera sistemini izlemek istediğiniz alan ve kayıt ihtiyacına göre planlıyoruz. Mevcut sistemlerde görüntü ve bağlantı sorunları değerlendirilerek uygun çözüm seçenekleri sunulur.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "features": "[\"Görüntüleme alanının planlanması\", \"Kamera ve kayıt cihazı seçimi\", \"Bağlantı ve kayıt kontrolü\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-yazici-toner-servisi",
    "slug": "yazici-toner-servisi",
    "name": "Yazıcı & Toner Servisi",
    "subtitle": "Yazıcı kurulumu, baskı sorunları ve toner değerlendirmesi.",
    "description": "Yazıcılarda baskı kalitesi, kağıt besleme ve bağlantı sorunlarını model bilgisiyle birlikte değerlendiriyoruz. Toner ve diğer sarf malzemeleri cihaz uyumluluğuna göre seçilir.",
    "category": "computer",
    "icon": "printer",
    "image": "",
    "features": "[\"Baskı kalitesinin kontrolü\", \"Bağlantı ve sürücü kurulumu\", \"Modele uygun sarf malzemesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-elektronik-onarim",
    "slug": "elektronik-onarim",
    "name": "Elektronik Onarım",
    "subtitle": "Elektronik cihaz ve devrelerde arıza değerlendirmesi.",
    "description": "Elektronik cihazlardaki çalışma problemlerini cihazın kullanım alanı ve arıza belirtilerine göre inceliyoruz. Parça bulunabilirliği ve onarım uygunluğu değerlendirme sonrasında belirlenir.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "features": "[\"Cihaz ve devre incelemesi\", \"Güç ve bileşen kontrolü\", \"Onarım uygunluğu değerlendirmesi\"]",
    "faq": "[{\"question\": \"İnceleme öncesinde hangi bilgileri paylaşmalıyım?\", \"answer\": \"Cihaz veya sistemin marka ve modelini, yaşadığınız sorunu ve varsa fotoğraflarını paylaşabilirsiniz.\"}, {\"question\": \"Ücret ve işlem süresi nasıl belirleniyor?\", \"answer\": \"Ücret ve süre; inceleme, işin kapsamı ve gerekli parçaların durumuna göre belirlenir. Uygulama öncesinde bilgi verilir.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-evler-icin-teknik-servis",
    "slug": "evler-icin-teknik-servis",
    "name": "Evler İçin Teknik Servis",
    "subtitle": "Evde kullanılan bilgisayar, elektrik, TV, uydu ve küçük ev aletleri için destek.",
    "category": "appliance",
    "icon": "settings",
    "image": "",
    "description": "Evde kullanılan bilgisayar, elektrik, TV, uydu ve küçük ev aletleri için destek. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"İhtiyacın ve cihazın değerlendirilmesi\", \"Uygun bakım ve onarım seçenekleri\", \"İşlem öncesinde kapsam bilgisi\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-ofisler-icin-teknik-servis",
    "slug": "ofisler-icin-teknik-servis",
    "name": "Ofisler İçin Teknik Servis",
    "subtitle": "Ofis bilgisayarları, yazıcılar ve teknik altyapı için bakım ve destek.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Ofis bilgisayarları, yazıcılar ve teknik altyapı için bakım ve destek. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Bilgisayar ve yazıcı kontrolü\", \"Kurulum ve bağlantı değerlendirmesi\", \"Bakım ihtiyaçlarının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-isletmeler-icin-teknik-servis",
    "slug": "isletmeler-icin-teknik-servis",
    "name": "İşletmeler İçin Teknik Servis",
    "subtitle": "İşletmelerin cihaz ve teknik sistem ihtiyaçlarına yönelik çözümler.",
    "category": "screen",
    "icon": "settings",
    "image": "",
    "description": "İşletmelerin cihaz ve teknik sistem ihtiyaçlarına yönelik çözümler. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"İşletmenin ihtiyaçlarının değerlendirilmesi\", \"Kamera ve cihaz sistemi kontrolü\", \"İş kapsamının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-sanayi-icin-teknik-servis",
    "slug": "sanayi-icin-teknik-servis",
    "name": "Sanayi İçin Teknik Servis",
    "subtitle": "Elektrik, elektronik ve otomasyon bağlantıları için iş kapsamı değerlendirmesi.",
    "category": "electric",
    "icon": "settings",
    "image": "",
    "description": "Elektrik, elektronik ve otomasyon bağlantıları için iş kapsamı değerlendirmesi. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Sistem ve bağlantı incelemesi\", \"Elektrik ve elektronik ihtiyaçlarının belirlenmesi\", \"Uygulama kapsamının planlanması\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tamir-bakim",
    "slug": "tamir-bakim",
    "name": "Tamir & Bakım",
    "subtitle": "Cihazların bakım ve onarım ihtiyaçlarını birlikte değerlendirelim.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Cihazların bakım ve onarım ihtiyaçlarını birlikte değerlendirelim. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Arıza ve bakım ihtiyacının tespiti\", \"Uyumlu parça seçenekleri\", \"İşlem sonrası işlev kontrolü\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-cihaz-satis-aksesuar",
    "slug": "cihaz-satis-aksesuar",
    "name": "Cihaz Satış & Aksesuar",
    "subtitle": "Bilgisayar, yazıcı ve aksesuar seçiminde ihtiyaca uygun seçenekler.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Bilgisayar, yazıcı ve aksesuar seçiminde ihtiyaca uygun seçenekler. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Kullanım ihtiyacının belirlenmesi\", \"Cihaz ve aksesuar uyumluluğu\", \"Güncel stok ve fiyat bilgisi\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-satis-sonrasi-destek",
    "slug": "satis-sonrasi-destek",
    "name": "Satış Sonrası Destek",
    "subtitle": "Kurulum, kullanım ve teknik sorular için iletişim desteği.",
    "category": "computer",
    "icon": "settings",
    "image": "",
    "description": "Kurulum, kullanım ve teknik sorular için iletişim desteği. İhtiyacınızı, cihaz veya sistem bilgilerinizi paylaşın. Uygun hizmet kapsamı, işlem seçenekleri ve ücret bilgisi değerlendirme sonrasında belirlenir.",
    "features": "[\"Kurulum ve bağlantı desteği\", \"Cihaz kullanım sorularının değerlendirilmesi\", \"İşlem kapsamına göre destek seçenekleri\"]",
    "faq": "[{\"question\": \"Nasıl bilgi alabilirim?\", \"answer\": \"İletişim sayfasından veya telefonla ihtiyaç ve cihaz bilgilerinizi paylaşabilirsiniz.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-kahve-makinesi-tamiri",
    "slug": "kahve-makinesi-tamiri",
    "name": "Kahve Makinesi Tamiri",
    "subtitle": "Su akışı, ısıtma ve çalışma problemlerini marka ve modele göre değerlendiriyoruz.",
    "description": "Su akışı, ısıtma ve çalışma problemlerini marka ve modele göre değerlendiriyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 0,
    "icon": "settings",
    "image": "",
    "features": "[\"Su akışı ve ısıtma kontrolü\", \"Güç ve çalışma değerlendirmesi\", \"Temizlik ve bakım ihtiyacının belirlenmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-su-isiticisi-tamiri",
    "slug": "su-isiticisi-tamiri",
    "name": "Su Isıtıcısı Tamiri",
    "subtitle": "Elektrikli su ısıtıcılarında açılmama ve ısıtmama sorunlarını inceliyoruz.",
    "description": "Elektrikli su ısıtıcılarında açılmama ve ısıtmama sorunlarını inceliyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 1,
    "icon": "settings",
    "image": "",
    "features": "[\"Güç bağlantısı kontrolü\", \"Isıtma ve termostat değerlendirmesi\", \"Onarım uygunluğunun belirlenmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-tost-makinesi-tamiri",
    "slug": "tost-makinesi-tamiri",
    "name": "Tost Makinesi Tamiri",
    "subtitle": "Tost makinelerinin ısıtma ve güç sorunları için teknik değerlendirme.",
    "description": "Tost makinelerinin ısıtma ve güç sorunları için teknik değerlendirme. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 2,
    "icon": "settings",
    "image": "",
    "features": "[\"Isıtıcı ve güç kontrolü\", \"Termostat ve bağlantı değerlendirmesi\", \"İşlem sonrası çalışma kontrolü\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-blender-tamiri",
    "slug": "blender-tamiri",
    "name": "Blender Tamiri",
    "subtitle": "Blender cihazlarında motor ve çalışma problemlerinin değerlendirilmesi.",
    "description": "Blender cihazlarında motor ve çalışma problemlerinin değerlendirilmesi. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 3,
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve güç kontrolü\", \"Hazne ve bağlantı uygunluğu\", \"Parça bulunabilirliğinin değerlendirilmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-mikser-tamiri",
    "slug": "mikser-tamiri",
    "name": "Mikser Tamiri",
    "subtitle": "Mikserlerde hız, motor ve çalışma sorunlarını inceliyoruz.",
    "description": "Mikserlerde hız, motor ve çalışma sorunlarını inceliyoruz. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 4,
    "icon": "settings",
    "image": "",
    "features": "[\"Motor ve hız kontrolü\", \"Güç ve bağlantı incelemesi\", \"Parça ve onarım uygunluğu\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  },
  {
    "id": "catalog-supurge-tamiri",
    "slug": "supurge-tamiri",
    "name": "Süpürge Tamiri",
    "subtitle": "Elektrikli süpürgelerde çekiş, motor ve açılmama sorunlarına yönelik değerlendirme.",
    "description": "Elektrikli süpürgelerde çekiş, motor ve açılmama sorunlarına yönelik değerlendirme. Cihazınızın marka, model ve arıza belirtisini paylaşın. İşlem kapsamı, parça seçenekleri ve ücret inceleme sonrasında belirlenir.",
    "category": "appliance",
    "parent": "kucuk-ev-aletleri-tamiri",
    "photo_index": 5,
    "icon": "settings",
    "image": "",
    "features": "[\"Çekiş ve hava akışı kontrolü\", \"Motor ve güç incelemesi\", \"Filtre ve bakım ihtiyacının değerlendirilmesi\"]",
    "faq": "[{\"question\": \"Her marka ve model için onarım yapılabilir mi?\", \"answer\": \"Onarım uygunluğu cihazın durumu ve parça bulunabilirliğine göre değerlendirilir. Marka ve model bilgisini paylaşarak bilgi alabilirsiniz.\"}, {\"question\": \"İşlem süresi ve ücret ne zaman belli olur?\", \"answer\": \"İnceleme sonrasında yapılabilecek işlemler, parça seçenekleri, süre ve ücret bilgisi paylaşılır.\"}]",
    "is_active": 1
  }
]
CATALOG_JSON
, true);
}
function bsMergeServices($existing, $allRecords = []) {
    $result = is_array($existing) ? $existing : [];
    $slugs = array_merge(array_column($result, 'slug'), array_column($allRecords, 'slug'));
    foreach (bsServiceCatalog() as $item) {
        if (!in_array($item['slug'], $slugs, true)) $result[] = $item;
    }
    return $result;
}
function bsServicePhotoClass($service) {
    if (isset($service['photo_index']) && is_int($service['photo_index']) && $service['photo_index'] >= 0 && $service['photo_index'] <= 5) return 'bs-appliance-photo bs-appliance-' . $service['photo_index'];
    $category = $service['category'] ?? '';
    if (in_array($category, ['computer', 'electric', 'screen', 'appliance'], true)) return 'bs-photo-' . $category;
    $text = mb_strtolower(($service['name'] ?? '') . ' ' . ($service['slug'] ?? ''), 'UTF-8');
    if (preg_match('/kahve|blender|ev.alet|süpürge/u', $text)) return 'bs-photo-appliance';
    if (preg_match('/tv|televizyon|uydu|kamera/u', $text)) return 'bs-photo-screen';
    if (preg_match('/elektr|avize|priz|sigorta|otomasyon/u', $text)) return 'bs-photo-electric';
    return 'bs-photo-computer';
}
