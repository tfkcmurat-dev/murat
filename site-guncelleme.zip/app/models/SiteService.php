<?php
/**
 * Site Service Model
 * Sitede gösterilecek hizmetler için
 */

class SiteService {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Tüm hizmetleri getir
     */
    public function getAll($activeOnly = false) {
        try {
            $sql = "SELECT * FROM `site_services`";
            if ($activeOnly) {
                $sql .= " WHERE `is_active` = 1";
            }
            $sql .= " ORDER BY `name` ASC";
            
            $results = $this->db->fetchAll($sql);
            
            // Ensure we return an array
            if ($results === false || $results === null) {
                error_log("SiteService::getAll() - fetchAll returned false/null");
                return [];
            }
            
            // Debug: Log if empty
            if (empty($results)) {
                error_log("SiteService::getAll() - No services found. activeOnly: " . ($activeOnly ? 'true' : 'false'));
                // Try without backticks as fallback
                $sqlFallback = "SELECT * FROM site_services";
                if ($activeOnly) {
                    $sqlFallback .= " WHERE is_active = 1";
                }
                $sqlFallback .= " ORDER BY name ASC";
                $resultsFallback = $this->db->fetchAll($sqlFallback);
                if (!empty($resultsFallback)) {
                    error_log("SiteService::getAll() - Fallback query worked!");
                    return $resultsFallback;
                }
            } else {
                error_log("SiteService::getAll() - Found " . count($results) . " service(s)");
            }
            
            return is_array($results) ? $results : [];
        } catch (Exception $e) {
            error_log("SiteService::getAll() error: " . $e->getMessage());
            error_log("SiteService::getAll() trace: " . $e->getTraceAsString());
            return [];
        }
    }
    
    /**
     * Hizmet getir
     */
    public function findById($id) {
        return $this->db->fetch("SELECT * FROM site_services WHERE id = ?", [$id]);
    }
    
    /**
     * Slug'a göre hizmet getir
     */
    public function findBySlug($slug) {
        return $this->db->fetch("SELECT * FROM site_services WHERE slug = ? AND is_active = 1", [$slug]);
    }
    
    /**
     * Slug oluştur
     */
    public function generateSlug($name) {
        $slug = strtolower(trim($name));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');
        
        // Benzersizlik kontrolü
        $originalSlug = $slug;
        $counter = 1;
        while ($this->db->fetch("SELECT id FROM site_services WHERE slug = ?", [$slug])) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    /**
     * Hizmet oluştur
     */
    public function create($data) {
        return $this->db->insert('site_services', $data);
    }
    
    /**
     * Hizmet güncelle
     */
    public function update($id, $data) {
        return $this->db->update('site_services', $data, 'id = ?', [$id]);
    }
    
    /**
     * Hizmet sil (soft delete - aktif/pasif yap)
     */
    public function delete($id) {
        return $this->db->update('site_services', ['is_active' => 0], 'id = ?', [$id]);
    }
    
    /**
     * Hizmet aktif/pasif durumunu değiştir
     */
    public function toggleActive($id) {
        $service = $this->findById($id);
        if ($service) {
            $newStatus = $service['is_active'] ? 0 : 1;
            return $this->db->update('site_services', ['is_active' => $newStatus], 'id = ?', [$id]);
        }
        return false;
    }
    
    /**
     * Hizmet sayısı
     */
    public function count($activeOnly = false) {
        $sql = "SELECT COUNT(*) as count FROM site_services";
        if ($activeOnly) {
            $sql .= " WHERE is_active = 1";
        }
        $result = $this->db->fetch($sql);
        return $result['count'];
    }
    public function importPublicCatalog() {
        require_once APP_PATH . '/helpers/service-catalog.php';
        $connection = $this->db->getConnection();
        $connection->beginTransaction();
        try {
            $added = 0;
            foreach (bsServiceCatalog() as $item) {
                if ($this->db->fetch('SELECT id FROM site_services WHERE slug = ?', [$item['slug']])) continue;
                $data = array_intersect_key($item, array_flip(['name','slug','subtitle','description','icon','image','features','faq','is_active']));
                $this->create($data);
                $added++;
            }
            $connection->commit();
            return $added;
        } catch (Exception $e) {
            if ($connection->inTransaction()) $connection->rollBack();
            throw $e;
        }
    }

}
