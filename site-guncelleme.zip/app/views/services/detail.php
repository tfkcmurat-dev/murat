<?php
require_once APP_PATH . '/helpers/service-catalog.php';
$features = json_decode($service['features'] ?? '[]', true);
$features = is_array($features) ? array_filter($features, 'is_string') : [];
$faq = json_decode($service['faq'] ?? '[]', true);
$faq = is_array($faq) ? array_filter($faq, function ($item) { return is_array($item) && isset($item['question'], $item['answer']) && is_string($item['question']) && is_string($item['answer']); }) : [];
$phone = preg_replace('/[^+0-9]/', '', getThemeSetting('contact_phone', '05548634870'));
$image = $service['image'] ?? '';
$image = is_string($image) && (preg_match('#^https?://#i', $image) || (substr($image, 0, 1) === '/' && substr($image, 0, 2) !== '//')) ? $image : '';
?>
<main>
<section class="bs-hero bs-service-hero">
    <div class="container">
        <nav class="bs-breadcrumb" aria-label="Sayfa yolu"><a href="<?= url() ?>">Anasayfa</a><span aria-hidden="true">/</span><a href="<?= url('hizmetler') ?>">Hizmetler</a><span aria-hidden="true">/</span><span aria-current="page"><?= clean($service['name']) ?></span></nav>
        <div class="bs-hero-grid">
            <div><span class="bs-eyebrow">Bilişim Servis · Teknik Çözümler</span><h1><?= clean($service['name']) ?></h1><p><?= clean($service['subtitle'] ?? '') ?></p><div class="bs-actions"><a class="bs-button" href="<?= url('iletisim') ?>">Bilgi ve Teklif Al →</a><?php if ($phone !== ''): ?><a class="bs-button bs-button-light" href="tel:<?= clean($phone) ?>">Hemen Ara</a><?php endif; ?></div></div>
            <?php if ($image !== ''): ?><img class="bs-service-image" src="<?= clean($image) ?>" alt="<?= clean($service['name']) ?>" width="640" height="420"><?php else: ?><div class="bs-service-image bs-card-photo <?= bsServicePhotoClass($service) ?>" role="img" aria-label="<?= clean($service['name']) ?> için temsili teknik servis görseli"></div><?php endif; ?>
        </div>
    </div>
</section>
<div class="container bs-detail-layout">
    <article><span class="bs-eyebrow">Hizmet hakkında</span><h2><?= clean($service['name']) ?> için nasıl yardımcı oluyoruz?</h2><div class="bs-description"><?= nl2br(clean($service['description'] ?? 'İhtiyacınızı ve cihaz bilgilerinizi paylaşın; uygun hizmet kapsamını birlikte belirleyelim.')) ?></div>
    <?php if ($features): ?><h2>Hizmet Kapsamı</h2><ul class="bs-feature-list"><?php foreach ($features as $feature): ?><li><?= clean($feature) ?></li><?php endforeach; ?></ul><?php endif; ?></article>
    <aside class="bs-contact-card"><h2>İhtiyacınızı konuşalım</h2><p>Cihaz veya sistem bilgilerinizi paylaşın. İnceleme ve işlem seçenekleri hakkında bilgi alın.</p><a class="bs-button" href="<?= url('iletisim') ?>">İletişime Geç →</a><?php if ($phone !== ''): ?><a class="bs-button bs-button-light" href="tel:<?= clean($phone) ?>">Hemen Ara</a><?php endif; ?><small>İşlem kapsamı, ücret ve süre değerlendirme sonrasında belirlenir.</small></aside>
</div>
<?php if (($service['slug'] ?? '') === 'kucuk-ev-aletleri-tamiri'): ?>
<section class="bs-section"><div class="container"><span class="bs-eyebrow">Cihazınıza göre keşfedin</span><h2>Küçük Ev Aletleri Hizmetleri</h2><div class="bs-service-list-grid">
<?php foreach (bsServiceCatalog() as $product): if (($product['parent'] ?? '') !== 'kucuk-ev-aletleri-tamiri') continue; ?>
<a class="bs-home-card" href="<?= url('hizmet/' . $product['slug']) ?>"><div class="bs-card-photo <?= bsServicePhotoClass($product) ?>" role="img" aria-label="<?= clean($product['name']) ?> için temsili cihaz görseli"></div><div class="bs-home-card-body"><h2><?= clean($product['name']) ?></h2><p><?= clean($product['subtitle']) ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div></a>
<?php endforeach; ?>
</div></div></section>
<?php endif; ?>
<section class="bs-section bs-section-tint"><div class="container"><span class="bs-eyebrow">Hizmet süreci</span><h2>Üç adımda çözüm</h2><div class="bs-steps">
<div class="bs-step"><span class="bs-step-number">01 / İLETİŞİM</span><h3>İhtiyacınızı paylaşın</h3><p>Marka, model ve sorun bilgilerini iletin. Gerekirse fotoğraflarla durumu açıklayın.</p></div>
<div class="bs-step"><span class="bs-step-number">02 / DEĞERLENDİRME</span><h3>Seçenekleri öğrenin</h3><p>İnceleme sonrasında yapılabilecek işlemler, ücret ve süre hakkında bilgi alın.</p></div>
<div class="bs-step"><span class="bs-step-number">03 / UYGULAMA</span><h3>Onayınızla ilerleyelim</h3><p>Kararlaştırılan işlemler onayınızla uygulanır; tamamlandığında sonuçlar paylaşılır.</p></div>
</div></div></section>
<?php if ($faq): ?><section class="bs-section"><div class="container bs-faq"><span class="bs-eyebrow">Merak edilenler</span><h2>Sıkça Sorulan Sorular</h2><?php foreach ($faq as $item): ?><details><summary><?= clean($item['question']) ?></summary><p><?= nl2br(clean($item['answer'])) ?></p></details><?php endforeach; ?></div></section><?php endif; ?>
<?php if (!empty($relatedServices)): ?><section class="bs-section bs-section-tint"><div class="container"><span class="bs-eyebrow">Diğer çözümler</span><h2>İlgili Hizmetler</h2><div class="bs-related"><?php foreach ($relatedServices as $related): ?><a href="<?= url('hizmet/' . $related['slug']) ?>"><h3><?= clean($related['name']) ?></h3><p><?= clean($related['subtitle'] ?? '') ?></p><span>Hizmeti İncele →</span></a><?php endforeach; ?></div></div></section><?php endif; ?>
</main>
