<?php require_once APP_PATH . '/helpers/service-catalog.php'; ?>
<main>
<section class="bs-hero"><div class="container"><span class="bs-eyebrow">Bilişim Servis</span><h1>Tüm teknik çözümler,<br><span>tek adreste.</span></h1><p>İhtiyacınıza uygun hizmeti seçin. Detay sayfalarında hizmet kapsamını ve işlem sürecini inceleyin.</p></div></section>
<section class="bs-section"><div class="container bs-service-list-grid">
<?php foreach ($services ?? [] as $item): ?>
<a class="bs-home-card" href="<?= url('hizmet/' . ($item['slug'] ?? createSlug($item['name']))) ?>"><div class="bs-card-photo <?= bsServicePhotoClass($item) ?>" role="img" aria-label="<?= clean($item['name']) ?> hizmet görseli"></div><div class="bs-home-card-body"><h2><?= clean($item['name']) ?></h2><p><?= clean($item['subtitle'] ?? '') ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div></a>
<?php endforeach; ?>
</div></section>
</main>
