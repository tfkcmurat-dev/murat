<?php require_once APP_PATH . '/helpers/service-catalog.php'; $groups = bsServiceGroups($services ?? []); ?>
<main>
<section class="bs-hero"><div class="container"><span class="bs-eyebrow">Bilişim Servis · Hizmetlerimiz</span><h1>İhtiyacınıza göre<br><span>bir kategori seçin.</span></h1><p>Kategoriyi açın, ilgili hizmetleri inceleyin. Her hizmetin fotoğraflı detay sayfasından kapsam ve işlem bilgilerine ulaşabilirsiniz.</p></div></section>
<section class="bs-section"><div class="container bs-categories">
<?php foreach ($groups as $id => $group): ?>
<details class="bs-category" id="<?= clean($id) ?>">
<summary><span class="bs-category-heading"><span class="bs-category-name"><?= clean($group['name']) ?></span><span class="bs-category-description"><?= clean($group['description']) ?></span></span><span class="bs-category-count"><?= count($group['services']) ?> hizmet</span><span class="bs-category-toggle" aria-hidden="true">+</span></summary>
<?php if ($id === 'kucuk-ev-aletleri'): ?>
<div class="bs-appliance-overview"><a class="bs-button bs-button-light" href="<?= url('hizmet/kucuk-ev-aletleri-tamiri') ?>">Küçük Ev Aletleri Hizmeti Hakkında →</a></div>
<?php $applianceGroups = bsApplianceGroups($group['services']); require APP_PATH . '/views/services/appliance-groups.php'; ?>
<?php else: ?>
<div class="bs-service-list-grid bs-category-content">
<?php foreach ($group['services'] as $item): ?>
<a class="bs-home-card" href="<?= url('hizmet/' . $item['slug']) ?>"><?php echo bsRenderServicePhoto($item); ?><div class="bs-home-card-body"><h2><?= clean($item['name']) ?></h2><p><?= clean($item['subtitle'] ?? '') ?></p><span class="bs-card-arrow" aria-hidden="true">→</span></div></a>
<?php endforeach; ?>
</div>
<?php endif; ?></details>
<?php endforeach; ?>
</div></section>
</main>
<script>
(function () {
    function openLinkedCategory() {
        var id = location.hash.slice(1);
        var category = document.getElementById(id);
        if (category && category.matches('details.bs-category')) {
            category.open = true;
            category.scrollIntoView({block: 'start'});
        }
    }
    openLinkedCategory();
    window.addEventListener('hashchange', openLinkedCategory);
})();
</script>
