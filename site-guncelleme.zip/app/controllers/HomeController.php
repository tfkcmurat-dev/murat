<?php
/**
 * Home Controller
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/SiteService.php';
require_once APP_PATH . '/helpers/service-catalog.php';
require_once APP_PATH . '/models/Reference.php';

class HomeController {
    
    public function index() {
        try {
            $siteServiceModel = new SiteService();
            $allRecords = $siteServiceModel->getAll(false);
            $services = $siteServiceModel->getAll(true);
            
            // Debug: Log services count
            error_log("HomeController: Found " . count($services) . " active services");
            if (!empty($services)) {
                error_log("HomeController: First service: " . json_encode($services[0]));
            }
        } catch (Exception $e) {
            $services = [];
            error_log("Services error: " . $e->getMessage());
            error_log("Services error trace: " . $e->getTraceAsString());
        }
        
        try {
            $referenceModel = new Reference();
            $references = $referenceModel->getAllActive();
        } catch (Exception $e) {
            $references = [];
            error_log("References error: " . $e->getMessage());
        }
        
        $services = bsMergeServices($services ?? [], $allRecords ?? []);
        $pageTitle = '';
        require_once APP_PATH . '/views/layouts/header.php';
        view('home/index', [
            'services' => $services ?? [],
            'references' => $references ?? []
        ]);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
}
