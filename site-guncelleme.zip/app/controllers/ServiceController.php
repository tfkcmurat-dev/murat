<?php
/**
 * Service Controller
 * Hizmetler listesi sayfası
 */

require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/SiteService.php';
require_once APP_PATH . '/helpers/service-catalog.php';

class ServiceController {
    
    public function index() {
        try {
            $siteServiceModel = new SiteService();
            $allRecords = $siteServiceModel->getAll(false);
            $services = $siteServiceModel->getAll(true);
        } catch (Exception $e) {
            $services = [];
            error_log("Services error: " . $e->getMessage());
        }
        
        $services = bsMergeServices($services ?? [], $allRecords ?? []);
        $pageTitle = 'Hizmetlerimiz';
        require_once APP_PATH . '/views/layouts/header.php';
        view('services/index', [
            'services' => $services ?? []
        ]);
        require_once APP_PATH . '/views/layouts/footer.php';
    }
}
