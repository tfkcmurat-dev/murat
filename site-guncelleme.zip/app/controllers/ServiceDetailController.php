<?php
require_once APP_PATH . '/config/config.php';
require_once APP_PATH . '/models/SiteService.php';
require_once APP_PATH . '/helpers/service-catalog.php';

class ServiceDetailController {
    public function show($slug) {
        if (!in_array($slug, array_merge(array_column(bsServiceCatalog(), 'slug'), array_keys(bsManagedServiceMetadata())), true)) {
            bsRenderNotFound();
            return;
        }
        $service = null;
        $allServices = [];
        $existing = [];
        try {
            $model = new SiteService();
            $existing = $model->getAll(false);
            $service = $model->findBySlug($slug);
            $allServices = $model->getAll(true);
        } catch (Exception $e) {
            error_log('Service detail data unavailable: ' . $e->getMessage());
        }
        // An existing inactive record must not be reactivated by catalog content.
        $existingSlugs = array_column($existing, 'slug');
        if (!$service && !in_array($slug, $existingSlugs, true)) {
            foreach (bsServiceCatalog() as $item) {
                if ($item['slug'] === $slug) { $service = $item; break; }
            }
        }
        if (!$service) {
            bsRenderNotFound();
            return;
        }
        $allServices = bsMergeServices($allServices, $existing);
        foreach ($allServices as $mergedService) if ($mergedService['slug'] === $slug) $service = $mergedService;
        $relatedServices = array_values(array_filter($allServices, function ($item) use ($service) {
            return ($item['slug'] ?? '') !== $service['slug'];
        }));
        $relatedServices = array_slice($relatedServices, 0, 3);
        $pageTitle = $service['name'];
        require APP_PATH . '/views/layouts/header.php';
        view('services/detail', ['service' => $service, 'relatedServices' => $relatedServices, 'applianceServices' => $allServices]);
        require APP_PATH . '/views/layouts/footer.php';
    }
}
